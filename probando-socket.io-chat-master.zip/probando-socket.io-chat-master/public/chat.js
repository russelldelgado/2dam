console.log('que pasa');
//con este socket podemos tener todo el codigo del front end
//para enviar eso al servidor 
//inicmaos ser4vidor -> envia todo el front end al navegador --> cargamos el javascrito de socket io con 
//esto automaticamente me conecto al servidor , una vez me conecto se dispara el mensaje 
//tambien recibimos la informacion del cliente.
const socket =  io();


//DOM ELEMENT ES DECIR ELEMENTOS DE HTML
var message = document.getElementById('message');
var username = document.getElementById('username');
var btn = document.getElementById('send');
var output = document.getElementById('output');
var actions = document.getElementById('actions');

btn.addEventListener('click' , function(){
    //con esto le digo al servidor que le voy a enviar mediante algo que he creado que se llama
    //chat:message varios datos , y como solo puedo enviar un dato lo que hago es meterlos dentro de un objeto json
    //donde encapsulo al usuario y al mensaje
    socket.emit('chat:message' ,{message : message.value , username : username.value})
console.log(username.value , message.value)
})

message.addEventListener('keypress' , function(){
socket.emit('chat:typing' , username.value);
});

//data son los datos que recivo del servidor , no hay conflito porque el metodo emit 
//se encarga de emitir datos y el metodo on se encarga de escucahr esos datos que ha emitido el servidor.
socket.on('chat:message' , function(data){
    actions.innerHTML = '';
    output.innerHTML += `<p>
        <strong> ${data.username} </strong> : ${data.message}
    </p>`

})

socket.on('chat:typing' , function(data){
    actions.innerHTML =`
    <p><em>${data}</em> is typing a message</p>
    `
})