
//este modulo se utiliza para crear nuestro servidor
const express = require('express');
const app =  express();

//este modulo se utiliza para trabajar con rutas y unir directorios
const path = require('path');
//vamos a empezar a requerir el socket io ahora
const SocketIO = require('socket.io');

//------------------SERVIDOR--------------------------------


//setting
app.set('port' , process.env.PORT|| 3000)

//static files
console.log(__dirname)

//en este caso usamos el path.join para no tener que distinguir entre windows o linux
//ya que en w-se usa \ y en linux -se usa / , el path.join arregla este problema
//con app use le decimos que le mandamos la carpeta publica para que ya se cargue las paginas que vamos a utilizar

app.use(express.static(path.join(__dirname, 'public')))

//start service
const server =  app.listen(app.get('port') , ()=>{
    console.log(`servidor en el puerto ${app.get('port')}`);
})


//--------------------SOCKET IO---------------------------

//INDICAMOS QUE ESTA ESCUCHANDO NUESTRO SOCKET IO
var io  = SocketIO(server);

//WEB SOCKETS
io.on('connection' ,(socket)=>{
    console.log('new coneccion , id ; ' + socket.id)

    //con esto le indico que vamos a recibir un mensaje con estos datos (data) y con el nombre de chat:message
    socket.on('chat:message' , (data)=>{
        console.log(data);
        //io es la coneccion con todos los clientes
        //con este recibimos los datos y lo enviamos a todos los navegadores
        io.sockets.emit('chat:message', data )
    })

    socket.on('chat:typing' , (data)=>{
        console.log(data)
        socket.broadcast.emit('chat:typing' ,data);

    })
})










//INFORMACION EXTRA

//SOCKET IO
//SOCKET IO NECESITA UN SERVIDOR , HACE LA COMUNICACION BIDIRECCIONALA PERO NECESITA UN SERVIDOR YA CREADO
//ESTO SE HACE DESPUES DE CREAR NUESTRO SERVIDOR Y PONERLO A ESCUCHAR EN EL PUERTO QUE TENGAMOS
//si hacemos esto se crea en nuestra ruta principal un archivo que se llama socket.io/socker.io.js 
//podemos acceder a este archivo si no ponemos en el navegador la ruta
//ya tenemos conectado el backend pero ahora falta el front en , para esto lo que hacemos es poner un scritp
//en nuestro html para que escuche  <script src="/socket.io/socket.io.js" charset="utf-8" ></script>
//si hacemos esto no sucede nada , para que pase algo tenemos que usar una variable que utiliza el socket io
//io(); << esta es la variable la pegamos en un javascritp que tengamos enlazado con nuestro html y terminado.

