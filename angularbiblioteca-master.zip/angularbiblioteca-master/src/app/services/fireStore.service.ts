import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Book } from '../models/books';

@Injectable({
  providedIn: 'root'
})
export class FireStoreService {

  collection = 'biblioies'

  constructor(private firestore:AngularFirestore) { }

  getBook(){
    return this.firestore.collection<Book>('biblioies').snapshotChanges().pipe(
      map(books =>{
        return books.map(book => {
          const data = book.payload.doc.data();
          const key = book.payload.doc.id;
          return {key , ...data};
        });
      })
    );
  }

  getBoook(key : string){
    return this.firestore.collection<Book>(this.collection).doc(key).get();
  }

  addBook(book : Book){
    return this.firestore.collection<Book>(this.collection).add(book);
  }

  deleteBook(book : Book){
    return this.firestore.collection(this.collection).doc(book.key).delete();
  }

  updateBook(book : Book , key : string){
    return this.firestore.collection<Book>(this.collection).doc(key).update(book);
  }
}
