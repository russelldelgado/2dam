import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FireStoreService } from '../services/fireStore.service';
import { Book } from '../models/books';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

  bookForm : FormGroup = new FormGroup({
    title: new FormControl('' , [Validators.required]),
    isbn: new FormControl('' , [Validators.required,  Validators.minLength(13)]),
    description: new FormControl(''),

  });

  key : string;
  editMode : boolean = false;
  constructor(private firestoreService : FireStoreService , 
              private router : Router,
              private activateRouter : ActivatedRoute,
    ) { }

  save(){
    if(this.bookForm.valid){
      let book : Book = {
        title : this.bookForm.get('title').value,
        isbn : this.bookForm.get('isbn').value,
        description : this.bookForm.get('description').value,
      };
      if(this.editMode){

        this.firestoreService.updateBook(book , this.key).then(
          _ => {this.router.navigateByUrl('/');}
        );

      }else{
        this.firestoreService.addBook(book).then( 
          _ => {this.router.navigateByUrl('/');}
        );
      }
    }

  }

  ngOnInit(): void {

  if( this.activateRouter.snapshot.paramMap.has('key')){
    this.key = this.activateRouter.snapshot.paramMap.get('key');
    this.editMode = true;
    this.firestoreService.getBoook(this.key).subscribe(
      editBook =>{
        let mibook : Book = editBook.data();
        this.bookForm.get('title').setValue(mibook.title);
        this.bookForm.get('isbn').setValue(mibook.isbn);
        this.bookForm.get('description').setValue(mibook.description);
      }
    )
  }   



  }

}
