import { Component, OnInit } from '@angular/core';
import { from, Observable } from 'rxjs';
import { FireStoreService } from '../services/fireStore.service';
import { Book } from '../models/books';
import {tap} from 'rxjs/operators'
@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  
  books :Observable<Book[]>;
  selecterBook : Book;

constructor(private fireStoreService : FireStoreService){}

  ngOnInit(): void {
    //tap lo que hace es entrar en el observable y la funcion que hemos
    //metido dentro del tap se va a ejecutar una unica vez
    //tap sirve para no transformar los datos
 this.books =  this.fireStoreService.getBook().pipe(tap(
  books => this.selecterBook = books[0]

 ));}

 select(book : Book){
  this.selecterBook = book;
 }

}
