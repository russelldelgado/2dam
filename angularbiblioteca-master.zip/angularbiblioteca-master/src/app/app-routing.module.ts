import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookListComponent } from './book-list/book-list.component';
import { ErrorComponent } from './error/error.component';
import { AddBookComponent } from './add-book/add-book.component';

const routes: Routes = [
  {path : '' , component : BookListComponent},
  {path : 'nuevo' , component : AddBookComponent},
  {path : 'nuevo/:key' , component : AddBookComponent},
  {path : '**' , component : ErrorComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
