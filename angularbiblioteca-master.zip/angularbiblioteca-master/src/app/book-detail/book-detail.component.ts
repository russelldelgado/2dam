import { Component, Input, OnInit } from '@angular/core';
import { Book } from '../models/books';
import { FireStoreService } from '../services/fireStore.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-detail',
  templateUrl: './book-detail.component.html',
  styleUrls: ['./book-detail.component.css']
})
export class BookDetailComponent {

  @Input() book : Book;
constructor(private router : Router,
  private fireStoreService : FireStoreService){}

  delete(){
    if(this.book !=null){
      this.fireStoreService.deleteBook(this.book);
    }
  }

  edit(){
    this.router.navigate(['/nuevo', this.book.key] );
  }

}
