void main() async {
  //Future, async, await
  var numero = 0;
  print('A');
  await Future.delayed(Duration(seconds: 1), () {
    numero = 1;
    print('B $numero');
  });
  print('C $numero');
  await Future.delayed(Duration(seconds: 1), () => print('D'));
  print('E');
}
