import 'dart:convert';

import 'package:http/http.dart' as http;

Future<int> numeroLibros(busqueda) async {
  var domain = 'www.googleapis.com';
  var booksUrl = '/books/v1/volumes';

  var url = Uri.https(domain, booksUrl, {'q': busqueda});
  var response = await http.get(url);
  if (response.statusCode == 200) {
    var json = jsonDecode(response.body);
    var itemCount = json['totalItems'];
    return itemCount;
  } else {
    throw 'Error al conectar con el servidor';
  }
}
