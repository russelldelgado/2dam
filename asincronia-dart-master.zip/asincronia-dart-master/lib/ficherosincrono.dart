import 'dart:io';

void ficheroSincrono() {
  var path = Directory.current.path + '/prueba.bin';
  var fichero = File(path);
  var ficheroAbierto = fichero.openSync(mode: FileMode.write);
  for (var i = 0; i < 256; i++) {
    ficheroAbierto.writeByteSync(i);
  }
  ficheroAbierto.setPositionSync(0);

  var value = 0;
  while ((value = ficheroAbierto.readByteSync()) != -1) {
    print(value);
  }

  ficheroAbierto.closeSync();
}

Future ficheroAsincrono() async {
  var path = Directory.current.path + '/prueba.bin';
  var fichero = File(path);
  var ficheroAbierto = await fichero.open(mode: FileMode.write);

  for (var i = 0; i < 256; i++) {
    await ficheroAbierto.writeByte(i);
  }
  await ficheroAbierto.setPosition(0);

  var value = 0;
  while (value != -1) {
    value = await ficheroAbierto.readByte();
    print(value);
  }

  await ficheroAbierto.close().then((value) => print('Fichero cerrado'));
}
