package com.iesvdc.acceso.simplecrud.model;

public enum Estado {
    BUENO , MALO ,EXCELENTE;
}
