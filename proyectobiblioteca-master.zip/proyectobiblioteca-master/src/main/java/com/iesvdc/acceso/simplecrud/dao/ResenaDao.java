package com.iesvdc.acceso.simplecrud.dao;

import java.time.LocalDate;
import java.util.List;

import com.iesvdc.acceso.simplecrud.model.Libro;
import com.iesvdc.acceso.simplecrud.model.Resena;
import com.iesvdc.acceso.simplecrud.model.Usuario;

public interface ResenaDao {
    //public boolean create(Libro libro, int estrellas, String comentario, Usuario usuario, boolean anonimo, LocalDate fecha);
    public boolean create(int libro, int estrellas, String comentario, int usuario, boolean anonimo, LocalDate fecha);
    public boolean update(Resena oldResena, Resena newResena);
    public boolean update(int oldResena, Resena newResena);
    public Resena findOne(int idResena);
    public List<Resena> findAll();
    public List<Resena> findByLibro(Libro libro);
    public List<Resena> findByDate(LocalDate fecha);
    public List<Resena> findByUsuario(Usuario usuario);
    public boolean delete(int resena);
    public boolean delete(Resena resena);
}
