package com.iesvdc.acceso.simplecrud.controller.service;

import com.iesvdc.acceso.simplecrud.dao.*;
import com.iesvdc.acceso.simplecrud.daoimpl.*;
import com.iesvdc.acceso.simplecrud.model.*;

import jdk.nashorn.internal.objects.annotations.Getter;

import java.util.List;
import java.util.logging.Logger;

import javax.faces.annotation.RequestCookieMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * UsuarioResource
 */
@Path("/api")
public class UsuarioResource {

    @GET
    @Path("usuario")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getUsuarios() {
        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        List<Usuario> usuarios;
        try {
            usuarios = usuarioDao.findAll();
            return Response.ok(usuarios).build();
        } catch (Exception e) {
            Logger.getLogger(e.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }

    }

    @GET
    @Path("usuario/{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getUsuarioById(@PathParam("id") String id) {
        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;
        try {
            usuario = usuarioDao.findById(Integer.parseInt(id));
            return Response.ok(usuario).build();
        } catch (Exception e) {
            Logger.getLogger(e.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("usuario")
    public Response createUsuario(Usuario usuario) {
        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        try {
            if (usuarioDao.create(usuario))
                return Response.status(200).entity(usuario).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(500).entity(usuario).build();
        }
        return Response.status(404).entity(usuario).build();
    }

    @PUT
    @Path("usuario/{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response updateUsuario(@PathParam("id") Integer oldUsuario, Usuario newUsuario) {
        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        try {
            if (usuarioDao.update(oldUsuario, newUsuario)) {
                return Response.status(200).entity(newUsuario).build();
            }
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(oldUsuario).build();
        }
        return Response.status(Status.NOT_FOUND).entity(oldUsuario).build();
    }

    @DELETE
    @Path("usuario/{id}")
    public Response deleteUsuario(@PathParam("id") Integer id) {
        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        try {
            if (usuarioDao.delete(id))
                return Response.status(200).entity(id).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(id).build();
        }
        return Response.status(Status.NOT_FOUND).entity(id).build();
    }
    
}