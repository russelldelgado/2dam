package com.iesvdc.acceso.simplecrud.dao;

import java.time.LocalDate;
import java.util.List;

import com.iesvdc.acceso.simplecrud.model.Libro;
import com.iesvdc.acceso.simplecrud.model.Prestamo;
import com.iesvdc.acceso.simplecrud.model.Resena;
import com.iesvdc.acceso.simplecrud.model.Usuario;
import com.iesvdc.acceso.simplecrud.model.Estado;

public interface PrestamoDao {
    public boolean create(LocalDate fechaPrestamo, LocalDate fechaDevolucion, int usuario, int prorroga, Estado estado);
    public boolean update(Prestamo oldPrestamo, Prestamo newPrestamo);
    public boolean update(int oldPrestamo, Prestamo newPrestamo);
    public Prestamo findOne(int idPrestamo);
    public List<Prestamo> findAll();
    public List<Prestamo> findByUsuario(Usuario usuario);
    public boolean delete(int prestamo);
    public boolean delete(Prestamo prestamo);
}
