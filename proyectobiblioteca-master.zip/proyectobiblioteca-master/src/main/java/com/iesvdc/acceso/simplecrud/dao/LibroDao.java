package com.iesvdc.acceso.simplecrud.dao;

import java.util.List;

import com.iesvdc.acceso.simplecrud.model.Libro;

public interface LibroDao {
    public boolean create(Libro libro);
    public Libro findById(int id);
    public List<Libro> findAll();
    public List<Libro> findByTitulo(String titulo);
    public boolean update(Libro oldLibro, Libro nuevoLibro);
    public boolean update(int oldLibro, Libro nuevoLibro);
    public boolean delete(Libro libro);
    public boolean delete(int libro);
}
