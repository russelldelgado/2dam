package com.iesvdc.acceso.simplecrud;

import java.sql.Connection;
import com.iesvdc.acceso.simplecrud.conexion.Conexion;

public class Probando {

    public static void main(String[] args) {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        System.out.println(conn);
        System.out.println(conn);
        System.out.println(conn);
        System.out.println(conn);
    }
}
