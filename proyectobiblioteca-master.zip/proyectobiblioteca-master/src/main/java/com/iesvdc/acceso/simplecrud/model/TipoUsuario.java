package com.iesvdc.acceso.simplecrud.model;

public enum TipoUsuario {
    ALUMNO , PROFESOR , ADMINISTRADOR;
}
