
package com.iesvdc.acceso.simplecrud.model;

import java.util.Objects;

public class Usuario {

    int id;
    String userName;
    String password;
    TipoUsuario tipo;
    String nombre;
    String apellidos;
    String email;
    String dni;
    String telefono;


    public Usuario() {
    }

    public Usuario(int id, String userName, String password, String tipo, String nombre, String apellidos, String email, String dni, String telefono) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        if (tipo.equals("ADMINISTRADOR")) {
            this.tipo = TipoUsuario.ADMINISTRADOR;
        } else if (tipo.equals("ALUMNO")) {
            this.tipo = TipoUsuario.ALUMNO;
        } else if (tipo.equals("PROFESOR")){
            this.tipo = TipoUsuario.PROFESOR;
        }
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.dni = dni;
        this.telefono = telefono;
    }


    public Usuario(int id, String userName, String password, TipoUsuario tipo, String nombre, String apellidos, String email, String dni, String telefono) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.tipo = tipo;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.dni = dni;
        this.telefono = telefono;
    }

    public Usuario(String userName, String password, TipoUsuario tipo, String nombre, String apellidos, String email, String dni, String telefono) {
        this.userName = userName;
        this.password = password;
        this.tipo = tipo;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.dni = dni;
        this.telefono = telefono;
    }


    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public TipoUsuario getTipo() {
        return this.tipo;
    }

    public void setTipo(TipoUsuario tipo) {
        this.tipo = tipo;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return this.apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDni() {
        return this.dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTelefono() {
        return this.telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", userName='" + getUserName() + "'" +
            ", password='" + getPassword() + "'" +
            ", tipo='" + getTipo() + "'" +
            ", nombre='" + getNombre() + "'" +
            ", apellidos='" + getApellidos() + "'" +
            ", email='" + getEmail() + "'" +
            ", dni='" + getDni() + "'" +
            ", telefono='" + getTelefono() + "'" +
            "}";
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Usuario)) {
            return false;
        }
        Usuario usuario = (Usuario) o;
        return id == usuario.id && Objects.equals(userName, usuario.userName) && Objects.equals(password, usuario.password) && Objects.equals(tipo, usuario.tipo) && Objects.equals(nombre, usuario.nombre) && Objects.equals(apellidos, usuario.apellidos) && Objects.equals(email, usuario.email) && Objects.equals(dni, usuario.dni) && Objects.equals(telefono, usuario.telefono);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, userName, password, tipo, nombre, apellidos, email, dni, telefono);
    }



    


    
}