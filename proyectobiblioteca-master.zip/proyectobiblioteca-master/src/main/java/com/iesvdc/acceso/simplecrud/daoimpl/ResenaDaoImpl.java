package com.iesvdc.acceso.simplecrud.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;

import com.iesvdc.acceso.simplecrud.conexion.Conexion;
import com.iesvdc.acceso.simplecrud.dao.LibroDao;
import com.iesvdc.acceso.simplecrud.dao.ResenaDao;
import com.iesvdc.acceso.simplecrud.dao.UsuarioDao;
import com.iesvdc.acceso.simplecrud.model.Libro;
import com.iesvdc.acceso.simplecrud.model.Resena;
import com.iesvdc.acceso.simplecrud.model.Usuario;

public class ResenaDaoImpl implements ResenaDao {

    /*@Override
    public boolean create(Libro libro, int estrellas, String comentario, Usuario usuario,
            boolean anonimo, LocalDate fecha) {
        return libro.getIdLibro(), estrellas, comentario, usuario.getId(), anonimo, fecha;
    }*/

    @Override
    public boolean create(int libro, int estrellas, String comentario, int usuario,
    boolean anonimo, LocalDate fecha) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            String sql = 
                "INSERT INTO resena(idResena, libro, estrellas, comentario, usuario, anonimo, fecha) VALUES (NULL,?,?,?,?,?)";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setInt(1, libro);
            pstmt.setInt(2, estrellas);
            pstmt.setString(3, comentario);
            pstmt.setInt(4, usuario);
            pstmt.setBoolean(5, anonimo);
            pstmt.setString(6, fecha.toString());
            if (pstmt.executeUpdate() > 1) 
                resultado = true;
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  "+ex.getMessage());
        }
        return resultado;
    }

    @Override
    public boolean update(Resena oldResena, Resena newResena) {
        return update(oldResena.getIdReserva(), newResena);
    }

    @Override
    public boolean update(int oldResena, Resena newResena) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            String sql =

                "UPDATE FROM resena SET fecha=?, anonimo=?, usuario=?, comentario=?, estrellas=?, libro=? WHERE idResena=?";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setString(1, newResena.getFecha().toString());
            pstmt.setBoolean(2, newResena.isAnonimo());
            pstmt.setInt(3, newResena.getUsuario().getId());
            pstmt.setString(4, newResena.getComentario().toString());
            pstmt.setInt(5, newResena.getEstrellas());
            pstmt.setInt(6, newResena.getLibro().getIdLibro());
            pstmt.setInt(7, oldResena);
            if (pstmt.executeUpdate() > 1) 
                resultado = true;
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  "+ex.getMessage());
        }
        return resultado;
    }

    @Override
    public Resena findOne(int idResena) {
        Resena resena;

        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;

        LibroDao libroDao = new LibroDaoImpl();
        Libro libro;
 
        int estrellas;

        String comentario;
 
        boolean anonimo;
    
        LocalDate fecha;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM resena WHERE id=?";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ps.setInt(1, idResena);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                libro = libroDao.findById(rs.getInt("libro"));
                estrellas = rs.getInt("estrellas");
                comentario = rs.getString("comentario");
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                anonimo = rs.getBoolean("anonimo");
                fecha = LocalDate.parse(rs.getString("fecha"));
                resena = new Resena(
                    rs.getInt("id"),
                    libro,
                    estrellas,
                    comentario,
                    usuario,
                    anonimo,
                    fecha
                );
            } else {
                resena = new Resena();
            }
            conexion.destroy();
        } catch (SQLException se) {
            resena = null;
        }
        return resena;
    }

    @Override
    public List<Resena> findAll() {
        Resena resena;
        List<Resena> resenas = new ArrayList<Resena>();

        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;

        LibroDao libroDao = new LibroDaoImpl();
        Libro libro; 

        int estrellas;

        String comentario;
 
        boolean anonimo;
    
        LocalDate fecha;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM resena";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                libro = libroDao.findById(rs.getInt("libro"));
                estrellas = rs.getInt("estrellas");
                comentario = rs.getString("comentario");
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                anonimo = rs.getBoolean("anonimo");
                fecha = LocalDate.parse(rs.getString("fecha"));
                resena = new Resena(
                    rs.getInt("id"),
                    libro,
                    estrellas,
                    comentario,
                    usuario,
                    anonimo,
                    fecha
                );
                resenas.add(resena);
            } 
            conexion.destroy();
        } catch (SQLException se) {
            resenas = null;
        }
        return resenas;
    }

    @Override
    public List<Resena> findByLibro(Libro libro) {
        Resena resena;
        List<Resena> resenas = new ArrayList<Resena>();

        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;

        LibroDao libroDao = new LibroDaoImpl();
         

        int estrellas;

        String comentario;
 
        boolean anonimo;
    
        LocalDate fecha;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT resena.* FROM resena, libro "+
                " WHERE resena.libro=libro.id AND libro=?";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ps.setInt(1, libro.getIdLibro());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                libro = libroDao.findById(rs.getInt("libro"));
                estrellas = rs.getInt("estrellas");
                comentario = rs.getString("comentario");
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                anonimo = rs.getBoolean("anonimo");
                fecha = LocalDate.parse(rs.getString("fecha"));
                resena = new Resena(
                    rs.getInt("id"),
                    libro,
                    estrellas,
                    comentario,
                    usuario,
                    anonimo,
                    fecha
                );
                resenas.add(resena);
            } 
            conexion.destroy();
        } catch (SQLException se) {
            resenas = null;
        }
        return resenas;
    }

    @Override
    public List<Resena> findByDate(LocalDate fecha) {
        Resena resena;
        List<Resena> resenas = new ArrayList<Resena>();

        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;

        LibroDao libroDao = new LibroDaoImpl();

        Libro libro;
         

        int estrellas;

        String comentario;
 
        boolean anonimo;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM resena WHERE fecha=?";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ps.setString(1, fecha.toString());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                libro = libroDao.findById(rs.getInt("libro"));
                estrellas = rs.getInt("estrellas");
                comentario = rs.getString("comentario");
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                anonimo = rs.getBoolean("anonimo");
                fecha = LocalDate.parse(rs.getString("fecha"));
                resena = new Resena(
                    rs.getInt("id"),
                    libro,
                    estrellas,
                    comentario,
                    usuario,
                    anonimo,
                    fecha
                );
                resenas.add(resena);
            } 
            conexion.destroy();
        } catch (SQLException se) {
            resenas = null;
        }
        return resenas;
    }

    @Override
    public List<Resena> findByUsuario(Usuario usuario) {
        Resena resena;
        List<Resena> resenas = new ArrayList<Resena>();

        UsuarioDao usuarioDao = new UsuarioDaoImpl();

        LibroDao libroDao = new LibroDaoImpl();
        Libro libro;
         

        int estrellas;

        String comentario;
 
        boolean anonimo;
    
        LocalDate fecha;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT resena.* FROM resena, usuario "+
                " WHERE resena.usuario=usuario.id AND usuario=?";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ps.setInt(1, usuario.getId());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                libro = libroDao.findById(rs.getInt("libro"));
                estrellas = rs.getInt("estrellas");
                comentario = rs.getString("comentario");
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                anonimo = rs.getBoolean("anonimo");
                fecha = LocalDate.parse(rs.getString("fecha"));
                resena = new Resena(
                    rs.getInt("id"),
                    libro,
                    estrellas,
                    comentario,
                    usuario,
                    anonimo,
                    fecha
                );
                resenas.add(resena);
            } 
            conexion.destroy();
        } catch (SQLException se) {
            resenas = null;
        }
        return resenas;
    }

    @Override
    public boolean delete(int resena) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            String sql = 
                "DELETE FROM resena WHERE id=?";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);

            pstmt.setInt(1, resena);
            if (pstmt.executeUpdate() > 1) 
                resultado = true;
            pstmt.close();
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  "+ex.getMessage());
        }
        return resultado;
    }

    @Override
    public boolean delete(Resena resena) {
        return delete(resena.getIdReserva());
    }

    
    
}
