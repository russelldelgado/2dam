
package com.iesvdc.acceso.simplecrud.controller.service;

import com.iesvdc.acceso.simplecrud.dao.*;
import com.iesvdc.acceso.simplecrud.daoimpl.*;
import com.iesvdc.acceso.simplecrud.model.*;

import jdk.nashorn.internal.objects.annotations.Getter;

import java.util.List;
import java.util.logging.Logger;

import javax.faces.annotation.RequestCookieMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * ReviewResource
 */
@Path("/api")
public class ResenaResource {

    @GET
    @Path("resena")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getResenas() {
        ResenaDao resenaDao = new ResenaDaoImpl();
        List<Resena> resenas;
        try {
            resenas = resenaDao.findAll();
            return Response.ok(resenas).build();
        } catch (Exception e) {
            Logger.getLogger(e.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }

    }

    @GET
    @Path("resena/{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getResenaById(@PathParam("id") String id) {
        ResenaDao resenaDao = new ResenaDaoImpl();
        Resena resena;
        try {
            resena = resenaDao.findOne(Integer.parseInt(id));
            return Response.ok(resena).build();
        } catch (Exception e) {
            Logger.getLogger(e.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    /*
    @PUT
    @Path("resena/{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response updateResena(@PathParam("id") Resena oldResena, Resena newResena) {
        ResenaDao resenaDao = new ResenaDaoImpl();
        try {
            if (resenaDao.update(oldResena, newResena)) {
                return Response.status(200).entity(newResena).build();
            }
        } catch (Exception e) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(oldResena).build();
        }
        return Response.status(Status.NOT_FOUND).entity(oldResena).build();
    }
    */

    @PUT
    @Path("resena/{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response updateResena(@PathParam("id") Integer oldResena, Resena newResena) {
        ResenaDao resenaDao = new ResenaDaoImpl();
        try {
            if (resenaDao.update(oldResena, newResena)) {
                return Response.status(200).entity(newResena).build();
            }
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(oldResena).build();
        }
        return Response.status(Status.NOT_FOUND).entity(oldResena).build();
    }

    @DELETE
    @Path("resena/{id}")
    public Response deleteResena(@PathParam("id") int id) {
        ResenaDao resenaDao = new ResenaDaoImpl();
        try {
            if (resenaDao.delete(id))
                return Response.status(200).entity(id).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(id).build();
        }
        return Response.status(Status.NOT_FOUND).entity(id).build();
    }
    
}