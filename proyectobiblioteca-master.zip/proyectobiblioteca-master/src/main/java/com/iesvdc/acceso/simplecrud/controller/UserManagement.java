package com.iesvdc.acceso.simplecrud.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
//import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import com.iesvdc.acceso.simplecrud.model.Usuario;
import com.iesvdc.acceso.simplecrud.conexion.*;

/**
 * UserManagement
 */
public class UserManagement extends HttpServlet {

        /**
         *
         */
        private static final long serialVersionUID = 1L;

        private Conexion conn;
        private Connection conexion;

        @Override
        public void init() throws ServletException {
                this.conn = new Conexion();
                this.conexion = conn.getConnection();
        }

        // findOne(id)
        @Override
        protected void doGet(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {
                resp.setContentType("application/json");
                PrintWriter out = resp.getWriter();
                String jsonObject = "{}";
                // buscamos en la base de datos el objeto y devolvemos sus datos

                String id = req.getRequestURI().substring(req.getContextPath().length());
                id = id.replace("/user/", "");
                jsonObject = "{salida: '" + id + "'}";

                // String id = req.getParameter("userid");

                
                try {
                
                String sql = "SELECT * FROM usuario WHERE id=?";

                PreparedStatement pstm = conexion.prepareStatement(sql);

                pstm.setInt(1, Integer.parseInt(id));

                ResultSet rs = pstm.executeQuery();

                if (rs.next()) {
                        String username = rs.getString("username");
                        String password = rs.getString("password");
                        String tipo = rs.getString("tipo");
                        String nombre = rs.getString("nombre");
                        String apellidos =rs.getString("apellidos");
                        String email = rs.getString("email");
                        String dni = rs.getString("dni");
                        String telefono = rs.getString("telefono");
                        // String id = rs.getString("id");
                        jsonObject = "{" + "\n" + "'id':'" + id + "'," + "\n" + "'username':'" + username + "'," + "\n"
                                + "'password':'" + password + "'," + "\n" + "'tipo':'" + tipo + "'," + "\n" 
                                + "'nombre':'" + nombre + "',\n" + "'apellidos':'" + apellidos + "',\n"
                                + "'email':'" + email + "',\n" + "'dni':'" + dni + "',\n" + "'telefono':'" 
                                + telefono + "'\n" + "}";

                }
                } catch (Exception ex) {
                resp.sendRedirect("/error.jsp");
                }
                out.print(jsonObject.replaceAll("'", "\""));
                out.flush();
        }

        // CREAR
        @Override
        protected void doPost(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                String usuario = req.getParameter("username");
                String password = req.getParameter("password");

                String tipo = req.getParameter("usuariotipo");
                String nombreUsuario = req.getParameter("nombre");
                String apellido = req.getParameter("apellido");
                String email = req.getParameter("email");
                String dni = req.getParameter("dni");
                String telefono = req.getParameter("telefono");

                System.out.println(usuario);
                System.out.println(password);
                System.out.println(tipo + "--" + nombreUsuario + "--" + apellido + "--" + email + "--" + dni + "--"
                                + telefono);

                try {
                        String sql = "INSERT INTO usuario(username,password,tipo,nombre,apellidos,email,dni,telefono) VALUES(?,?,?,?,?,?,?,?)";
                        // String sql = "INSERT INTO usuario (username,password) VALUES (?,?)";
                        PreparedStatement pstm = conexion.prepareStatement(sql);

                        pstm.setString(1, usuario);
                        pstm.setString(2, password);
                        pstm.setString(3, tipo);
                        pstm.setString(4, nombreUsuario);
                        pstm.setString(5, apellido);
                        pstm.setString(6, email);
                        pstm.setString(7, dni);
                        pstm.setString(8, telefono);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("USUARIO INSERTADO CORRECTAMENTE");
                        } else {
                                resp.getWriter().println("NO SE HA PODIDO INSERTAR EL USUARIO");
                        }
                        conexion.close();
                } catch (Exception e) {
                        resp.getWriter().println("ERROR");
                        resp.getWriter().println("No se ha podido insertar el usuario en la base de datos");
                }
                resp.sendRedirect("./privado/usuariosListar.jsp");

        }

        // BORRAR
        @Override
        protected void doDelete(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                int idUsuario = Integer.parseInt(req.getParameter("idUsuario"));
                System.out.println(" ID DEL USUARIO QUE VAMOS A BORRAR ES : " + idUsuario);
                String sql = "DELETE FROM usuario WHERE id=?";
                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                PreparedStatement pstm;
                try {
                        pstm = conexion.prepareStatement(sql);

                        pstm.setInt(1, idUsuario);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("ELIMINADO CORRECTAMENTE");
                                try {
                                        Thread.sleep(2000);
                                } catch (InterruptedException e) {
                                        e.printStackTrace();
                                }
                        } else {
                                throw new Error();
                        }
                        conexion.close();
                } catch (SQLException e) {
                        throw new Error();
                }
        }

        // ACTUALIZAR
        @Override
        protected void doPut(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {
                Usuario user = new Gson().fromJson(req.getReader(), Usuario.class);

                try {
                String sql = "UPDATE usuario SET username=?, password=?, tipo=?, nombre=?, apellidos=?, email=?, dni=?, telefono=? WHERE id=?";

                PreparedStatement pstm = conexion.prepareStatement(sql);

                pstm.setString(1, user.getUserName());
                pstm.setString(2, user.getPassword());
                pstm.setString(3, user.getTipo().toString());
                pstm.setString(4, user.getNombre());
                pstm.setString(5, user.getApellidos());
                pstm.setString(6, user.getEmail());
                pstm.setString(7, user.getDni());
                pstm.setString(8, user.getTelefono());
                pstm.setInt(9, user.getId());

                if (!(pstm.executeUpdate() > 0)){
                        resp.getWriter().println("No se ha podido insertar");
                }
                } catch (Exception ex) {
                resp.sendRedirect("error.jsp");
                }

                resp.sendRedirect(".");
        }

        public void destroy() {

                if (conexion != null)
                    try {
                        conexion.close();
                    } catch (SQLException e) {
                        
                    }
            }
}