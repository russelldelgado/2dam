package com.iesvdc.acceso.simplecrud.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.iesvdc.acceso.simplecrud.conexion.Conexion;
import com.iesvdc.acceso.simplecrud.dao.UsuarioDao;
import com.iesvdc.acceso.simplecrud.model.TipoUsuario;
import com.iesvdc.acceso.simplecrud.model.Usuario;

public class UsuarioDaoImpl implements UsuarioDao{

    @Override
    public boolean create(Usuario usuario) {
        boolean exito = true;
        try {
            //`username`, `password`, `tipo`,`nombre`, `apellidos`, `email`, `dni`, `telefono`

            Conexion conexion = new Conexion();
            String sql = "INSERT INTO usuario (username, password, tipo, nombre, apellidos, email, dni, telefono) VALUES (NULL,?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setString(1, usuario.getUserName());
            pstmt.setString(2, usuario.getPassword());
            pstmt.setString(3, usuario.getTipo().toString());
            pstmt.setString(4, usuario.getNombre());
            pstmt.setString(5, usuario.getApellidos());
            pstmt.setString(6, usuario.getEmail());
            pstmt.setString(7, usuario.getDni());
            pstmt.setString(8, usuario.getTelefono());
            pstmt.executeUpdate();
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  " + ex.getMessage());
            exito = false;
        }
        return exito;
    }


    @Override
    public Usuario findById(int id) {
        Usuario usuario;
        TipoUsuario tipo = null;
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM USUARIO WHERE id=?";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.getString("tipo") == "ALUMNO") {
                tipo = TipoUsuario.ALUMNO;
            } else if (rs.getString("tipo") == "PROFESOR") {
                tipo = TipoUsuario.PROFESOR;
            } else if (rs.getString("tipo") == "ADMINISTRADOR") {
                tipo = TipoUsuario.ADMINISTRADOR;
            }
            if (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id"), 
                    rs.getString("username"),
                    rs.getString("password"),
                    tipo,
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("email"),
                    rs.getString("dni"),
                    rs.getString("telefono"));
            } else {
                usuario = new Usuario();
            }
            rs.close();
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  " + ex.getMessage());
            usuario = new Usuario(); 
        }
        return usuario;
    }

    
    @Override
    public List<Usuario> findAll() {
        List<Usuario> usuarios = new ArrayList<Usuario>();
        Usuario usuario;
        TipoUsuario tipo = null;
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM USUARIO";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.getString("tipo") == "ALUMNO") {
                tipo = TipoUsuario.ALUMNO;
            } else if (rs.getString("tipo") == "PROFESOR") {
                tipo = TipoUsuario.PROFESOR;
            } else if (rs.getString("tipo") == "ADMINISTRADOR") {
                tipo = TipoUsuario.ADMINISTRADOR;
            }
            while (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id"), 
                    rs.getString("username"),
                    rs.getString("password"),
                    tipo,
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("email"),
                    rs.getString("dni"),
                    rs.getString("telefono"));
                usuarios.add(usuario);
            } 
            rs.close();
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  " + ex.getMessage());
        }
        return usuarios;
    }

    
    @Override
    public List<Usuario> findByUsername(String username) {
        List<Usuario> usuarios = new ArrayList<Usuario>();
        Usuario usuario;
        TipoUsuario tipo = null;
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM USUARIO WHERE username=?";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.getString("tipo") == "ALUMNO") {
                tipo = TipoUsuario.ALUMNO;
            } else if (rs.getString("tipo") == "PROFESOR") {
                tipo = TipoUsuario.PROFESOR;
            } else if (rs.getString("tipo") == "ADMINISTRADOR") {
                tipo = TipoUsuario.ADMINISTRADOR;
            }
            while (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id"), 
                    rs.getString("username"),
                    rs.getString("password"),
                    tipo,
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("email"),
                    rs.getString("dni"),
                    rs.getString("telefono"));
                usuarios.add(usuario);
            } 
            rs.close();
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  " + ex.getMessage());
        }
        return usuarios;
    }


    @Override
    public boolean update(Usuario oldUsuario, Usuario newUsuario) {
        return update(oldUsuario.getId(), newUsuario);
    }


    @Override
    public boolean update(int oldUsuario, Usuario newUsuario) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            PreparedStatement ps = conexion.getConnection().prepareStatement(
                "UPDATE FROM USUARIO SET username=?, password=?, tipo=?, nomrbe=?, apellidos=?, email=?, dni=?, telefono=? WHERE id=?");
            ps.setString(1, newUsuario.getUserName());
            ps.setString(2, newUsuario.getPassword());
            ps.setString(3, newUsuario.getTipo().toString());
            ps.setString(4, newUsuario.getNombre());
            ps.setString(5, newUsuario.getApellidos());
            ps.setString(6, newUsuario.getEmail());
            ps.setString(7, newUsuario.getDni());
            ps.setString(8, newUsuario.getTelefono());
            ps.setInt(9, oldUsuario);
            if (ps.executeUpdate() > 0) {
                resultado = true;
            }
        } catch (SQLException se) {
            System.out.println("ERROR:  " + se.getMessage());
        }
        return resultado;
    }

  
    @Override
    public boolean delete(Usuario usuario) {
        return delete(usuario.getId());
    }

   
    @Override
    public boolean delete(int usuario) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            PreparedStatement ps = conexion.getConnection().prepareStatement(
                "DELETE FROM USUARIO WHERE id=?");
            ps.setInt(1, usuario);
            if (ps.executeUpdate() > 0) {
                resultado = true;
            }
        } catch (SQLException se) {
            System.out.println("ERROR:  " + se.getMessage());
        }
        return resultado;
    }
}
