package com.iesvdc.acceso.simplecrud.dao;

import java.util.List;

import com.iesvdc.acceso.simplecrud.model.Usuario;

public interface UsuarioDao {

    public boolean create(Usuario usuario);
    public Usuario findById(int id);
    public List<Usuario> findAll();
    public List<Usuario> findByUsername(String username);
    public boolean update(Usuario oldUsuario, Usuario newUsuario);
    public boolean update(int oldUsuario, Usuario newUsuario);
    public boolean delete(Usuario usuario);
    public boolean delete(int usuario);
    
}
