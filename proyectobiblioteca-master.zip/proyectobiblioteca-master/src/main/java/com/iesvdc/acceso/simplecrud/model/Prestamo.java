package com.iesvdc.acceso.simplecrud.model;

import java.time.LocalDate;
import java.util.Objects;

public class Prestamo {

    int idPrestamo;
    LocalDate fechaPrestamo;
    LocalDate fechaDevolucion;
    Usuario usuario;
    Libro libro;
    int prorroga;
    Estado estado;

    public Prestamo() {
    }

    public Prestamo(LocalDate fechaPrestamo, LocalDate fechaDevolucion, Usuario usuario, Libro libro, int prorroga, Estado estado) {
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.usuario = usuario;
        this.libro = libro;
        this.prorroga = prorroga;
        this.estado = estado;
    }

    public Prestamo(int idPrestamo, LocalDate fechaPrestamo, LocalDate fechaDevolucion, Usuario usuario, Libro libro, int prorroga, Estado estado) {
        this.idPrestamo = idPrestamo;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.usuario = usuario;
        this.libro = libro;
        this.prorroga = prorroga;
        this.estado = estado;
    }

    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(LocalDate fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public int getProrroga() {
        return prorroga;
    }

    public void setProrroga(int prorroga) {
        this.prorroga = prorroga;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "idPrestamo=" + idPrestamo +
                ", fechaPrestamo=" + fechaPrestamo +
                ", fechaDevolucion=" + fechaDevolucion +
                ", usuario=" + usuario +
                ", prorroga=" + prorroga +
                ", estado=" + estado +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Prestamo prestamo = (Prestamo) o;
        return idPrestamo == prestamo.idPrestamo && prorroga == prestamo.prorroga && Objects.equals(fechaPrestamo, prestamo.fechaPrestamo) && Objects.equals(fechaDevolucion, prestamo.fechaDevolucion) && Objects.equals(usuario, prestamo.usuario) && estado == prestamo.estado;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPrestamo, fechaPrestamo, fechaDevolucion, usuario, prorroga, estado);
    }
}
