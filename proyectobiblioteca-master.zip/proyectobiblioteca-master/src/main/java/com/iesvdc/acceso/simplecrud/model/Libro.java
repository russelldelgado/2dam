package com.iesvdc.acceso.simplecrud.model;

import java.util.Objects;

public class Libro {

    int idLibro;
    String editorial;
    String titulo;
    int anoPublicacion;
    int paginas;
    String isbn;

    public Libro(int idLibro, String editorial, String titulo, int anoPublicacion, int paginas, String isbn) {
        this.idLibro = idLibro;
        this.editorial = editorial;
        this.titulo = titulo;
        this.anoPublicacion = anoPublicacion;
        this.paginas = paginas;
        this.isbn = isbn;
    }

    public Libro(String editorial, String titulo, int anoPublicacion, int paginas, String isbn) {
        this.editorial = editorial;
        this.titulo = titulo;
        this.anoPublicacion = anoPublicacion;
        this.paginas = paginas;
        this.isbn = isbn;
    }

    public Libro() {
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnoPublicacion() {
        return anoPublicacion;
    }

    public void setAnoPublicacion(int anoPublicacion) {
        this.anoPublicacion = anoPublicacion;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Override
    public String toString() {
        return "Libro{" +
                "idLibro=" + idLibro +
                ", editorial='" + editorial + '\'' +
                ", titulo='" + titulo + '\'' +
                ", anoPublicacion=" + anoPublicacion +
                ", paginas=" + paginas +
                ", isbn='" + isbn + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Libro libro = (Libro) o;
        return idLibro == libro.idLibro && anoPublicacion == libro.anoPublicacion && paginas == libro.paginas && Objects.equals(editorial, libro.editorial) && Objects.equals(titulo, libro.titulo) && Objects.equals(isbn, libro.isbn);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLibro, editorial, titulo, anoPublicacion, paginas, isbn);
    }
}
