package com.iesvdc.acceso.simplecrud.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
//import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.iesvdc.acceso.simplecrud.conexion.Conexion;
import com.iesvdc.acceso.simplecrud.model.Prestamo;

/**
 * LoanManagement
 */
public class LoanManagement extends HttpServlet {

        /**
         *
         */
        
        private static final long serialVersionUID = 1L;

        
        private Conexion conn;
        private Connection conexion;

        @Override
        public void init() throws ServletException {
                this.conn = new Conexion();
                this.conexion = conn.getConnection();
        }

        // findOne(id)
        @Override
        protected void doGet(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                resp.setContentType("application/json");
                PrintWriter out = resp.getWriter();
                String jsonObject = "{}";
                // buscamos en la base de datos el objeto y devolvemos sus datos

                String id = req.getRequestURI().substring(req.getContextPath().length());
                id = id.replace("/loan/", "");
                jsonObject = "{salida: '" + id + "'}";
                
                try {
                
                        String sql = "SELECT * FROM prestamo WHERE id=?";

                        PreparedStatement pstm = conexion.prepareStatement(sql);

                        pstm.setInt(1, Integer.parseInt(id));

                        ResultSet rs = pstm.executeQuery();

                        /*if (rs.next()) {
                                String estrellas = rs.getString("estrellas");
                                String comentario = rs.getString("comentario");
                                String fecha = rs.getString("fecha");
                                String usuario = rs.getString("usuario");
                                
                                jsonObject = "{" + "\n" + "'id':'" + id + "'," + "\n" + "'estrellas':'" + estrellas + "'," + "\n"
                                        + "'comentario':'" + comentario + "'," + "\n" + "'fecha':'" + fecha + "'," + "\n" 
                                        + "'usuario':'" + usuario + "'\n" + "}";

                        }*/

                        if (rs.next()) {
                                String inicio = rs.getString("inicio");
                                String fin = rs.getString("fin");
                                int prorroga = rs.getInt("prorroga");
                                int usuario = rs.getInt("usuario");
                                int libro = rs.getInt("libro");
                                String estado = rs.getString("estado");
                                
                                jsonObject = "{" + "\n" + "'id':'" + id + "'," + "\n" + "'inicio':'" + inicio + "'," + "\n"
                                        + "'fin':'" + fin + "'," + "\n" + "'prorroga':'" + prorroga + "'," + "\n" 
                                        + "'libro':'" + libro + "'," + "\n" + "'estado':'" + estado + "'," + "\n"
                                        + "'usuario':'" + usuario + "'\n" + "}";

                        }
                } catch (Exception ex) {
                resp.sendRedirect("/error.jsp");
                }
                out.print(jsonObject.replaceAll("'", "\""));
                out.flush();
        }

        // CREAR
        @Override
        protected void doPost(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                String inicio = req.getParameter("inicio");
                String fin = req.getParameter("fin");
                int prorroga = Integer.parseInt(req.getParameter("prorroga"));
                int idUsuario = Integer.parseInt(req.getParameter("usuario"));
                int idLibro = Integer.parseInt(req.getParameter("libro"));
                String estado = req.getParameter("estado");
                System.out.println(inicio + "--" + fin + "--" + prorroga + "--" + idUsuario + "--" + "" + idLibro + "--"
                                + estado);

                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                String sql = "INSERT INTO prestamo (inicio,fin,prorroga,usuario,libro,estado) VALUES (?,?,?,?,?,?)";

                try {
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        pstm.setString(1, inicio);
                        pstm.setString(2, fin);
                        pstm.setInt(3, prorroga);
                        pstm.setInt(4, idUsuario);
                        pstm.setInt(5, idLibro);
                        pstm.setString(6, estado);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("se ha reservado correctamente el libro");
                        } else {
                                resp.getWriter().println("no se ha podido realizar la reserva vuelvalo a intentar");
                        }
                        conexion.close();
                } catch (SQLException e) {
                        throw new Error();
                }
                resp.sendRedirect("./privado/prestamosListar.jsp");

        }

        // BORRAR
        @Override
        protected void doDelete(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                int idPrestamo = Integer.parseInt(req.getParameter("idPrestamo"));
                System.out.println(" ID DE LA RESEÑA  QUE VAMOS A BORRAR ES : " + idPrestamo);
                String sql = "DELETE FROM prestamo WHERE id=?";
                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                try {
                        PreparedStatement pstm = conexion.prepareStatement(sql);

                        pstm.setInt(1, idPrestamo);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("ELIMINADO CORRECTAMENTE");
                                try {
                                        Thread.sleep(2000);
                                } catch (InterruptedException e) {
                                        e.printStackTrace();
                                }
                        } else {
                                throw new Error();
                        }
                        conexion.close();
                } catch (SQLException e) {
                        throw new Error();
                }
        }

        // ACTUALIZAR
        @Override
        protected void doPut(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {
                Prestamo prestamo = new Gson().fromJson(req.getReader(), Prestamo.class);

                try {
                        String sql = "UPDATE prestamo SET inicio=?, fin=?, prorroga=?, usuario=?, libro=?, estado=? WHERE id=?";
                
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        
                        pstm.setString(1, prestamo.getFechaPrestamo().toString());
                        pstm.setString(2, prestamo.getFechaDevolucion().toString());
                        pstm.setInt(3, prestamo.getProrroga());
                        pstm.setInt(4, prestamo.getUsuario().getId());
                        pstm.setInt(5, prestamo.getLibro().getIdLibro());
                        pstm.setString(6, prestamo.getEstado().toString());
                        pstm.setInt(7, prestamo.getIdPrestamo());
                        
                        if (!(pstm.executeUpdate() > 0)){
                                resp.getWriter().println("No se ha podido insertar");
                        }
                } catch (Exception ex) {
                        resp.sendRedirect("error.jsp");
                }
                
                resp.sendRedirect(".");
        }

        public void destroy() {

                if (conexion != null)
                    try {
                        conexion.close();
                    } catch (SQLException e) {
                        
                    }
        }
}