package com.iesvdc.acceso.simplecrud.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
//import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import com.iesvdc.acceso.simplecrud.conexion.*;
import com.iesvdc.acceso.simplecrud.model.Resena;

/**
 * ReviewManagement
 */
public class ReviewManagement extends HttpServlet {

        /**
         *
         */
        private static final long serialVersionUID = 1L;

        private Conexion conn;
        private Connection conexion;

        @Override
        public void init() throws ServletException {
                this.conn = new Conexion();
                this.conexion = conn.getConnection();
        }

        // findOne(id)
        @Override
        protected void doGet(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                resp.setContentType("application/json");
                PrintWriter out = resp.getWriter();
                String jsonObject = "{}";
                // buscamos en la base de datos el objeto y devolvemos sus datos

                String id = req.getRequestURI().substring(req.getContextPath().length());
                id = id.replace("/review/", "");
                jsonObject = "{salida: '" + id + "'}";
                
                try {
                
                        String sql = "SELECT * FROM resena WHERE id=?";

                        PreparedStatement pstm = conexion.prepareStatement(sql);

                        pstm.setInt(1, Integer.parseInt(id));

                        ResultSet rs = pstm.executeQuery();

                        if (rs.next()) {
                                String estrellas = rs.getString("estrellas");
                                String comentario = rs.getString("comentario");
                                String fecha = rs.getString("fecha");
                                String usuario = rs.getString("usuario");
                                
                                jsonObject = "{" + "\n" + "'id':'" + id + "'," + "\n" + "'estrellas':'" + estrellas + "'," + "\n"
                                        + "'comentario':'" + comentario + "'," + "\n" + "'fecha':'" + fecha + "'," + "\n" 
                                        + "'usuario':'" + usuario + "'\n" + "}";

                        }
                } catch (Exception ex) {
                resp.sendRedirect("/error.jsp");
                }
                out.print(jsonObject.replaceAll("'", "\""));
                out.flush();
        }

        // CREAR
        @Override
        protected void doPost(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                int usuario = Integer.parseInt(req.getParameter("usuario"));
                String fechaResena = req.getParameter("fechaDeResena");
                String comentario = req.getParameter("comentario");
                int estrellas = Integer.parseInt(req.getParameter("estrellas"));

                System.out.println(usuario + "--" + fechaResena + "--" + comentario + "--" + estrellas);

                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                String sql = "INSERT INTO resena(estrellas,comentario,fecha,usuario) VALUES (?,?,?,?)";

                try {
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        pstm.setInt(1, estrellas);
                        pstm.setInt(4, usuario);
                        pstm.setString(2, comentario);
                        pstm.setString(3, fechaResena);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("reseña insertada correctamente");
                        } else {
                                resp.getWriter().println("no se ha podido realizar la reseña correctamente");
                        }
                        conexion.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }

                resp.sendRedirect("./privado/resenasListar.jsp");

        }

        // BORRAR
        @Override
        protected void doDelete(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                int idResena = Integer.parseInt(req.getParameter("idResena"));
                System.out.println(" ID DE LA RESEÑA  QUE VAMOS A BORRAR ES : " + idResena);
                String sql = "DELETE FROM resena WHERE id=?";
                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                try {
                        PreparedStatement pstm = conexion.prepareStatement(sql);

                        pstm.setInt(1, idResena);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("ELIMINADO CORRECTAMENTE");
                                try {
                                        Thread.sleep(2000);
                                } catch (InterruptedException e) {
                                        e.printStackTrace();
                                }
                        } else {
                                throw new Error();
                        }
                        conexion.close();
                } catch (SQLException e) {
                        throw new Error();
                }

        }

        // ACTUALIZAR
        @Override
        protected void doPut(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {
                Resena resena = new Gson().fromJson(req.getReader(), Resena.class);

                try {
                        String sql = "UPDATE resena SET estrellas=?, comentario=?, fecha=?, usuario=? WHERE id=?";
                
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        
                        pstm.setInt(1, resena.getEstrellas());
                        pstm.setString(2, resena.getComentario());
                        pstm.setString(3, resena.getFecha().toString());
                        pstm.setInt(4, resena.getUsuario().getId());
                        pstm.setInt(5, resena.getIdReserva());
                        
                        if (!(pstm.executeUpdate() > 0)){
                                resp.getWriter().println("No se ha podido insertar");
                        }
                } catch (Exception ex) {
                        resp.sendRedirect("error.jsp");
                }
                
                resp.sendRedirect(".");
        }

        public void destroy() {

                if (conexion != null)
                    try {
                        conexion.close();
                    } catch (SQLException e) {
                        
                    }
        }
}