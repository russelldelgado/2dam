package com.iesvdc.acceso.simplecrud.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
//import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.iesvdc.acceso.simplecrud.conexion.Conexion;
//import com.mysql.cj.xdevapi.PreparableStatement;
import com.iesvdc.acceso.simplecrud.model.Libro;

/**
 * BookManagement
 */
public class BookManagement extends HttpServlet {

        private Conexion conn;
        private Connection conexion;

        @Override
        public void init() throws ServletException {
                this.conn = new Conexion();
                this.conexion = conn.getConnection();
        }

        private static final long serialVersionUID = 1L;

        // findOne(id)
        
        @Override
        protected void doGet(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                resp.setContentType("application/json");
                PrintWriter out = resp.getWriter();
                String jsonObject = "{}";
                // buscamos en la base de datos el objeto y devolvemos sus datos

                String id = req.getRequestURI().substring(req.getContextPath().length());
                id = id.replace("/book/", "");
                jsonObject = "{salida: '" + id + "'}";
                
                try {
                
                        String sql = "SELECT * FROM libro WHERE id=?";

                        PreparedStatement pstm = conexion.prepareStatement(sql);

                        pstm.setInt(1, Integer.parseInt(id));

                        ResultSet rs = pstm.executeQuery();

                        if (rs.next()) {
                                String estrellas = rs.getString("editorial");
                                String comentario = rs.getString("titulo");
                                String fecha = rs.getString("anoPublicacion");
                                String usuario = rs.getString("isbn");
                                
                                jsonObject = "{" + "\n" + "'id':'" + id + "'," + "\n" + "'estrellas':'" + estrellas + "'," + "\n"
                                        + "'comentario':'" + comentario + "'," + "\n" + "'fecha':'" + fecha + "'," + "\n" 
                                        + "'usuario':'" + usuario + "'\n" + "}";

                        }
                } catch (Exception ex) {
                resp.sendRedirect("/error.jsp");
                }
                out.print(jsonObject.replaceAll("'", "\""));
                out.flush();
        }

        // CREAR
        @Override
        protected void doPost(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                String editorial = req.getParameter("editorial");
                String titulo = req.getParameter("titulo");
                int anoPublicacion = Integer.parseInt(req.getParameter("anopublicacion"));
                String isbn = req.getParameter("isbn");

                System.out.println(editorial + "--" + titulo + "--" + anoPublicacion + "--" + isbn);

                String sql = "INSERT INTO libro (editorial,titulo,anoPublicacion,isbn) VALUES (?,?,?,?)";
                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                try {
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        pstm.setString(1, editorial);
                        pstm.setString(2, titulo);
                        pstm.setInt(3, anoPublicacion);
                        pstm.setString(4, isbn);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("libro ejecutado correctamente");
                        } else {
                                resp.getWriter().println("error al insertar el usuario ");

                        }
                        conexion.close();

                } catch (SQLException e) {
                        // e.printStackTrace();
                        throw new Error();
                }
                resp.sendRedirect("./privado/librosReads.jsp");
        }

        // BORRAR
        @Override
        protected void doDelete(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {

                int idLibro = Integer.parseInt(req.getParameter("idLibro"));
                // System.out.println(" ID DEL LIBRO QUE VAMOS A BORRAR : " + idLibro);
                String sql = "DELETE FROM libro WHERE id=?";
                Conexion conn = new Conexion();
                Connection conexion = conn.getConnection();

                try {
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        pstm.setInt(1, idLibro);

                        if (pstm.executeUpdate() > 0) {
                                resp.getWriter().println("ELIMINADO CORRECTAMENTE");
                                try {
                                        Thread.sleep(2000);
                                } catch (InterruptedException e) {
                                        e.printStackTrace();
                                }
                        } else {
                                throw new Error();
                        }
                        conexion.close();
                } catch (SQLException e) {
                        throw new Error();
                }

        }

        // ACTUALIZAR
        @Override
        protected void doPut(HttpServletRequest req, // parámetros de la petición
                        HttpServletResponse resp) // respuesta que genero
                        throws ServletException, IOException {
                Libro libro = new Gson().fromJson(req.getReader(), Libro.class);

                try {
                        String sql = "UPDATE libro SET editorial=?, titulo=?, anoPublicacion=?, isbn=? WHERE id=?";
                
                        PreparedStatement pstm = conexion.prepareStatement(sql);
                        
                        pstm.setString(1, libro.getEditorial());
                        pstm.setString(2, libro.getTitulo());
                        pstm.setInt(3, libro.getAnoPublicacion());
                        pstm.setString(4, libro.getIsbn());
                        pstm.setInt(5, libro.getIdLibro());
                        
                        if (!(pstm.executeUpdate() > 0)){
                                resp.getWriter().println("No se ha podido insertar");
                        }
                } catch (Exception ex) {
                        resp.sendRedirect("error.jsp");
                }
                
                resp.sendRedirect(".");
        }
}

/**
 * ejemplo de coneccion
 * 
 * String username = req.getParameter("username"); String password =
 * req.getParameter("password"); String email = req.getParameter("email");
 * 
 * try { String sql = "INSERT INTO usuario (username,password,email)
 * VALUES(?,?,?)";
 * 
 * PreparedStatement pstm = conexion.prepareStatement(sql);
 * 
 * pstm.setString(1, username); pstm.setString(2, password); pstm.setString(3,
 * email);
 * 
 * if (pstm.executeUpdate() > 0) { resp.getWriter().println("Usuario
 * insertado"); } else { resp.getWriter().println("No se ha podido insertar"); }
 * 
 * } catch (Exception ex) { resp.sendRedirect("error.jsp"); //
 * resp.getWriter().println(ex.getMessage()); //
 * resp.getWriter().println(ex.getLocalizedMessage()); //
 * resp.getWriter().println("Imposible conectar a la BBDD"); }
 * 
 * resp.sendRedirect(".");
 * 
 * 
 * 
 * 
 * 
 * <-----------------------ejemplo reserva-------------------------------->
 * String username = req.getParameter("username"); String password =
 * req.getParameter("password"); String email = req.getParameter("email");
 * 
 * Connection conexion; PreparedStatement pstm; String jdbcURL;
 * 
 * jdbcURL = JDBC_MYSQL_GESTION_RESERVAS;
 * 
 * try { Class.forName("com.mysql.cj.jdbc.Driver"); conexion =
 * DriverManager.getConnection(jdbcURL, "root", "example");
 * 
 * String sql = "INSERT INTO usuario (username,password,email) VALUES(?,?,?)";
 * 
 * pstm = conexion.prepareStatement(sql);
 * 
 * pstm.setString(1, username); pstm.setString(2, password); pstm.setString(3,
 * email);
 * 
 * if (pstm.executeUpdate() >0) { resp.getWriter().println("Usuario insertado");
 * } else { resp.getWriter().println("No se ha podido insertar"); }
 * 
 * conexion.close(); } catch (Exception ex) {
 * resp.getWriter().println(ex.getMessage());
 * resp.getWriter().println(ex.getLocalizedMessage()); //
 * resp.getWriter().println("Imposible conectar a la BBDD"); }
 * 
 * resp.sendRedirect(".");
 * 
 * <-----------------------------ejemplo instalacion -------------------------->
 * String name = req.getParameter("name");
 * 
 * Conexion conn = new Conexion(); Connection conexion = conn.getConnection();
 * PreparedStatement pstm; String jdbcURL;
 * 
 * 
 * try {
 * 
 * String sql = "INSERT INTO instalacion (nombre) VALUES(?)";
 * 
 * pstm = conexion.prepareStatement(sql);
 * 
 * pstm.setString(1, name);
 * 
 * if (pstm.executeUpdate() > 0) { resp.getWriter().println("Instalación
 * insertada"); } else { resp.getWriter().println("No se ha podido insertar"); }
 * 
 * conexion.close(); } catch (Exception ex) {
 * resp.getWriter().println(ex.getMessage());
 * resp.getWriter().println(ex.getLocalizedMessage()); //
 * resp.getWriter().println("Imposible conectar a la BBDD"); }
 * 
 * resp.sendRedirect("/privado/instalacionRead.jsp");
 * 
 * 
 * <--------------------------------ejemplo horario--------------->
 * 
 * @Override protected void doPost(HttpServletRequest req, // parámetros de la
 *           petición HttpServletResponse resp) // respuesta que genero throws
 *           ServletException, IOException {
 * 
 *           String instalacion = req.getParameter("instalacion"); String inicio
 *           = req.getParameter("inicio"); String fin = req.getParameter("fin");
 *           try { Conexion con = new Conexion(); String sql = "INSERT INTO
 *           `horario` (`instalacion`, `inicio`, `fin`) "+ " VALUES (?, ?, ?);";
 *           PreparedStatement ps = con.getConnection().prepareStatement(sql);
 *           ps.setInt(1, Integer.parseInt(instalacion)); ps.setString(2,
 *           inicio); ps.setString(3, fin); ps.executeUpdate(); con.destroy();
 *           resp.sendRedirect("privado/horarioRead.jsp"); } catch (Exception
 *           e){ resp.setStatus(409); } }
 */