package com.iesvdc.acceso.simplecrud.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;


import com.iesvdc.acceso.simplecrud.conexion.Conexion;
import com.iesvdc.acceso.simplecrud.dao.PrestamoDao;
import com.iesvdc.acceso.simplecrud.dao.UsuarioDao;
import com.iesvdc.acceso.simplecrud.dao.LibroDao;
import com.iesvdc.acceso.simplecrud.daoimpl.UsuarioDaoImpl;
import com.iesvdc.acceso.simplecrud.daoimpl.LibroDaoImpl;
import com.iesvdc.acceso.simplecrud.model.Libro;
import com.iesvdc.acceso.simplecrud.model.Prestamo;
import com.iesvdc.acceso.simplecrud.model.Resena;
import com.iesvdc.acceso.simplecrud.model.Usuario;
import com.iesvdc.acceso.simplecrud.model.Estado;

public class PrestamoDaoImpl implements PrestamoDao {
    

    @Override
    public boolean create(LocalDate fechaPrestamo, LocalDate fechaDevolucion, int usuario, int prorroga, Estado estado) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            String sql = 
                "INSERT INTO prestamo(idPrestamo, fechaPrestamo, fechaDevolucion, usuario, ejemplar, prorroga, estado ) VALUES (NULL,?,?,?,?,?)";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setString(1, fechaPrestamo.toString());
            pstmt.setString(2, fechaDevolucion.toString());
            pstmt.setInt(3, usuario);
            pstmt.setInt(4, prorroga);
            pstmt.setString(5, estado.toString());
            
            if (pstmt.executeUpdate() > 1) 
                resultado = true;
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  "+ex.getMessage());
        }
        return resultado;
    }

    @Override
    public boolean update(Prestamo oldPrestamo, Prestamo newPrestamo) {
        return update(oldPrestamo.getIdPrestamo(), newPrestamo);
    }

    @Override
    public boolean update(int oldPrestamo, Prestamo newPrestamo) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            // NO se puede actualizar el ID porque es un autoincrement.
            String sql = 
                "UPDATE FROM prestamo SET inicio=?, fin=?, prorroga=?, usuario=?, libro=?, estado=? WHERE id=?";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);
            pstmt.setString(2, newPrestamo.getFechaPrestamo().toString());
            pstmt.setString(3, newPrestamo.getFechaDevolucion().toString());
            pstmt.setInt(4, newPrestamo.getProrroga());
            pstmt.setInt(5, newPrestamo.getUsuario().getId());
            pstmt.setInt(6, newPrestamo.getLibro().getIdLibro());
            pstmt.setString(7, newPrestamo.getEstado().toString());
            pstmt.setInt(8, oldPrestamo);
            if (pstmt.executeUpdate() > 1) 
                resultado = true;
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  "+ex.getMessage());
        }
        return resultado;
    }

    @Override
    public Prestamo findOne(int idPrestamo) {
        Prestamo prestamo;

        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;

        LibroDao libroDao = new LibroDaoImpl();
        Libro libro;

        LocalDate inicio;
        LocalDate fin;
        int prorroga;
        Estado estado = null;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM prestamo WHERE id=?";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ps.setInt(1, idPrestamo);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                libro = libroDao.findById( rs.getInt("libro") );
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                inicio = LocalDate.parse(rs.getString("inicio"));
                fin = LocalDate.parse(rs.getString("fin"));
                prorroga = rs.getInt("prorroga");
                if (rs.getString("estado") == "BUENO") {
                    estado = Estado.BUENO;
                } else if (rs.getString("estado") == "MALO") {
                    estado = Estado.MALO;
                } else if (rs.getString("estado") == "EXCELENTE") {
                    estado = Estado.EXCELENTE;
                }
                prestamo = new Prestamo(
                    rs.getInt("id"),
                    inicio,
                    fin,
                    usuario,
                    libro,
                    prorroga,
                    estado
                );
            } else {
                prestamo = new Prestamo();
            }
            conexion.destroy();
        } catch (SQLException se) {
            prestamo = null;
        }
        return prestamo;
    }

    @Override
    public List<Prestamo> findAll() {
        List<Prestamo> prestamos = new ArrayList<Prestamo>();
        Prestamo prestamo;

        UsuarioDao usuarioDao = new UsuarioDaoImpl();
        Usuario usuario;

        LibroDao libroDao = new LibroDaoImpl();
        Libro libro;

        LocalDate inicio;
        LocalDate fin;
        int prorroga;
        Estado estado = null;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM prestamo";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                libro = libroDao.findById( rs.getInt("libro") );
                usuario = usuarioDao.findById( rs.getInt("usuario"));
                inicio = LocalDate.parse(rs.getString("inicio"));
                fin = LocalDate.parse(rs.getString("fin"));
                prorroga = rs.getInt("prorroga");
                if (rs.getString("estado") == "BUENO") {
                    estado = Estado.BUENO;
                } else if (rs.getString("estado") == "MALO") {
                    estado = Estado.MALO;
                } else if (rs.getString("estado") == "EXCELENTE") {
                    estado = Estado.EXCELENTE;
                }
                prestamo = new Prestamo(
                    rs.getInt("id"),
                    inicio,
                    fin,
                    usuario,
                    libro,
                    prorroga,
                    estado
                );
                prestamos.add(prestamo);
            } 
            conexion.destroy();
        } catch (SQLException se) {
            prestamos = null;
        }
        return prestamos;
    }

    @Override
    public List<Prestamo> findByUsuario(Usuario usuario) {
        List<Prestamo> prestamos = new ArrayList<Prestamo>();
        Prestamo prestamo;

        LibroDao libroDao = new LibroDaoImpl();
        Libro libro;

        LocalDate inicio;
        LocalDate fin;
        int prorroga;
        Estado estado = null;
        
        try {
            Conexion conexion = new Conexion();
            String sql = "SELECT * FROM reserva WHERE usuario=?";
            PreparedStatement ps = conexion.getConnection().prepareStatement(sql);
            ps.setInt(1, usuario.getId());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                libro = libroDao.findById( rs.getInt("libro") );
                // usuario = usuarioDao.findById( rs.getInt("usuario"));
                inicio = LocalDate.parse(rs.getString("inicio"));
                fin = LocalDate.parse(rs.getString("fin"));
                prorroga = rs.getInt("prorroga");
                if (rs.getString("estado") == "BUENO") {
                    estado = Estado.BUENO;
                } else if (rs.getString("estado") == "MALO") {
                    estado = Estado.MALO;
                } else if (rs.getString("estado") == "EXCELENTE") {
                    estado = Estado.EXCELENTE;
                }
                prestamo = new Prestamo(
                    rs.getInt("id"),
                    inicio,
                    fin,
                    usuario,
                    libro,
                    prorroga,
                    estado
                );
                prestamos.add(prestamo);
            } 
            conexion.destroy();
        } catch (SQLException se) {
            prestamos = null;
        }
        return prestamos;
    }

    @Override
    public boolean delete(int prestamo) {
        boolean resultado = false;
        try {
            Conexion conexion = new Conexion();
            String sql = 
                "DELETE FROM prestamo WHERE id=?";
            PreparedStatement pstmt = conexion.getConnection().prepareStatement(sql);

            pstmt.setLong(1, prestamo);
            if (pstmt.executeUpdate() > 1) 
                resultado = true;
            pstmt.close();
            conexion.destroy();
        } catch (SQLException ex) {
            System.out.println("ERROR:  "+ex.getMessage());
        }
        return resultado;
    }

    @Override
    public boolean delete(Prestamo prestamo) {
        return delete(prestamo.getIdPrestamo());
    }
}
