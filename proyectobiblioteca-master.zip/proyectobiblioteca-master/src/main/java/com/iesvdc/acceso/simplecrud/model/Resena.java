package com.iesvdc.acceso.simplecrud.model;

import java.time.LocalDate;
import java.util.Objects;

public class Resena {

    int idReserva;
    Libro libro;
    int estrellas;
    String comentario;
    Usuario usuario;
    boolean anonimo;
    LocalDate fecha;

    public Resena() {
    }

    public Resena(int idReserva, Libro libro, int estrellas, String comentario, Usuario usuario, boolean anonimo, LocalDate fecha) {
        this.idReserva = idReserva;
        this.libro = libro;
        this.estrellas = estrellas;
        this.comentario = comentario;
        this.usuario = usuario;
        this.anonimo = anonimo;
        this.fecha = fecha;
    }

    public Resena(Libro libro, int estrellas, String comentario, Usuario usuario, boolean anonimo, LocalDate fecha) {
        this.libro = libro;
        this.estrellas = estrellas;
        this.comentario = comentario;
        this.usuario = usuario;
        this.anonimo = anonimo;
        this.fecha = fecha;
    }

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public int getEstrellas() {
        return estrellas;
    }

    public void setEstrellas(int estrellas) {
        this.estrellas = estrellas;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public boolean isAnonimo() {
        return anonimo;
    }

    public void setAnonimo(boolean anonimo) {
        this.anonimo = anonimo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Reseña{" +
                "idReserva=" + idReserva +
                ", libro=" + libro +
                ", estrellas=" + estrellas +
                ", comentario='" + comentario + '\'' +
                ", usuario=" + usuario +
                ", anonimo=" + anonimo +
                ", fecha=" + fecha +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Resena resena = (Resena) o;
        return idReserva == resena.idReserva && estrellas == resena.estrellas && anonimo == resena.anonimo && Objects.equals(libro, resena.libro) && Objects.equals(comentario, resena.comentario) && Objects.equals(usuario, resena.usuario) && Objects.equals(fecha, resena.fecha);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idReserva, libro, estrellas, comentario, usuario, anonimo, fecha);
    }
}
