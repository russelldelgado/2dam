package com.iesvdc.acceso.simplecrud.controller.service;

import com.iesvdc.acceso.simplecrud.dao.*;
import com.iesvdc.acceso.simplecrud.daoimpl.*;
import com.iesvdc.acceso.simplecrud.model.*;

import jdk.nashorn.internal.objects.annotations.Getter;

import java.util.List;
import java.util.logging.Logger;

import javax.faces.annotation.RequestCookieMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * UsuarioResource
 */
@Path("/api")
public class LibroResource {

    @GET
    @Path("libro")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getLibros() {
        LibroDao libroDao = new LibroDaoImpl();
        List<Libro> libros;
        try {
            libros = libroDao.findAll();
            return Response.ok(libros).build();
        } catch (Exception e) {
            Logger.getLogger(e.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }

    }

    @GET
    @Path("libro/{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getLibroById(@PathParam("id") String id) {
        LibroDao libroDao = new LibroDaoImpl();
        Libro libro;
        try {
            libro = libroDao.findById(Integer.parseInt(id));
            return Response.ok(libro).build();
        } catch (Exception e) {
            Logger.getLogger(e.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("libro")
    public Response createLibro(Libro libro) {
        LibroDao libroDao = new LibroDaoImpl();
        try {
            if (libroDao.create(libro))
                return Response.status(200).entity(libro).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(500).entity(libro).build();
        }
        return Response.status(404).entity(libro).build();
    }

    @PUT
    @Path("libro/{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response updateLibro(@PathParam("id") Integer oldLibro, Libro newLibro) {
        LibroDao libroDao = new LibroDaoImpl();
        try {
            if (libroDao.update(oldLibro, newLibro)) {
                return Response.status(200).entity(newLibro).build();
            }
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(oldLibro).build();
        }
        return Response.status(Status.NOT_FOUND).entity(oldLibro).build();
    }

    @DELETE
    @Path("libro/{id}")
    public Response deleteUsuario(@PathParam("id") Integer id) {
        LibroDao libroDao = new LibroDaoImpl();
        try {
            if (libroDao.delete(id))
                return Response.status(200).entity(id).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(id).build();
        }
        return Response.status(Status.NOT_FOUND).entity(id).build();
    }
    
}