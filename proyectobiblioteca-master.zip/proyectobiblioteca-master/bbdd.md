# Creamos base de datos
```sql
DROP DATABASE IF EXISTS biblioteca;
CREATE DATABASE biblioteca CHARACTER SET utf16 COLLATE utf16_spanish_ci;

USE biblioteca;

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dni` varchar(9) NOT NULL,
  `telefono` varchar(20) NOT NULL
) ENGINE='InnoDB';

INSERT INTO `usuario` (`username`, `password`, `tipo`,`nombre`, `apellidos`, `email`, `dni`, `telefono`) VALUES
('ggarrioch0', 'NHeF9z', 'ALUMNO', 'Bawle', 'Gabriele', 'ggarrioch0@webs.com', '76477384T', '824-143-1655'),
('kwroath1', 'Z7Oi0P', 'ALUMNO', 'Aynscombe', 'Kimberlee', 'kwroath1@topsy.com', '77336784T', '574-707-2894'),
('asansbury2', 'zZPJC8e', 'ADMINISTRADOR', 'Fevier', 'Addia', 'asansbury2@flickr.com', '24977384T', '629-696-9660'),
('htunmore3', 'Cgy7QQD6', 'ALUMNO', 'Reichartz', 'Hynda', 'htunmore3@reddit.com', '25647784T', '464-730-7914'),
('lvinick4', 'n4Clcj3U', 'ADMINISTRADOR', 'D''Ambrogi', 'Leanora', 'lvinick4@independent.co.uk', '25987384T', '813-578-0560'),
('bflemyng5', 'IMzAnYD', 'ADMINISTRADOR', 'Blacksell', 'Brad', 'bflemyng5@meetup.com', '72349384T', '522-120-0058'),
('wsaer6', 'PiLtvJ', 'PROFESOR', 'Bourton', 'Wilton', 'wsaer6@aboutads.info', '24817384T', '541-347-4368'),
('oandreichik7', 'U79ZCD', 'PROFESOR', 'Boag', 'Odelle', 'oandreichik7@loc.gov', '25983404T', '437-686-4649'),
('hjeenes8', 'bRsOnEW0e', 'PROFESOR', 'Andrusyak', 'Hugibert', 'hjeenes8@youtube.com', '34827738T', '940-564-4876'),
('ggosnold9', '04PTKkf8KL', 'ALUMNO', 'Klimus', 'Greta', 'ggosnold9@ibm.com', '25649884T', '912-640-2547');


DROP TABLE IF EXISTS `libro`; 
CREATE TABLE `libro` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `editorial` varchar(12) NOT NULL,
  `titulo` varchar(40) NOT NULL,
  `anoPublicacion` int(4) NOT NULL,
  `isbn` VARCHAR(13) NOT NULL
) ENGINE='InnoDB';

INSERT INTO `libro` (`editorial`, `titulo`, `anoPublicacion`, `isbn`) VALUES
('HdLetsGo', 'Cómo ganar dinero en tres pasos', '1999', '8764384439293'),
('Enlacasa', 'Decoración para espacios diáfanos', '2016', '1444472839293'),
('Demaleta', 'Los mejores destinos de Roma', '2003', '9472859435582'),
('Surferos4K', 'Las olas más grandes del Atlántico', '2009', '9785283339293');


DROP TABLE IF EXISTS `prestamo`; 
CREATE TABLE `prestamo` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `inicio` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `prorroga` int(1),
  `usuario` int(11) NOT NULL,
  `libro` int(11) NOT NULL,
  `estado` varchar(12) NOT NULL
           CHECK( estado IN('BUENO','MALO', 'EXCELENTE') ),
  FOREIGN KEY (`usuario`) REFERENCES `usuario` (`id`),
  FOREIGN KEY (`libro`) REFERENCES `libro` (`id`)
) ENGINE='InnoDB';

INSERT INTO `prestamo` (`inicio`, `fin`, `prorroga`, `usuario`, `libro`, `estado`) VALUES
('2013-10-05 09:00:00','2013-10-25 09:00:00',	0, 4, 2, 'BUENO'),
('2019-08-14 09:00:00','2019-09-01 09:00:00',	1,	3, 4, 'BUENO'),
('2020-03-13 09:00:00','2020-04-20 09:00:00',	2,	1, 1, 'EXCELENTE'),
('2020-11-22 09:00:00','2020-11-30 09:00:00',	3,	2, 3, 'MALO');

DROP TABLE IF EXISTS`resena`; 
CREATE TABLE `resena` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `estrellas` int(1) NOT NULL,
  `comentario` varchar(200) NOT NULL,
  `fecha` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `libro` int(11) NOT NULL,
  FOREIGN KEY (`usuario`) REFERENCES `usuario` (`id`),
  FOREIGN KEY (`libro`) REFERENCES `libro` (`id`)
) ENGINE='InnoDB';

INSERT INTO `resena` (`estrellas`, `comentario`, `fecha`, `usuario`, `libro`) VALUES
(4,'Me cambió la vida', '2013-10-25',	4, 2),
(1,'He perdido 10 horas de mi vida, quiero que me las devuelvan', '2019-09-01',	3, 3),
(2,'Lo recomendaré a mis amigos y familiares', '2020-04-20',	1, 1),
(3,'No quiero volver a tocar un libro en mi vida, Hulio', '2020-11-30',	2, 4);
      

--CREATE TABLE `alumno` (
  --`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  --`nombre` varchar(12) NOT NULL,
  --`apellidos` varchar(20) NOT NULL,
  --`email` varchar(20) NOT NULL
--) ENGINE='InnoDB';

--INSERT INTO `alumno` (`nombre`, `apellidos`, `email`) VALUES
--('José', 'López Rodríguez', 'joloro@biz.com'),
--('Humberto', 'Cano Carmona', 'hucaca@biz.com'),
--('Paula', 'Véliz García', 'pavela@biz.com'),
--('Sergio', 'Martínez Cobos', 'semaco@biz.com');

--CREATE TABLE `profesor` (
  --`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  --`dni` varchar(9) NOT NULL,
  --`nombre` varchar(12) NOT NULL,
  --`apellidos` varchar(20) NOT NULL,
  --`telefono` int(9) NOT NULL,
  --`email` varchar(20) NOT NULL
--) ENGINE='InnoDB';


--INSERT INTO `profesor` (`dni`, `nombre`, `apellidos`, `telefono`, `email`) VALUES
--('25593649R',	'Jacinto','López Rodríguez', 667483924,'jaloro@biz.com'),
--('26675849T',	'Francisco', 'Cano Carmona', 666513924, 'fracaca@biz.com'),
--('25678149X',	'Elena', 'Véliz García', 689653924, 'elvela@biz.com'),
--('23655849G',	'María', 'Martínez Cobos', 693753924, 'mamaco@biz.com');

--CREATE TABLE `administrador` (
  --`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  --`username` varchar(12) NOT NULL,
  --`password` varchar(20) NOT NULL
--) ENGINE='InnoDB';

--INSERT INTO `administrador` (`username`, `password`) VALUES
--('Alfredo', 'alfredo'),
--('Alejandra', 'alejandra'),
--('Alberto', 'alberto'),
--('Prudencia', 'prudencia');

--CREATE TABLE `ejemplar` (
  --`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  --`libro` int(11) NOT NULL,
  --FOREIGN KEY (`libro`) REFERENCES `libro` (`id`)
--) ENGINE='InnoDB';

--INSERT INTO `ejemplar` (`libro`) VALUES
--(4),
--(1),
--(2),
--(3);      

```