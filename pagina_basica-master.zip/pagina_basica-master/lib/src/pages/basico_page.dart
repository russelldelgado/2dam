import 'package:flutter/material.dart';


class BasicoPage extends StatelessWidget {

  final estiloTitulo = TextStyle(fontSize: 20,fontWeight: FontWeight.bold);
  final estiloSubtitulo = TextStyle(fontSize: 18,color: Colors.grey);

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
            child: Column(
                children:[
                _crearImagen(),
                _crearTitulo(),
                _crearAcciones(),
                _crearTexto(),
                _crearTexto(),
                _crearTexto(),
                _crearTexto(),
                _crearTexto(),
                _crearTexto(),
                _crearTexto(),
          
          ]
            ),
      ),
    );
  }

  Widget _crearImagen(){
    return  Container(
      width: double.infinity,
          child: Image(
              image: NetworkImage('https://static.photocdn.pt/images/articles/2018/12/03/articles/2017_8/mountain-landscape-ponta-delgada-island-azores-picture-id944812540.jpg'),
              fit: BoxFit.cover,
              height: 200,
              ),
    );
       
  }

  Widget _crearTitulo(){
    return SafeArea(
          child: Container(
              padding: EdgeInsets.symmetric(horizontal: 30.0 , vertical: 20.0),
              child: Row(
                children: [
                  Expanded(
                      child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Text('Lago del misisipi' ,style: estiloTitulo,),
                        SizedBox(height: 7.0,),
                        Text('es el mejor lago del mundo' , style: estiloSubtitulo,),
                      ],
                    ),
                  ),
                  Icon(Icons.star , color: Colors.red, size: 30.0,),
                  Text('41' , style: TextStyle(fontSize: 20),),

                ],
              ),
            ),
    );
  }

  Widget _crearAcciones(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children :[

        _accion(Icons.call , 'CALL'),
        _accion(Icons.near_me , 'ROUTE'),
        _accion(Icons.share , 'SHARE'),
        

      ]
    );
}

  Widget _accion(IconData icon , String texto){
    return Column(
          children : [
            Icon(icon , color: Colors.blue, size: 40.0,),
            SizedBox(height: 5.0,),
            Text(texto ,style: TextStyle(fontSize: 15.0 , color: Colors.blue),),
          ]
        );
  }

Widget _crearTexto(){
  return SafeArea(
      child: Container(
      padding: EdgeInsets.symmetric(horizontal: 40.0 ),
      child: Text(
        'Commodo velit voluptate nostrud exercitation in sit cillum esse adipisicing. Sunt consectetur adipisicing occaecat pariatur est laboris proident voluptate esse fugiat non nulla ullamco. Sit mollit qui mollit aute. Sit aliquip culpa ullamco exercitation anim. Exercitation veniam ad nulla excepteur non. Aute eu proident et fugiat deserunt esse ullamco enim.'
      ,textAlign: TextAlign.justify,
      ),
    ),
  );
}
}