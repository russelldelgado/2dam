package com.iesvdc.acceso.simplecrud.controller;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.util.List;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;


import com.iesvdc.acceso.simplecrud.conexion.Conexion;
import com.iesvdc.acceso.simplecrud.dao.ReservaDao;
import com.iesvdc.acceso.simplecrud.model.Instalacion;
import com.iesvdc.acceso.simplecrud.model.Reserva;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReservaManagement extends HttpServlet {
    
    @Override 
    public void init() throws ServletException {
        
    }

    // findOne(id)
    @Override
    protected void doGet(
        HttpServletRequest req, // parámetros de la petición
        HttpServletResponse resp) // respuesta que genero
        throws ServletException, IOException {
            
    }

    // CREAR
    @Override
    protected void doPost(
        HttpServletRequest req, // parámetros de la petición
        HttpServletResponse resp) // respuesta que genero
        throws ServletException, IOException {

            //recuperamos los datos del del jsp enviados mediante javascript y jquery
            Integer idUsuario = Integer.parseInt(req.getParameter("usuario")); 
            Integer idHorario = Integer.parseInt(req.getParameter("horario"));
            String fecha = req.getParameter("fecha");
             
            //comprobamos imprimiendo por consola el resultado
            System.out.print("usuario :" + idUsuario + " horario :" + idHorario + " fecha :" + fecha);
           
            //establecemos la conexcion con la base de datos
             Conexion conn = new Conexion();
             Connection conexion = conn.getConnection();
             PreparedStatement pstm;

             //realizamos la insercion de los datos
            try {
                String sql = "INSERT INTO reserva(usuario, horario, fecha) VALUES (?, ?, ?);";
                    pstm = conexion.prepareStatement(sql);
                    pstm.setInt(1, idUsuario);
                    pstm.setInt(2, idHorario);
                    //pstm.setString(3, "fechaActual");
                    pstm.setString(3, fecha );
               pstm.executeUpdate();
               conexion.close();
               //conexion.destroy();
               // resp.sendRedirect("/privado/reservaRead.jsp");
            } catch (Exception e){
               // resp.setStatus(700);
            } finally {
                //sresp.sendRedirect("/privado/reservaRead.jsp");
            }



            

            
       
    }

    // BORRAR
    @Override
    protected void doDelete(
        HttpServletRequest req, // parámetros de la petición
        HttpServletResponse resp) // respuesta que genero
        throws ServletException, IOException {

            resp.setContentType("application/json");
            PrintWriter out = resp.getWriter();
            String jsonObject = "{}";
            // buscamos en la base de datos el objeto y devolvemos sus datos
    
            String id = req.getRequestURI().substring(req.getContextPath().length());
            id = id.replace("/reserva/", "");
            jsonObject = "{'error': '" + id + "'}";
    
            // String id = req.getParameter("userid");
            try {
                Conexion conn = new Conexion();
                String sql = "DELETE FROM reserva WHERE id=?";
                PreparedStatement pstm = conn.getConnection().prepareStatement(sql);
                pstm = conn.getConnection().prepareStatement(sql);
    
                pstm.setInt(1, Integer.parseInt(id));
    
                if (pstm.executeUpdate() == 0) {
                    jsonObject = "{ " + "'id':'" + id + "'}";
                }
    
                pstm.close();
                conn.destroy();
            } catch (Exception ex) {
    
            }
            out.print(jsonObject.replaceAll("'", "\""));
            out.flush();

    }

    // ACTUALIZAR
    @Override
    protected void doPut(
        HttpServletRequest req, // parámetros de la petición
        HttpServletResponse resp) // respuesta que genero
        throws ServletException, IOException {

        
    }
}