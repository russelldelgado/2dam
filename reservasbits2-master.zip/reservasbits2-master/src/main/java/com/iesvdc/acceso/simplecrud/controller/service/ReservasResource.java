package com.iesvdc.acceso.simplecrud.controller.service;

import com.iesvdc.acceso.simplecrud.dao.*;
import com.iesvdc.acceso.simplecrud.daoimpl.*;
import com.iesvdc.acceso.simplecrud.model.*;

import java.util.List;
import java.util.logging.Logger;

import javax.faces.annotation.RequestCookieMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

//importaciones extras

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Juangu <jgutierrez at iesvirgendelcarmen.com>
 */
@Path("/api")
public class ReservasResource {

    @GET
    @Path("reservas")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getHorarios() {
        ReservaDao reservaDao = new ReservaDaoImpl();
        List<Reserva> reservas;
        try {
            reservas = reservaDao.findAll();
            return Response.ok(reservas).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GET
    @Path("reservas/instalacion/{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getHorarioInstalacion(@PathParam("id") String id) {
        HorarioDao horarioDao = new HorarioDaoImpl();
        List<Horario> horarios;
        try {
            horarios = horarioDao.findByInstalacion(Integer.parseInt(id));
            if (horarios!=null) // consulta ok y devuelve lista
                return Response.ok(horarios).build();
            else // no pudo conectar a la BBDD
                return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        } catch (Exception ex) { // cualquier otro error
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GET
    @Path("reservas/{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getHorarioById(@PathParam("id") String id) {
        ReservaDao reservaDao = new ReservaDaoImpl();
        Reserva reserva;
        try {
            reserva = reservaDao.findOne(Long.parseLong(id));
            return Response.ok(reserva).build();
        } catch (Exception ex) {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @PUT
    @Path("reservas/{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response updateHorario(@PathParam("id") Long oldHorarioId, Horario newHorario) {
        HorarioDao horarioDao = new HorarioDaoImpl();
        try {
            if (horarioDao.update(oldHorarioId, newHorario)) {
                return Response.status(200).entity(newHorario).build();
            } 
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(oldHorarioId).build();
        }
        return Response.status(Status.NOT_FOUND).entity(oldHorarioId).build();
    }
/*
    
    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("reservas/{id}")
    public Response createReserva(@context HttpServletRequest req , @PathParam("id") String id) {

        String usuId = "";

        Cookie loginCookie = null;
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("ges_res.user")) {
					loginCookie = cookie;
					break;
                }
                if (cookie.getName().equals("ges_res.userid")) {
					usuId = cookie.getValue();
					break;
				}
			}
		}
		if (loginCookie != null) {
			loginCookie.setMaxAge(0);
			response.addCookie(loginCookie);
		}
       

        ReservaDao rd = new ReservaDaoImpl();
        HorarioDao hd = new HorarioDaoImpl();
        UsuarioDao ud = new UsuarioDaoImpl();

        Reserva reserva = rd.findOne(Long.parseLong(id)); //faltan datos
        Horario horario = hd.findById(Integer.parseInt(id)); // falta datos
        Usuario usuario = ud.findById(Integer.parseInt(usuId)); //faltan datos

    }
    
    */
    @DELETE
    @Path("reservas/{id}")
    public Response deleteHorario(@PathParam("id") Long id) {
        ReservaDao reservaDao = new ReservaDaoImpl();
        try {
            if (reservaDao.delete(id))
                return Response.status(200).entity(id).build();
        } catch (Exception ex) {
            Logger.getLogger(ex.getLocalizedMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(id).build();
        }
        return Response.status(Status.NOT_FOUND).entity(id).build();
    }
}