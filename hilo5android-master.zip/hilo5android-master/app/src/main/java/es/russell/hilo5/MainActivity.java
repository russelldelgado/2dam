package es.russell.hilo5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Process;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.TimerTask;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    TextView mensaje ;
    Button botonIniciar;
    Button botonParar;
    ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(2);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mensaje = findViewById(R.id.mensaje);
        botonIniciar = findViewById(R.id.botonIniciar);
       //botonIniciar.setOnClickListener(this);
        // botonParar.setOnClickListener(this);
        botonParar = findViewById(R.id.botonParar);


        Runnable tarea3 = new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mensaje.append("\nEJECUTANTO TAREA 3 ");
                        mensaje.append("\nTAREA EN = " + Thread.currentThread().getName());
                    }
                });
            }
        };


    }



        Runnable tarea3 = new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mensaje.append("\nEJECUTANTO TAREA 3 ");
                        mensaje.append("\nTAREA EN = " + Thread.currentThread().getName());
                    }
                });
            }
        };





        Runnable tarea4 = new Runnable() {
            @Override
            public void run() {
                android.os.Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                final String tarea = Thread.currentThread().getName();

                mensaje.post(new Runnable() {
                    @Override
                    public void run() {
                        mensaje.append("\nEJECUTANTO TAREA 4 ");
                        mensaje.append("\nTAREA EN = " + tarea);
                    }
                });

            }
        };



    /*
    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.botonIniciar :
                break;
            case R.id.botonParar:
                break;

        }

    }

     */

    @Override
    protected void onResume() {
        super.onResume();

        botonIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mensaje.setText("INICIANDO TAREAS");

                ScheduledFuture tare1 = executor.scheduleAtFixedRate(new Tarea1(),0,5, TimeUnit.SECONDS);
                executor.schedule(new Tarea2() ,2,TimeUnit.SECONDS);

                executor.scheduleAtFixedRate(tarea3,0,2 ,TimeUnit.SECONDS);
                executor.scheduleAtFixedRate(tarea4  ,0  ,2 ,TimeUnit.SECONDS);

                mensaje.append("\nTamaño del pool = " + String.valueOf(executor.getPoolSize()));

            }
        });

        botonParar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mensaje.append("\nAPAGANDO EJECUCUINO DE TAREAS");
                executor.shutdown();
            }
        });
    }


    class Tarea1 extends TimerTask{

        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mensaje.append("\nEJECUTANTO TAREA 1 ");
                    mensaje.append("\nTAREA EN = " + Thread.currentThread().getName());
                }
            });
        }
    }

    class Tarea2 extends TimerTask{
        @Override
        public void run() {

            android.os.Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            final String tarea = Thread.currentThread().getName();
            mensaje.post(new Runnable() {
                @Override
                public void run() {
                    mensaje.append("\nEJECUTANTO TAREA 2 ");
                    mensaje.append("\nTAREA EN = " + tarea);
                }
            });

        }
        }



}


/*
*
* @Override
    protected void onResume() {
        super.onResume();

        botonIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mensaje.setText("INICIANDO TAREAS");

            }
        });
    }
*
* */