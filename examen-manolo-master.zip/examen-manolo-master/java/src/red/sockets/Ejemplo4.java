package red.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

//cliente para Ejemplo3
public class Ejemplo4 {
    public static void main(String[] args) {
        final int PORT = 5001;
        final String HOST = "localhost";
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream());
             Scanner in = new Scanner(socket.getInputStream());
             )
        {
            Scanner teclado = new Scanner(System.in);

            while (in.hasNextLine()) {
                String linea = in.nextLine();
                if (linea.equalsIgnoreCase("Adios")){
                    System.out.println(linea);
                    teclado.close();
                    break;
                }
                System.out.println(linea);
                System.out.println("introduce palabra a mandar al servidor, fin para acabar");
                String envio = teclado.nextLine();
                out.println(envio);
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
