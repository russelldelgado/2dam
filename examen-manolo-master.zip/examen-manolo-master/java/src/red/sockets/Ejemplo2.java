package red.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Ejemplo2 {
    public static void main(String[] args) {
        final int PORT = 80;
        final String HOST = "www.google.es";
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream());
             Scanner in = new Scanner(socket.getInputStream()))
        {
            //mandamos datos al servidor
            out.println("GET / HTTP/1.1");
            out.println("Host:www.google.es");
            out.println();
            out.flush();
            //recojemos datos del servidor
            while (in.hasNextLine())
                System.out.println(in.nextLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
