package red.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

class Handler implements Runnable {
    private static int nConexion = 0;
    private final Socket socket;
    private Scanner in ;
    private PrintWriter out ;
    Handler(Socket socket) {
        this.socket = socket;
        nConexion++;
        try {
            this.in = new Scanner(socket.getInputStream());
            this.out = new PrintWriter(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void run() {
        System.out.println("Conexión abiertas: " + nConexion);
        out.println("Envía datos");
        out.flush();
        String linea;
        while (in.hasNextLine()) {
            linea = in.nextLine();
            System.out.printf("Recibido: %s%n", linea);
            if (linea.equalsIgnoreCase("fin")) {
                out.println("Adios");  //cierre elegante
                out.flush();
                nConexion--;
                break;
            }
            //envíos de datos al cliente
            out.println(linea.toUpperCase());
            out.flush();
        }
    }
}
