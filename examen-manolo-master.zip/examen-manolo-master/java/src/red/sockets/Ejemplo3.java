package red.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Ejemplo3 {
    public static void main(String[] args) {
        final int PORT = 5001;
        try (ServerSocket serverSocket = new ServerSocket(PORT);
             Socket socket = serverSocket.accept();
             Scanner in = new Scanner(socket.getInputStream());
             PrintWriter out = new PrintWriter(socket.getOutputStream()))
        {
            System.out.printf("SERVIDOR: %s%n", serverSocket.getLocalSocketAddress());
            //obtener datos del cliente
            out.println("Envía datos");
            out.flush();
            String linea;
            while (in.hasNextLine()) {
                linea = in.nextLine();
                System.out.printf("Recibido: %s%n", linea);
                if (linea.equalsIgnoreCase("fin")) {
                    out.println("Adios");  //cierre elegante
                    out.flush();
                    break;
                }
                //envíos de datos al cliente
                out.println(linea.toUpperCase());
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
