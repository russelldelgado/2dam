package red.sockets;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Ejemplo1 {
    public static void main(String[] args) {
        final int PORT = 13;
        final String HOST = "time.nist.gov";
        try(Socket socket = new Socket(HOST, PORT);
            Scanner in = new Scanner(socket.getInputStream()))
        {
            while (in.hasNextLine())
                System.out.println(in.nextLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
