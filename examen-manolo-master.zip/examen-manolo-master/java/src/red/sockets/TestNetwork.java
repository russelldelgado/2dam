package red.sockets;

import java.io.IOException;

public class TestNetwork {
    public static void main(String[] args) throws IOException {
        new Thread(new NetworkService(5001)).start();
    }
}
