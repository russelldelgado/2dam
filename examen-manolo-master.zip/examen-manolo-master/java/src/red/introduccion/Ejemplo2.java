package red.introduccion;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Ejemplo2 {
    public static void main(String[] args) {
        try {
            // URL url = new URL("ftp://cisco");
            URL url = new URL("http://www.iesvirgendelcarmen.com");
            URLConnection connection = url.openConnection();
            Map<String, List<String>> cabeceras = connection.getHeaderFields();
            cabeceras.entrySet().stream().forEach(System.out::println);
            System.out.println("\n");
            Scanner in = new Scanner(url.openStream());
            while (in.hasNextLine())
                System.out.println(in.nextLine());
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
