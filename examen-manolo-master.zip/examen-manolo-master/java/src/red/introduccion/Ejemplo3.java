package red.introduccion;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Ejemplo3 {
    public static void main(String[] args) throws IOException {
        URL url = new URL("http://www.iesvirgendelcarmen.com");
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        System.out.printf("Código de respuesta %d%n", httpURLConnection.getResponseCode());
        System.out.printf("Respuesta %s%n", httpURLConnection.getResponseMessage());
        System.out.printf("Método empleado %s%n", httpURLConnection.getRequestMethod());
    }
}
