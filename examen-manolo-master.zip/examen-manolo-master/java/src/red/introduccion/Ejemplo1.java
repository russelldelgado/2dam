package red.introduccion;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Ejemplo1 {
    public static void main(String[] args) throws IOException {
        URL url = new URL("https://www.as.com");
        Scanner in = new Scanner(url.openStream());
        while (in.hasNextLine())
            System.out.println(in.nextLine());
        in.close();
    }
}
