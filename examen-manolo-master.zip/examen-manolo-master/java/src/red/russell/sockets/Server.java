package red.russell.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Scanner;

public class Server {

    public static void main(String[] args) throws IOException {
        ServerSocket listener = new ServerSocket(5001);
        try {
            while (true) {
                Socket socket = listener.accept();
                try {
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    out.println("FUNCIONA");
                    while (true) {
                        Scanner in = new Scanner(socket.getInputStream());
                        out.println(new Date().toString());
                        System.out.println(in.nextLine());
                    }

                } catch (Exception e) {
                    // TODO: handle exception
                } finally {
                    socket.close();
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
        } finally {
            listener.close();
        }

    }
}