package red.russell.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Socket2 {

    public static void main(String[] args) {

        final String HOST = "dict.org";
        final int PORT = 2628;

        Socket socket = null;
        Scanner in = null;
        PrintWriter out = null;

        try {
            socket = new Socket(HOST, PORT);
            out = new PrintWriter(socket.getOutputStream());
            out.println("define fd-spa-eng coche");
            out.flush();

            in = new Scanner(socket.getInputStream());

            while (in.nextLine() != null) {
                System.out.print(in.nextLine());

            }

        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            in.close();
            out.close();
            try {
                socket.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

}
