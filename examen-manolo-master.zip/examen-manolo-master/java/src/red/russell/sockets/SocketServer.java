package red.russell.sockets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class SocketServer {

    public static void main(String[] args) {
        ServerSocket socketSERVER;
        try {
            socketSERVER = new ServerSocket(9090);
            Socket socket = socketSERVER.accept();

            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println(new Date().toString());
            out.flush();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

        }

    }

}
