package red.russell.sockets;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Socket1 {

    public static void main(String[] args) {
        final String HOST = "time.nist.gov";
        final int PORT = 13;
        Socket socket = null;
        Scanner in = null;

        try {
            socket = new Socket(HOST, PORT);
            in = new Scanner(socket.getInputStream());

            while (in.hasNextLine()) {
                System.out.println(in.nextLine());
            }

        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            in.close();
        }

        ;

    }

}
