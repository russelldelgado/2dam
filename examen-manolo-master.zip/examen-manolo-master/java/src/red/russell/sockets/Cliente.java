package red.russell.sockets;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

    public static void main(String[] args) {

        String HOST = "localhost";
        int PORT = 5001;
        Socket socket = null;

        Scanner sc = null;
        PrintWriter printWriter = null;

        try {
            socket = new Socket(HOST, PORT);
            printWriter = new PrintWriter(socket.getOutputStream());

            sc = new Scanner(System.in);

            // System.out.println("eee");

            while (sc.hasNextLine()) {
                // System.out.println(sc.nextLine());
                printWriter.println(sc.nextLine());
                printWriter.flush();
            }
        } catch (Exception e) {
            // TODO: handle exception
        } finally {
            sc.close();
            try {
                printWriter.close();
                socket.close();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }

    }

}