package red.russell;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class UrlConexion {

    public static void main(String[] args) {
        try {
            URL conexion = new URL("https://www.oracle.com");

            Scanner in = new Scanner(conexion.openStream());

            while (in.hasNextLine()) {
                System.out.println(in.nextLine());
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
