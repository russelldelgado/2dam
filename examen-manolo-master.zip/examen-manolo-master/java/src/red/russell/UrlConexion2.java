package red.russell;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UrlConexion2 {

    public static void main(String[] args) {
        try {
            URL miConexion = new URL("http://www.amazon.com");
            URLConnection urlConexion = miConexion.openConnection();
            Map<String, List<String>> cabeceras = urlConexion.getHeaderFields();
            cabeceras.entrySet().stream().forEach(System.out::println);

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
