package red.russell;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class HttpUrlConexionMia {

    public static void main(String[] args) {
        try {
            URL url = new URL("http://www.iesvirgendelcarmen.com");
            HttpURLConnection httpUrlConexionMia = (HttpURLConnection) url.openConnection();

            System.out.println("CODIGO DE RESPUESTA : " + httpUrlConexionMia.getResponseCode());
            System.out.println("CODIGO time out : " + httpUrlConexionMia.getConnectTimeout());
            System.out.println("CODIGO ifmodifiedsince : " + httpUrlConexionMia.getIfModifiedSince());

            Scanner sc = new Scanner(url.openStream());
            while (sc.hasNextLine()) {
                System.out.println(sc.nextLine());
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
