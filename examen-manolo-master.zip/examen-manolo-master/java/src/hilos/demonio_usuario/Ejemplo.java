package hilos.demonio_usuario;

import java.util.Random;

public class Ejemplo {
    public static void main(String[] args) throws InterruptedException {
        //hilos de tipo usuario
        //siempre que la JVM está arrancada, se ejecutan, aunque el hilo principal acabe
        new Hilos().start();
        new Hilos().start();
        Thread.sleep(new Random().nextInt(5_000));
        System.out.println("fin de programa");
    }
}
class Hilos extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 50; i++) {
            System.out.println(Thread.currentThread().getName());
            try {
                Thread.sleep(new Random().nextInt(1_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}