package hilos.introduccion;

import java.util.Random;

public class Ejemplo {
    public static void main(String[] args) {
        //hilos 0 y 1
        for (int i = 0; i < 2; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ejecucion();
                }
            }).start();
        }
        //Hilo 2
        Runnable runnable =  () -> ejecucion();
        new Thread(runnable).start();
        //Hilo 3
        new Thread(Ejemplo::ejecucion).start();
        //Hilo  main
        ejecucion();
        System.out.println("Fin de programa");
    }
    public static void ejecucion () {
        for (int i = 0; i < 25; i++) {
            System.out.println(Thread.currentThread().getName());
            try {
                Thread.sleep( new Random().nextInt(1_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
