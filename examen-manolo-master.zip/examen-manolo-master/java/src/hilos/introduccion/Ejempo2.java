package hilos.introduccion;

import java.util.Random;

public class Ejempo2 {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            new Thread(Codigo::mostrarConsola).start();
        }
        System.out.println("Fin de programa");
    }
}
class Codigo {
    public static void mostrarConsola () {
        for (int i = 0; i < 25; i++) {
            System.out.printf("HILO: %s, NÚMERO: %d%n", Thread.currentThread().getName(), i);
            try {
                Thread.sleep(new Random().nextInt(1_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
