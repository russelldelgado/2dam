package hilos.introduccion;

import java.util.Random;

public class Ejemplo1 {
    public static void main(String[] args) {
        Thread hilo1 = new Thread(new Hilos()), hilo2 = new Thread(new Hilos()), hilo3 = new Thread(new Hilos());
        hilo1.start(); hilo2.start(); hilo3.start();
        for (int i = 0; i < 25; i++) {
            System.out.println(Thread.currentThread().getName());
            try {
                Thread.sleep( new Random().nextInt(100));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Fin de programa");
    }
}
/*
class Hilos extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 25; i++) {
            System.out.println(Thread.currentThread().getName());
            try {
                Thread.sleep( new Random().nextInt(1_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}*/
class Hilos implements Runnable {

    @Override
    public void run() {
        for (int i = 0; i < 25; i++) {
            System.out.println(Thread.currentThread().getName());
            try {
                Thread.sleep( new Random().nextInt(1_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}