package hilos.introduccion;

public class SumaConHilos {
    public static void main(String[] args) throws InterruptedException {
        long inicio = System.currentTimeMillis();
        SumaHilos hilo1 = new SumaHilos();
        SumaHilos hilo2 = new SumaHilos();
        SumaHilos hilo3 = new SumaHilos();
        SumaHilos hilo4 = new SumaHilos();
        hilo1.start(); hilo2.start(); hilo3.start(); hilo4.start();
        hilo1.join(); hilo2.join(); hilo3.join(); hilo4.join();
        long suma1 = hilo1.getSuma();
        long suma2 = hilo2.getSuma();
        long suma3 = hilo3.getSuma();
        long suma4 = hilo4.getSuma();
        long resultado = suma1 + suma2 + suma3 + suma4;
        long fin = System.currentTimeMillis();
        System.out.printf("Resultado %d. Tiempo cálculo: %d ms%n", resultado, fin - inicio);
    }
}
class SumaHilos extends Thread {

    private long suma;

    public long getSuma() {
        return suma;
    }

    @Override
    public void run() {
        for (int i = 0; i <= 100_000_000; i++) {
            suma += i;
        }
    }
}
