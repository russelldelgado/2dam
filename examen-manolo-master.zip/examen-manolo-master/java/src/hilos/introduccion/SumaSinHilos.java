package hilos.introduccion;

public class SumaSinHilos {
    public static void main(String[] args) {

        long inicio = System.currentTimeMillis();
        long suma1 = Suma.sumar();
        long suma2 = Suma.sumar();
        long suma3 = Suma.sumar();
        long suma4 = Suma.sumar();
        long resultado = suma1 + suma2 + suma3 + suma4;
        long fin = System.currentTimeMillis();
        System.out.printf("Resultado %d. Tiempo cálculo: %d ms%n", resultado, fin - inicio);
    }

}
class Suma {
    public static long sumar() {
        long suma = 0;
        for (int i = 0; i <= 100_000_000; i++) {
            suma += i;
        }
        return suma;
    }
}

