package hilos.pool;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Ejemplo1 {
    public static void main(String[] args) {
        ExecutorService handler = Executors.newSingleThreadExecutor();
        for (int i = 0; i < 10; i++) {
            System.out.println("Nº hilo: " + i);
            handler.submit(new Hilos());
        }
        handler.shutdown();
        System.out.println("ACABANDO EL PROGRAMA EN EL HILO PRINCIPAL ");
    }
}

class Hilos implements Runnable {
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println(Thread.currentThread().getName());
            try {
                Thread.sleep(new Random().nextInt(1_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}