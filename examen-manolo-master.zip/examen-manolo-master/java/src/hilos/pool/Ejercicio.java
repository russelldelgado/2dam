package hilos.pool;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.*;

public class Ejercicio {
    public static void main(String[] args) throws FileNotFoundException, ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        Scanner scanner = new Scanner(new File("FILES/numeros_primos.txt"));
        Map<Long, Boolean> diccionario = new HashMap<>();
        while (scanner.hasNextLong()) {
           // System.out.println(scanner.nextLong());
            long numero = scanner.nextLong();
            Future<Boolean> future = executorService.submit(new Primalidad(numero));
           // System.out.printf("%d ¿Es primo? %B%n", numero, future.get());
            diccionario.put(numero, future.get());
        }
        executorService.shutdown();
        scanner.close();
        /*for (Long numero: diccionario.keySet()) {
            System.out.printf("Numero %d, primo: %B%n", numero, diccionario.get(numero));
        }*/
        diccionario.entrySet().stream().forEach(System.out::println);
    }
}
class Primalidad implements Callable<Boolean> {
    private long numero;

    public Primalidad(long numero) {
        this.numero = numero;
    }

    @Override
    public Boolean call() throws Exception {
        if (numero <= 3){
            return numero > 1;
        }else if(numero % 2 == 0 || numero % 3 == 0){
            return false;
        }else {
            for (long i = 5; i * i <= numero; i +=6){
                if(numero % i == 0 || numero % (i + 2) == 0){
                    return false;
                }
            }
            return true;
        }
    }
}

