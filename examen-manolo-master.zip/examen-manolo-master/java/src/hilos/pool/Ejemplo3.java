package hilos.pool;

import java.util.Random;
import java.util.concurrent.*;

public class Ejemplo3 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        int suma = 0;
        ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        for (int i = 0; i < 100; i++) {
            Future<Integer> future = executorService.submit(new Hilo3());
            suma += future.get();
        }

        executorService.shutdown();
        System.out.println("Resultado de la suma " + suma);


    }
}
class Hilo3 implements Callable<Integer> {

    @Override
    public Integer call() throws Exception {
        int resultado = new Random().nextInt(1_000);
        System.out.println(Thread.currentThread().getName() + " - " + resultado);
        Thread.sleep(resultado);
        return resultado;
    }
}