package procesos;
//ejecutando el proceso ls -la
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Ejemplo1 {
    public static void main(String[] args) {
        String[] comandos = {"ls", "-la"};
        String[] variablesEntorno = null;
        File directorioTrabajo = new File("/home/manuel");
        Runtime runtime = Runtime.getRuntime();
        Scanner scanner = null;
        try {
            Process process = runtime.exec(comandos, variablesEntorno, directorioTrabajo);
            scanner = new Scanner(process.getInputStream());
            while (scanner.hasNextLine())
                System.out.println(scanner.nextLine());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
            System.out.println("Fin de programa");
        }
    }
}
