package procesos;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Scanner;

public class Ejemplo4 {
    public static void main(String[] args) {
        List<String> comandos1 = List.of("cat", "datos.txt");
        List<String> comandos2 = List.of("grep", "google");
        List<String> comandos3 = List.of("wc", "-l");
        ProcessBuilder processBuilder1 = new ProcessBuilder(comandos1);
        processBuilder1.directory(new File("FILES"));
        ProcessBuilder processBuilder2 = new ProcessBuilder(comandos2);
        ProcessBuilder processBuilder3 = new ProcessBuilder(comandos3);
        Scanner in = null;
        try {

            Process process1 = processBuilder1.start();
            Process process2 = processBuilder2.start();
            Process process3 = processBuilder3.start();

            in = new Scanner(process1.getInputStream());
            PrintWriter out = new PrintWriter(process2.getOutputStream());
            while (in.hasNextLine()) {
                //System.out.println(in.nextLine());
                out.println(in.nextLine());
                out.flush();
            }
            process1.waitFor();
            out.close();

            in = new Scanner(process2.getInputStream());
            out = new PrintWriter(process3.getOutputStream());
            while (in.hasNextLine()) {
                //System.out.println(in.nextLine());
                out.println(in.nextLine());
                out.flush();
            }
            process2.waitFor();
            out.close();

            in = new Scanner(process3.getInputStream());
            while (in.hasNextLine())
                System.out.println(in.nextLine());
            process3.waitFor();


        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            in.close();
        }


    }
}
