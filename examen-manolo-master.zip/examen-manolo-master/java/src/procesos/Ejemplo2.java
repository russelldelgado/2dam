package procesos;
//lanzando proceso okular (puede ser cualquier aplicación gráfica)

import java.io.IOException;
import java.util.List;

public class Ejemplo2 {
    public static void main(String[] args) {
        /*List<String> comandos = new ArrayList<>();
        comandos.add("libreoffice");*/
        List<String> comandos = List.of("okular");
        ProcessBuilder processBuilder = new ProcessBuilder(comandos);
        try {
            Process process = processBuilder.start();
            ProcessHandle.Info info = process.info();
            System.out.println(info.command().orElse("No tengo datos"));
            System.out.printf("El id del proceso hijo es %d%n", process.pid());
            process.waitFor();
            System.out.printf("Proceso terminado con valor %d%n", process.exitValue());

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
