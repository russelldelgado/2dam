import User from '../models/user'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'

const userController = {
    saveUser : async (req, res) => {
        const { body } = req
        try {
            const userNew = await User.create(body)
            res
                .status(201)
                .json(userNew)
        } catch (error) {
            res 
                .status(400)
                .json({error: error})
        }
    },
    loginUser : async (req, res) => {
        console.log('en longin')
        
        const { body } = req //body viene email para buscar el usuario y la password para comprobar
        console.log(body)
        try {
            const user = await User.findOne({email: body.email})
            if (!user) {  //no existe el usuario, email no existe en la BD
                res 
                    .status(400)
                    .json({error: 'not valid user'})
                throw new Error()
            }
            const validUser = await bcrypt.compare(body.password + "", user.password + "") 
            if (validUser){ //password correcta
                //generar el token
                const token = jwt.sign({_id: user._id }, process.env.JWT_KEY,
                    { expiresIn: '1h' })
                res
                    .status(200)
                    .json({message: 'valid user', token: token})
            } else { //password incorrecta
                res 
                    .status(400)
                    .json({error: 'not valid password'})
            }
           
        } catch (error) {
            console.log(error)
        }
    },
    validate: async (req, res, next) => {
        const token = req.headers['x-access-token']
      //  console.log(token)
        try {
            if (!token) {
                res 
                .status(400)
                .json({error: 'no hay token'})
                throw new Error()
            }
            jwt.verify(token, process.env.JWT_KEY, function(err, decoded) {
                if (err) {
                    res 
                        .status(400)
                        .json({error: 'token incorrecto'})
                    throw new Error()
                }
                next()
            }) 

        } catch (error) {
            console.log(error)
            
        }
    }
}

export default userController