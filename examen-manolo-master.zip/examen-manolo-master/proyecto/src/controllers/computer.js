import Computer from '../models/computer'

const computerController = {
    saveComputer : async (req, res) => {
        const { body } = req
        try {
            const computer = await Computer.create(body)
            res
                .status(201)
                .json(computer)
        } catch (error) {
            res 
                .status(400)
                .json({error: error})
        }
    },
    getComputers: async (req, res) => {
        try {
            const computers = await Computer.find()
            res
                .status(200)
                .json(computers)
        } catch (error) {
            res 
                .status(400)
                .json({error: error})
        }
    },
    getComputerById: async (req, res) => {
        const _id  = req.params.id
        try {
            const computer = await Computer.findById(_id)
            res
                .status(200)
                .json(computer)
        } catch (error) {
            res 
                .status(500)
                .json({error: error})
        }
    },
    deleteById: async (req, res) => {
        const _id  = req.params.id
      //  console.log('id: ' + _id)
        
        try {
            const computer = await Computer.findByIdAndDelete(_id)
            res
                .status(200)
                .json(computer)
        } catch (error) {
            res 
                .status(500)
                .json({error: error})
        }
    },
    updateComputer: async (req, res) => {
        const _id = req.params.id
        const { body } = req
        try {
            const computer = await Computer.findByIdAndUpdate(
                _id,
                body,
            )
            if (!computer) {
                res 
                    .status(404)
                    .json({error: "no existe el ordenador"})
            }
            res
                .status(200)
                .json( {message: "actualización correcta" })
        } catch (error) {
            res 
                .status(500)
                .json({error: "Error de servidor"})
        }
    }
}


export default computerController