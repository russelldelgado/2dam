import computerRoutes from './routes/computer'
import userRoutes from './routes/user'
import userController from './controllers/user'

const router = (app) => {
    app.get('/', async (req, res) => {
        res.send('Router 💻')
    })
    app.use('/computer', userController.validate ,computerRoutes)
    app.use('/user', userRoutes )
}

export default router