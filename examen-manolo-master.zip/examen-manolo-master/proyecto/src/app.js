//console.log("API REST 😎")
import express from 'express'
import config from './config'
import router from './router'
import './database'

const PORT = process.env.PORT || 5000
const app = express()
//configuramos app de express
config(app)
//añadimos las rutas
router(app)

app.listen(PORT, () =>
  console.log(`El servidor ha sido inicializado: http://localhost:${PORT}`)
)