import express from 'express'
import userController from '../controllers/user'

const router = express.Router()

router.post('/signup', userController.saveUser)
router.post('/signin', userController.loginUser)


export default router