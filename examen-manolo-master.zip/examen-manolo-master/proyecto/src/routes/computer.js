import express from 'express'
import computerController from '../controllers/computer'

const router = express.Router()

router.post('/', computerController.saveComputer)
router.get('/', computerController.getComputers)
router.get('/:id', computerController.getComputerById)
router.delete('/:id', computerController.deleteById)
router.put('/:id', computerController.updateComputer)

export default router