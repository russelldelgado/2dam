import mongoose from 'mongoose'

const uri = process.env.MONGO_URI

const options = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true
}
mongoose.Promise = global.Promise
mongoose
    .connect(uri, options)
    .then( () => {
        console.log("Conectado a MongoDB 💾") })
    .catch ( (error) => {
        console.log(error);
    })
