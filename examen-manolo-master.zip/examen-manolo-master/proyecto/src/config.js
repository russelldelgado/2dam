import cors from 'cors'
import morgan from 'morgan'
import bodyParser from 'body-parser'

const config = (app) => {
    app.disable('x-powered-by') //no damos información de uso de express
    app.use(bodyParser.json())
    app.use(bodyParser.urlencoded({extended : false}))
    app.use(cors())
    app.use(morgan("dev"))
}

export default config