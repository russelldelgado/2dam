import mongoose from 'mongoose'

const Schema = mongoose.Schema

const ComputerSchema = new Schema( {
    ram : {
        type : Number, 
        enum: [8, 16, 32],
        default : 8
    },
    disk : {
        type: String,
        enum: ['hdd', 'sdd'],
        default: 'hdd'
    },
    cpu : {
        type: String,
        enum: ['intel', 'amd'],
        default: 'amd'
    },
}, {versionKey: false})

const Computer = mongoose.model('Computer', ComputerSchema)

export default Computer