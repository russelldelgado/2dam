// console.log("API REST 😎"); 
// console.log('Probando nodemon')
import mongoose from "mongoose";
import userController from './controller/user'

const uri = 'mongodb://172.17.0.2/ejemplo';
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useFindAndModify: false,
  useCreateIndex: true
};

mongoose.Promise = global.Promise;
mongoose
  .connect(uri, options)
  .then(() => {
    console.log("Conectado a MongoDB 💾");
    const user = {name : 'Juanjo', age: 22,  phone : '987456321'}
   // userController.createUser(user)
   //userController.listAllUsers()
      //userController.listUserById('5fd9e7aed4fa0d29c69832dc')
  // userController.updateUserById('5fd9e7aed4fa0d29c69832dc',user )
  userController.deleteUserById('5fd9e7aed4fa0d29c69832dc')
  })
  .catch(err => {
    console.error(err);
  });
