import mongoose from 'mongoose'

const Schema = mongoose.Schema

const UserSchema = new Schema ({
    name : {type: String, required : true},
    age : {type: Number, min: 18, default : 18},
    phone : {type: String, match : /^[6-9][0-9]{8}$/, required: true, unique : true}
}, {versionKey : false})

const UserModel = mongoose.model('User' , UserSchema )

export default UserModel