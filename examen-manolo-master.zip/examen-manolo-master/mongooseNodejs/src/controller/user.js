import UserModel from '../model/user'

const userController = {
    createUser : async (user) => {
        try {
            const newUser = await UserModel.create(user)
            console.log(`Creado nuevo usuario ${user.name}`)
        } catch (error) {
            console.log(error)
        }
    },
    listAllUsers : async () => {
        try {
            const allUsers = await UserModel.find()
            console.log(allUsers)
        } catch (error) {
            console.log(error)
        }
    },
    listUserById : async (_id) => {
        try {
            const user = await UserModel.findById(_id)
            console.log(user)
            
        } catch (error) {
            console.log(error)
        }
    },
    updateUserById : async(_id, user) => {
        try {
            const userUpdate = await UserModel.findByIdAndUpdate(_id, user)
            console.log(userUpdate)
            console.log(user)

        } catch (error) {
            console.log(error)
        }
    },
    deleteUserById : async (_id) => {
        try {
            const userDelete = await UserModel.findByIdAndDelete(_id)
            console.log(userDelete)
            
        } catch (error) {
            
        }
    }
}

export default userController