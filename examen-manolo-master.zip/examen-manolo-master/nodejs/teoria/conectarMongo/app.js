const MongoClient = require('mongodb').MongoClient;
const buscarTodos = require('./crud').findDocuments
const bucarPorPais = require('./crud').findByCountry
const insertDocuments = require('./crud').insertDocuments
const updateCountry = require('./crud').updateCountry
const removeCountry = require('./crud').removeCountry
//const assert = require('assert');

// Connection URL
const url = 'mongodb://172.17.0.2:27017';

// Database Name
const dbName = 'ejemplo';

// Create a new MongoClient
const client = new MongoClient(url, { useUnifiedTopology: true });

// Use connect method to connect to the Server
client.connect(function(err) {
//  assert.equal(null, err);
  console.log("Connected successfully to server");

  const db = client.db(dbName);
//   buscarTodos(db, function(data){
//     console.log(data)
      
//     client.close();
//   }) 
    // bucarPorPais(db, 'Spain', function (err, data){
    //     if (err) console.log(err)
    //     else console.log(data)
    //     client.close()
    // // })
    // const documento =  {
    //     pais : 'Spain', 
    //     ciudad : 'Jaen',
    //     zonaHoraria : "Europe/Madrid",
    //     latitud : 0, 
    //     longitud : 0
    // }
    // insertDocuments(db, documento, (err, resultado) => {
    //     if (err) console.log(err)
    //     else console.log(resultado)
    //     client.close()
        
        
    // }) 
    // updateCountry(db, 'España', 'Spain', (err, resultado) => {
    //     if (err) console.log(err)
    //     else console.log(resultado.result.n)
    //     client.close()
        
        
    // })

    removeCountry(db, 'France', (err, resultado) => {
        if (err) console.log(err)
        else (resultado)
        client.close()
        
    })
  
});