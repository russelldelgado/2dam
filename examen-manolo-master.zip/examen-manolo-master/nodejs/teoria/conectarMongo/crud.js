export const findDocuments = function(db, res, callbac) {
  
    // Get the documents collection
    // Find some documents
    const collection = db.collection('geografia');
    collection.find({pais : 'Spain'}).toArray(function(err, data) {
     // console.log(docs)
     res.statusCode = 200
     res.setHeader('Content-Type', 'text/plain')
     res.end(JSON.stringify(data))
     // callback(docs);
    });
}
// const findByCountry = function (db, pais, callback) {
//     const collection = db.collection('geografia');
//     collection.find({pais : pais}).toArray(function(err, docs) {
//               callback(err, docs);
//           });
// }
// const insertDocuments = function(db, documento, callback) {
//     // Get the documents collection
//     const collection = db.collection('geografia');
//     // Insert some documents
//     collection.insertOne( documento, function(err, result) {
   
//       callback(err, result);
//     });
//   }
//   const updateCountry = function(db, paisOld, paisNew, callback) {
//     // Get the documents collection
//     const collection = db.collection('geografia');
//     // Update document where a is 2, set b equal to 1
//     collection.updateMany({ pais : paisOld }
//       , { $set: { pais : paisNew } }, function(err, result) {
//       callback(result);
//     });  
//   }
//   const removeCountry = function(db, pais, callback) {
//     // Get the documents collection
//     const collection = db.collection('geografia');
//     // Delete document where a is 3
//     collection.deleteMany({ pais : pais }, function(err, result) {
     
//       callback(result);
//     });    
//   }

// exports.findByCountry=findByCountry
// exports.insertDocuments=insertDocuments
// exports.updateCountry=updateCountry
// exports.removeCountry=removeCountry