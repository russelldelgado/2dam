import {readFileSync} from 'fs'
console.log('inicio de programa')
for (let i = 0; i < 50; i++) {
    const data = readFileSync('/etc/passwd', 'utf-8')
    console.log(data)
}
console.log('fin de programa')


