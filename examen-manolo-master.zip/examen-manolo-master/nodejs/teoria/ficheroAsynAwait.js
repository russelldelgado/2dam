import {readFile} from 'fs'

const leerFichero = (nombreFichero) => {
    return new Promise ((resolve, reject) => {
        readFile(nombreFichero, 'utf-8', (err, data) => {
            if (err) reject(err)
            else resolve(data)
        })
    })
}
console.log('inicio de programa')


async function lecturaAsincrona () {
    try {
        const datos =  await leerFichero ('/etc/passwd') 
        console.log(datos)
    } catch (error) {
        console.log(error)
    }
}

lecturaAsincrona()

console.log('fin de programa')

