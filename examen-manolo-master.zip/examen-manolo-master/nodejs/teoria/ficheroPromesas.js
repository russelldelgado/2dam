import {readFile} from 'fs'

const leerFichero = (nombreFichero) => {
    return new Promise ((resolve, reject) => {
        readFile(nombreFichero, 'utf-8', (err, data) => {
            if (err) reject(err)
            else resolve(data)
        })
    })
}
console.log('inicio de programa')

leerFichero('/etc/pass')
    .then((data) => console.log(data))
    .catch((err) => console.log(err))

console.log('fin de programa')

