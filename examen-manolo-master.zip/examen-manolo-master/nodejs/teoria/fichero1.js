const dividir = (dividendo, divisor, callback) => {
    setTimeout (() => {
        if (divisor == 0) return callback ('división por cero', null)
        else return callback (null, dividendo / divisor)
                }, 1000)
    
}
console.log('inicio de programa')

// console.log(dividir (20 ,3))
// console.log(dividir (20 ,3))
dividir (20 , 3 , (err, resultado) => {
    if (err) console.log(err)
    else dividir (resultado , 3 , (err, datos) => {
        if (err) console.log(err)
        else dividir (datos , 3 , (err, data) => {
            if (err) console.log(err)
            else console.log(data)
        })
    })
})
dividir (20 , 0 , (err, resultado) => {
    if (err) console.log(err)
    else console.log(resultado)
})

console.log('fin de programa')

