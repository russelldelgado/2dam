import {readFile} from 'fs'

console.log('inicio de programa')
readFile('etc/passwd', 'utf-8', (error, datos) => {
    if (error) throw error
    console.log(datos)
})
console.log('fin de programa')

