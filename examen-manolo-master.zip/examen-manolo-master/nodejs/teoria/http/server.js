import http from 'http'
import { findDocuments } from './crud'
import {MongoClient} from 'mongodb'

const hostname = '127.0.0.1'
const port = 7000
// Connection URL
const url = 'mongodb://172.17.0.2:27017';

// Database Name
const dbName = 'ejemplo';

// Create a new MongoClient
const client = new MongoClient(url, { useUnifiedTopology: true });
const server = http.createServer((req, res) => {
    if (req.url == '/') {
        res.statusCode = 200
        res.setHeader('Content-Type', 'text/plain')
        res.end('Hello World\n')
    }
  else if (req.url == '/paises') {
    
    client.connect(function(err) {
        if (err) throw err
        console.log("Connected successfully to server");
        const db = client.db(dbName);
        findDocuments(db, res, function (){
        
                   
                
                client.close()
           
            })
        })
    }
    else {
        res.statusCode = 404
        res.setHeader('Content-Type', 'text/plain')
        res.end('Página no encontrada') 
    }

})

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`)
})