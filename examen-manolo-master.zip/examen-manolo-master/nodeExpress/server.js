import express from 'express'
//import axios from 'axios'
import handler from './endpoints/users'
import bodyParser from 'body-parser'

const app = express()
const port = 3000

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
 
// parse application/json
app.use(bodyParser.json())

//rutas
app.get('/', (req, res) => {
    res.send('Servicio web')
})
app.get('/users', handler.getAll)
app.get('/users/:id', handler.getById)
app.post('/users', handler.createUser)
app.delete('/users/:id', handler.deleteUserById)
app.put('/users/:id', handler.updateById)



app.listen(port, () => {
  console.log(`Servicio en http://localhost:${port}`)
})