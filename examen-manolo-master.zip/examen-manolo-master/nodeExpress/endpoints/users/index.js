import axios from 'axios'
const handler = {
    getAll:  async (req, res) => {
        try {
            const { data } = await axios.get('https://jsonplaceholder.typicode.com/users')
            res
                .status(200)
                .json(data)
        } catch (error) {
            res
                .status(400)
                .json({error : 'Mala petición'})
        }
    },
    getById:  async (req, res) => {
        const { id } = req.params
        try {
            const { data } = await axios.get(`https://jsonplaceholder.typicode.com/users/${id}`)
            res
                .status(200)
                .json(data)
        } catch (error) {
            res
               .status(404)
               .json({error : 'Recurso no encontrado'})
                
        }
    },
    createUser:  async (req, res) => {
        const { body }  = req
        try {
            const { data } = await axios.post(`https://jsonplaceholder.typicode.com/users/`, body)
            res
                .status(201)
                .json(data)
        } catch (error) {
            res
                .status(500)
                .json({error : 'Error de servidor'})
        }
    },
    deleteUserById:  async (req, res) => {
        const { id } = req.params
            //console.log(id)
        
        try {
            
            const { data } = await axios.delete(`https://jsonplaceholder.typicode.com/users/${id}`)

           // console.log(data)
            
            res
                .status(200)
                .json(data)
        } catch (error) {
            res
               .status(404)
               .json({error : 'Recurso no encontrado'})
                
        }
    },
    updateById:  async (req, res) => {
        const { id } = req.params
        const { body }  = req
        
        try {
            
            const { data } = await axios.put(`https://jsonplaceholder.typicode.com/users/${id}`, body)
            res
                .status(200)
                .json(data)
        } catch (error) {
            res
               .status(404)
               .json({error : 'Recurso no encontrado'})
                
        }
    }
}
export default handler