class Documento {
    constructor (titulo, autor, publicado) {
        this.titulo    = titulo
        this.autor     = autor
        this.publicado = publicado
    }
    publicar() {
        this.publicado = true
    }
    toString() {
        return `Documento ${this.titulo}, autor ${this.autor}, publicado: ${this.publicado}`
    }
    static publicarDocumento (documento) {
        documento.publicar()
    }
}

class Libro extends Documento { //suponemos que los libros están publicados
    constructor (titulo, autor, genero) {
        super (titulo, autor, true)
        this.genero = genero
    }
    toString () {
        return `Libro del genero ${this.genero}, ${super.toString()}`
    }
}



const documento1 =  new Documento("titulo1", "autor1", false)
console.log(documento1.toString()) 
Documento.publicarDocumento(documento1)
console.log(documento1.toString())

const libro1 = new Libro ('el quijote', 'cervantes', 'novela')
console.log(libro1.toString())

//LITERALES OBJETO
const documento2 = {
    titulo : 'titulo2',
    autor  : 'autor2',
    publicado : false,
    toString : () => `TÍTULO: ${documento2.titulo}, AUTOR: ${documento2.autor}, PUBLICADO: ${documento2.publicado}`
}
console.log(documento2.toString())
//Documento.publicarDocumento(documento2)
documento2.publicado = true
//documento2 = documento1 no se puede cambiar la referencia, es const
console.log(documento2.toString())

const libro2 = {}
libro2.titulo = 'la celestina'
libro2.autor  = 'anónimo'
libro2.publicado = true
libro2.genero = 'novela'
console.log(libro2)

const libro3 = {}
libro3['titulo'] = 'romancero gitano'
libro3['autor'] = 'garcía lorca'
libro3['publicado'] = true
libro3['genero'] = 'poesía'
console.log(libro3)



