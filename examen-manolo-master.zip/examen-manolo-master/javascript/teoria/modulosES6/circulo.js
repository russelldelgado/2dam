const PI = Math.PI

export const area     = radio => PI * radio ** 2
export const longitud = radio => 2 * PI * radio