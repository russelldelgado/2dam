var _circulo = require("./circulo");

var radio = 2.2;
var superficie = (0, _circulo.area)(radio);
var perimetro = (0, _circulo.longitud)(radio);
console.log("El \xE1rea del c\xEDrculo de radio ".concat(radio, " vale ").concat(superficie.toFixed(2)));
console.log("La longitud del c\xEDrculo de radio ".concat(radio, " vale ").concat(perimetro.toFixed(2)));