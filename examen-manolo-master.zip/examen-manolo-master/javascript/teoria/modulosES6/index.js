import {area as source, longitud} from './circulo'

const radio = 2.2
const superficie = source(radio)
const perimetro = longitud(radio)

console.log(`El área del círculo de radio ${radio} vale ${superficie.toFixed(2)}`)
console.log(`La longitud del círculo de radio ${radio} vale ${perimetro.toFixed(2)}`)