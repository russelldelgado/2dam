const palabras = ['uno', 'dos', 'tres', 'cuatro' ,'cinco'].filter(elemento => elemento.length > 4)
console.log(palabras)

const esSuficienteMenteGrande = (elemento) => elemento >= 10
const numeros = [1, 2, 56, 55, 1, 5].filter(esSuficienteMenteGrande)
console.log(numeros)

const buscarPares = (...elementos) =>
        elementos.filter(elemento => elemento % 2 == 0)
console.log(buscarPares(...[1 ,2 , 3, 4, 5]))

const ordenadores = [
    {id : 1, arq : 'ARM'}, 
    {id : 2, arq : 'Intel'} , 
    {id : 3, arq : 'Intel'} , 
    {id : 4, arq : 'ARM'}
]

const equiposARM = ordenadores.filter(equipo => equipo.arq == 'ARM')
const idARM      = equiposARM.map(equipo => equipo.id)
console.log(equiposARM)
console.log(idARM)
const idIntel = ordenadores.filter(equipo => equipo.arq == 'Intel')
                           .map(equipo => equipo.id) 
console.log(idIntel)

const multiplicacionImpares = [1, 2, 3, 4, 5].filter(numero => numero % 2 == 1)
                                             .reduce((acumulado, valorActual) =>
                                             acumulado * valorActual )
console.log(multiplicacionImpares)