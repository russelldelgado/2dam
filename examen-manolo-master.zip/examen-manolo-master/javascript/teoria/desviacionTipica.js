//leer los valores como argumentos
if (process.argv.length < 3) {  //process.arg en Java es String[] args
    console.log('Faltan los valores')  //solo que aquí el primer elemento es node
    process.exit(1)     //el segundo el nombre del fichero
}
const valores = [] //guardo los posibles valores

for (let i = 2; i < process.argv.length; i++) {
    if (/[0-9]+/.test(process.argv[i])) {
        valores.push(process.argv[i] * 1)  //convierto a número
    }
}



const desviacionTipica = (...valores) => {
    if (valores.length == 0) {
        return 0
    }   
    const media = valorMedio(...valores)
    let suma = 0
    for (const valor of valores) {
        suma += (valor - media) ** 2

    }
    return Math.sqrt(suma / valores.length)
}

// const valorMedio = (...valores) => {
//     let suma = 0
//     for (const valor of valores) {
//         suma += valor
//     }
//     return suma / valores.length
// }

const valorMedio = (...valores) => {
    if (valores.length == 0) {
        return 0
    }
   return valores.reduce((valorAnterior, valorActual) => valorAnterior + valorActual) / valores.length
}




console.log(`Valor medio: ${valorMedio(...valores).toFixed(3)}`)
console.log(`Desviación típica: ${desviacionTipica(...valores).toFixed(3)}`)  //destructuración del array 
