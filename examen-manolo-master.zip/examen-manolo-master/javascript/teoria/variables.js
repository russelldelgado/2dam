var global, local
console.log(global, local)
if (true) {
    global = 'soy global'
    let local = 'soy local'
}
console.log(global, local) 
