let numero = '112'
console.log(numero, typeof numero)
numero *= 2
console.log(numero, typeof numero)
const otroNumero = '111001'
console.log(otroNumero, parseInt(otroNumero,2))
const noNumero = 'elefante'
console.log(noNumero, parseInt(noNumero,2), typeof parseInt(noNumero,2))
