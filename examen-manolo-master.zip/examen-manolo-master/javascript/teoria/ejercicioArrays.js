const personas = [  { nombre : 'luis',   genero : 'masculino', edad : 12},
                    { nombre : 'andrés',  genero : 'masculino', edad : 72},
                    { nombre : 'luisa',  genero : 'femenino',  edad : 12},
                    { nombre : 'pepa',   genero : 'femenino',  edad : 22},
                    { nombre : 'manu',   genero : 'masculino', edad : 32},
                    { nombre : 'esther', genero : 'femenino',  edad : 42},
                    { nombre : 'raquel', genero : 'femenino',  edad : 52},
                    { nombre : 'pedro',  genero : 'masculino', edad : 2},
                    { nombre : 'mario',  genero : 'masculino', edad : 18},
                    { nombre : 'carol',  genero : 'femenino',  edad : 12},
]
console.log(personas)
const annadirFinalArray = (array, nuevoElemento) => { 
    array.push(nuevoElemento)
 }

annadirFinalArray (personas, { nombre : 'carol',  genero : 'femenino',  edad : 32 })
console.log(personas)
const buscarPersonas = (array, nombrePersona) => {
    const personasEncontradas = []
    for (const persona of array) {
        if (persona.nombre === nombrePersona) {
            personasEncontradas.push(persona)
        }
    }
    return personasEncontradas
 }
 console.log(buscarPersonas (personas, 'carol')) 
 console.log(buscarPersonas (personas, 'eduardo')) 
 console.log(buscarPersonas (personas, 'pepa')) 