let string = 'esto es una cadena'
console.log(string.toUpperCase())
console.log(string.startsWith('E'))
console.log(string.indexOf('e'))
console.log(string.lastIndexOf('e'))
let cadenaSplit = string.split(' ')
console.log(typeof cadenaSplit, cadenaSplit.length)
cadenaSplit.forEach( (valor) => console.log(`TOKEN: ${valor}`))
