const electrodomestico = (precio = 100, color = 'blanco', consumo = 'F') => {
    //si precio no está comprendido entre 100 y 1000 precio será 100
    //sino el precio que venga
    let _precio, _color, _consumo
    if (precio < 100 || precio > 1000) {
         _precio = 100
    } else {
        _precio = precio
    }
    //si color no es blanco, negro o gris, color es blanco
    //sino color que venga
    if (/(gris|negro)/.test(color.toLowerCase())) {
        _color = color
    } else {    //si es gris y negro lo permito, sino blanco
        _color = 'blanco'
    }
    //si la letra no está entre A-F, la letra es F
    //sino la letra que venga
    if (/[A-E]/.test(consumo.toUpperCase())) {
        _consumo = consumo
    } else {
        _consumo = 'F'
    }

    //definimos la funcion información con un template
    //Electrodomestico con precio XXXX, color XXX y consumo energético X
    const informacion = () => `Electrodomestico con precio ${_precio}, color ${_color} y consumo energético ${_consumo}`
    //setter de precio
    const setPrecio = (nuevoPrecio) => {
        if (nuevoPrecio >= 100 && nuevoPrecio <= 1000){
            _precio = nuevoPrecio
        }
    }
    
    //función que devuelva el electrodomestico mas barato cuando le pasamos un
    //array de electrodomésticos
    const electrodomesticoMasBarato = (...electrodomesticos) => {
        electrodomesticos.forEach(electrodomestico => console.log(electrodomestico)
        )
        //si no vienen electrodomésticos, devolvemos mensaje y no procesamos
        //return el electrodoméstico mas barato en precio
    }

    //return devolvemos la función informacion con otro nombre, ej caracteristica
    return { caracteristicas : informacion, cambiarPrecio : setPrecio,
             electrodomesticoMasBarato : electrodomesticoMasBarato }
}

const electrodomestico1 = electrodomestico()
console.log(electrodomestico1.caracteristicas())

const electrodomestico2 = electrodomestico(800, 'amarillo', 'D')
console.log(electrodomestico2.caracteristicas())

const electrodomestico3 = electrodomestico(500, 'gris', 'B')
electrodomestico3.cambiarPrecio(600)
electrodomestico3.cambiarPrecio(6000)
console.log(electrodomestico3.caracteristicas())

// console.log(electrodomestico().electrodomesticoMasBarato(
//     electrodomestico1, electrodomestico2, electrodomestico3).caracteristicas())

electrodomestico().electrodomesticoMasBarato(electrodomestico1, electrodomestico2, electrodomestico3)