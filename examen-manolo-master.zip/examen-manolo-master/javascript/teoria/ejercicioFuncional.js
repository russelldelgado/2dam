const personas = [  { nombre : 'luis',   genero : 'masculino', edad : 12},
                    { nombre : 'andrés',  genero : 'masculino', edad : 72},
                    { nombre : 'luisa',  genero : 'femenino',  edad : 12},
                    { nombre : 'pepa',   genero : 'femenino',  edad : 22},
                    { nombre : 'manu',   genero : 'masculino', edad : 32},
                    { nombre : 'esther', genero : 'femenino',  edad : 42},
                    { nombre : 'raquel', genero : 'femenino',  edad : 52},
                    { nombre : 'pedro',  genero : 'masculino', edad : 2},
                    { nombre : 'mario',  genero : 'masculino', edad : 18},
                    { nombre : 'carol',  genero : 'femenino',  edad : 12},
]

const buscarPorGenero = 
    (personas, genero) => personas.filter (persona => persona.genero == genero)

console.log(buscarPorGenero(personas, 'femenino'))

const nombresPorEdad =
    (personas, edad) => personas.filter(persona => persona.edad == edad)
                                .map(persona => persona.nombre)

console.log(nombresPorEdad(personas, 42))

const edadMediaPorGenero = 
    (array, genero) => (array.filter (persona => persona.genero == genero)
                             .map    (persona => persona.edad)
                             .reduce ((acumulador, valorActual) => acumulador + valorActual)) 
                                        / buscarPorGenero(array, genero).length 

console.log(edadMediaPorGenero(personas, 'masculino'))
console.log(edadMediaPorGenero(personas, 'femenino'))