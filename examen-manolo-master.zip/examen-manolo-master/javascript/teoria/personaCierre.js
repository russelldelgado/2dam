const persona = (nombre = 'sin nombre', edad = 0) => {
    //variables instancia  ??????
    let _nombre = nombre
    let _edad   = edad
    //getters y setters  y resto de métodos ????
    const getNombre = () => `Nombre: ${_nombre}`
    const setNombre = (nuevoNombre) => _nombre = nuevoNombre 
    const setEdad   = (nuevaEdad) => _edad = nuevaEdad 
    const toString  = () => `${getNombre()}, edad: ${_edad}`
    const mayorEdad = () => _edad > 17

    //definir interfaz 
    return { obtenerNombre : getNombre, cambiarEdad : setEdad, 
        cambiarNombre : setNombre, informacion : toString, mayoria : mayorEdad }
}

const persona1 = persona()
console.log(persona1.obtenerNombre(), persona1.informacion(), persona1.mayoria())
persona1.cambiarNombre('Roberto')
persona1.cambiarEdad(18)
console.log(persona1.obtenerNombre(), persona1.informacion(), persona1.mayoria())

const persona2 = persona('felipe')
console.log(persona2.obtenerNombre(), persona2.informacion(), persona2.mayoria())
persona2.cambiarEdad(14)
console.log(persona2.obtenerNombre(), persona2.informacion(), persona2.mayoria())


const persona3 = persona('marisa', 44)
console.log(persona3.obtenerNombre(), persona3.informacion(), persona3.mayoria())
