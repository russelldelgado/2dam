class Electrodomestico {
    constructor (precio = 100, color = 'blanco', consumo = 'F') {
        if (/(gris|negro)/.test(color.toLowerCase())) {
            this.color = color
        } else {    //si es gris y negro lo permito, sino blanco
            this.color = 'blanco'
        }
        if (precio < 100 || precio > 1000) {
            this.precio = 100
        } else {
            this.precio = precio
        }
        if (/[A-E]/.test(consumo.toUpperCase())) {
            this.consumo = consumo
        } else {
            this.consumo = 'F'
        }
    }
    setPrecio (nuevoPrecio) {
        if (nuevoPrecio >= 100 && nuevoPrecio <= 1000){
            this.precio = nuevoPrecio
        }
    }
    informacion () { return `Electrodomestico con precio ${this.precio}, color ${this.color} y consumo energético ${this.consumo}` }
    static electrodomesticosMasCaros (...electrodomesticos) {
        console.log(electrodomesticos)
        
        let eMc = []
        let precioMasCaro = 0
        electrodomesticos.forEach(electrodomestico => {
            if (electrodomestico.precio > precioMasCaro ) {
                eMc = []
                eMc.push(electrodomestico)
                precioMasCaro = electrodomestico.precio
            }
            else if (electrodomestico.precio == precioMasCaro ) {
                eMc.push(electrodomestico)
            }
        })
        return eMc
    }

}

const electrodomestico1 = new Electrodomestico()
const electrodomestico2 = new Electrodomestico(800, 'amarillo', 'D')
//electrodomestico2 = electrodomestico1 //no funciona porque son const
electrodomestico2.setPrecio(1500)
electrodomestico1.setPrecio(200)

const electrodomestico3 = new Electrodomestico(500, 'gris', 'B')

console.log(electrodomestico1.informacion())
console.log(electrodomestico2.informacion())
console.log(electrodomestico3.informacion())

const eMc = Electrodomestico.electrodomesticosMasCaros(electrodomestico1, electrodomestico2, electrodomestico3)
eMc.forEach(electrodomestico => console.log(electrodomestico.informacion())
)