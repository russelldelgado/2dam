
console.log(sumar(5,3))

function sumar (x, y) {
    return x + y
}

var restar = function (x,y) {
    return x - y
}
console.log(restar(5,3))

var multiplicar = (x,y = 1) => {
    console.log(x ,y)
    return  x * y
}

console.log(multiplicar(5))

const valorMayor = (...valores ) => {
    if (valores.length === 0) {
        return 0
    }
    let maximo = valores[0]
    for (let i = 1 ; i < valores.length ; i++) {
        if (valores[i] > maximo) {
            maximo = valores[i]
        }
    }
    return maximo
}
console.log(valorMayor())
console.log(valorMayor(1,2,3,4,5,2,2))
console.log(valorMayor(...[1,2,3,4,5,2,2]))
