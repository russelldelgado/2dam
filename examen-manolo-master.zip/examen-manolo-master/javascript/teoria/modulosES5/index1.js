const circulo = require('./circulo1')
const cuadrado = require('./cuadrado')
const trianguloRectangulo = require('./trianguloRectangulo')

const radio = 2.2
const area = circulo.area(radio)
const perimetro = circulo.longitud(radio)

console.log(`El área del círculo de radio ${radio} vale ${area.toFixed(2)}`)
console.log(`La longitud del círculo de radio ${radio} vale ${perimetro.toFixed(2)}`)

const ladoCuadrado = 4.5
console.log(`El área del cuadrado de lado ${ladoCuadrado} vale ${cuadrado.area(ladoCuadrado).toFixed(2)}`)
console.log(`La longitud del círculo de radio ${ladoCuadrado} vale ${cuadrado.perimetro(ladoCuadrado).toFixed(2)}`)

const cateto1 = 2.2
const cateto2 = 6.6
const areaTriangulo = trianguloRectangulo.area(cateto1, cateto2)
const perimetroTriangulo = trianguloRectangulo.longitud(cateto1, cateto2)
console.log(`El área del triángulo rectángulo de cateto1 ${cateto1} y cateto2 ${cateto2} vale ${areaTriangulo.toFixed(2)}`)
console.log(`El perímetro del triángulo rectángulo de cateto1 ${cateto1} y cateto2 ${cateto2} vale ${perimetroTriangulo.toFixed(2)}`)