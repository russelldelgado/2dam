const superficie = require('./circulo1').area
const longitud = require('./circulo1').longitud

const radio = 2.2
const area = superficie(radio)
const perimetro = longitud(radio)

console.log(`El área del círculo de radio ${radio} vale ${area.toFixed(2)}`)
console.log(`La longitud del círculo de radio ${radio} vale ${perimetro.toFixed(2)}`)