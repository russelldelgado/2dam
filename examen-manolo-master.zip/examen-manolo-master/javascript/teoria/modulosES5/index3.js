const funcionesCirculo = require('./circulo2').funciones

const radio = 2.2
const area = funcionesCirculo.area(radio)
const perimetro = funcionesCirculo.perimetro(radio)

console.log(`El área del círculo de radio ${radio} vale ${area.toFixed(2)}`)
console.log(`La longitud del círculo de radio ${radio} vale ${perimetro.toFixed(2)}`)