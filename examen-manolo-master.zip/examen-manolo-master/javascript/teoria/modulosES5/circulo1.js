const PI = Math.PI

exports.area     = radio => PI * radio ** 2
exports.longitud = radio => 2 * PI * radio