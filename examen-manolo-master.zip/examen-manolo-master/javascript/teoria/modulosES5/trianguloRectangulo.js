exports.area = (cateto1, cateto2) => cateto1 * cateto2 / 2
exports.longitud = (cateto1, cateto2) => cateto1 + cateto2 + Math.sqrt(
                            cateto1 ** 2 + cateto2 ** 2)