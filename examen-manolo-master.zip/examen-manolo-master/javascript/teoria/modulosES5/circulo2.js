const PI = Math.PI

const area     = radio => PI * radio ** 2
const longitud = radio => 2 * PI * radio

const funciones = {area : area, perimetro : longitud}

exports.funciones = funciones