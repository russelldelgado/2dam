exports.area      = lado => lado ** 2
exports.perimetro = lado => lado * 4