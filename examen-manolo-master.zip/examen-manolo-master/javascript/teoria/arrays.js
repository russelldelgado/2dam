const array = [1,2,3, 'hola', 'adios']

//bucle clásico fori
for (let i = 0; i < array.length; i++) {
    console.log(`Posición ${i}: ${array[i]}`)
}
//bucle for of
for (let item of array) {
    console.log(`ITEM: ${item}`)
}
//foreach sobre el literal
[1,2,3, 'hola', 'adios'].forEach( item => console.log(`ITEM: ${item}`))

array.push(5)
array.unshift(0)
console.log(array)
array.pop()
console.log(array)
array.shift()
console.log(array)