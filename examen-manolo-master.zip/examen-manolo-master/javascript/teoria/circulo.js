if (process.argv.length < 3) {
    console.log('Faltan argumentos')
    process.exit(1)
}

if ( isNaN( process.argv[2] )) {
    console.log(`${process.argv[2]} no es un número`)
    process.exit(2)
}

let radio  = process.argv[2] 
let area = Math.PI * radio ** 2
let longitud = 2 * Math.PI * radio

console.log(`El círculo de radio ${radio} tiene como área ${area.toFixed(2)} y como longitud ${longitud.toFixed(2)}`)
