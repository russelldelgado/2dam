import {validarISBN, devolverISBN} from './isbn'

let isbn = process.argv[2]

if (validarISBN(isbn))
    console.log(devolverISBN(isbn));