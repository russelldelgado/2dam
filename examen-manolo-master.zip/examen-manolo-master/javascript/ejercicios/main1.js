import Coche from './coche'

const coche1 = new Coche('ford', 'fiesta', 1990)

console.log('Comprobación toString: ' + coche1.toString())
console.log('Comprobación getFechaFabricacion: ' + coche1.getFechaFabricacion())
coche1.setModelo('focus')
console.log('Comprobación setter: ' + coche1.toString())
