/*{
    "fabricante": "GMC",
    "modelo": "Canyon",
    "fechaFabricacion": 2008
  }*/

class Coche {
    constructor(fabricante, modelo, fechaFabricacion) {
        this.fabricante = fabricante
        this.modelo = modelo
        this.fechaFabricacion = fechaFabricacion
    }
    //métodos instancia getters, setters, toString()....
    toString () {
        //código
        return `FABRICANTE: ${this.fabricante}, MODELO: ${this.modelo} y FECHA FABRICACIÓN: ${this.fechaFabricacion}`
    }
    getFechaFabricacion () {
        return this.fechaFabricacion
    }
    setModelo (modelo) {
        this.modelo = modelo
    }
    //...................
    static cocheSegunAnno (arrayCoches, annoFabricacion) {
        //código
        return (arrayCoches.filter( coche => coche.fechaFabricacion == annoFabricacion)).length
    }
    static cocheSegunFabricante (arrayCoches, fabricante) {
        //código
        return (arrayCoches.filter( coche => coche.fabricante == fabricante)).length
    }
    static modelosFabricante (arrayCoches, fabricante) {
      /*  function onlyUnique(value, index, self) { 
            return self.indexOf(value) === index;
        }      */  
        const modelos =   arrayCoches.filter( coche => coche.fabricante == fabricante )
                                     .map  (coche => coche.modelo)
                                     .filter( (value, index, self) => {
                                                return self.indexOf(value) === index
                                            } )
        return modelos
        
    }

    //resto métodos estáticos
}

export default Coche