const validarISBN = (isbn) => /^84[0-9]{7}$/.test(isbn)

const devolverISBN = (isbn) => {
    let suma = 0
    for (let i = 0; i < isbn.length; i++){
        suma += isbn.charAt(i) * (i +1)
    }
    let digito = suma % 11
    if (digito == 10)
        digito = 'X'
    return isbn + '' + digito
}

export {validarISBN, devolverISBN}