import personas from './personas'

//console.log(personas)
// for(let i = 0; i < personas.length; i++) {
//     console.log(`Nombre: ${personas[i].nombre}, edad: ${personas[i].edad}`)
// }

// personas.forEach(persona => console.log(`Nombre: ${persona.nombre}, edad: ${persona.edad}`))

// for (const persona of personas) {
//     console.log(`Nombre: ${persona.nombre}, edad: ${persona.edad}`)
// }
//bucle for in recomendado para recorrer propiedades de un objeto
//no lo recomiendo para arrays []
for (let index in personas) {
    //    console.log(personas[index])
    console.log(`Nombre: ${personas[index].nombre}, edad: ${personas[index].edad}`)
}