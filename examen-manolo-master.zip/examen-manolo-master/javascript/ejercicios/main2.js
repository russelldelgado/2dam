import cars from './cars'
import Coche from './coche'
//console.log(cars)
const fecha = 2001
const fabricante = 'Ford'
console.log(`Coches fabricados en ${fecha} son ${Coche.cocheSegunAnno(cars, fecha)}`)
console.log(`Coches del fabricante en ${fabricante} son ${Coche.cocheSegunFabricante(cars, fabricante)}`)
const coches = Coche.modelosFabricante(cars, fabricante)
console.log(coches)

