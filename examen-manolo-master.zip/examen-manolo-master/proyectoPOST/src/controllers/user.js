import User from '../models/user'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { json } from 'express'

const userController = {
    saveUser: async (req, res) => {
        const { body } = req
        try {
            const newUser = await User.create(body)
            res
                .status(201)
                .json(newUser)
        } catch (error) {
            res
                .status(500)
                .json({error: error})
        }
    },
    loginUser :async (req, res) => {
        const { login } = req.body
        const { password } = req.body
       // console.log(typeof password)
        
        try {
            const user = await User.findOne({login: login})
            if (!user) {
                return res.status(404).json({
                  message: 'not exist user'
                })
            }
            if (! (await bcrypt.compare(password + "", user.password ))) {
                return res.status(404).json({
                  message: 'incorrect password'
                })
            }
            const token = jwt.sign({login: user.login}, process.env.SECRET_KEY, { expiresIn: '1h' })
            res
                .status(200)
                .json({
                    message: 'valide user',
                    token : token
                })
        } catch (error) {
            res
                .status(400)
                .json({error: error})
        }
    },
    validateToken: (req, res, next) => {
        
        if (! req.headers.authorization) {
            return res
                    .status(401)
                    .json({error: 'unathorized'})
        }
        try {
            const token = jwt.verify(req.headers.authorization, process.env.SECRET_KEY)
            req.body.user = token.login
            next()
        } catch (error) {
            return res
                    .status(401)
                    .json({error: 'not valide token'})
        }
        
    }
}

export default userController