import Post from '../models/post'

const postController = {
    savePost: async (req, res) => {
        const { body } = req
    //    console.log(body)
        
        try {
            const newPost = await Post.create(body)
            res
                .status(201)
                .json(newPost)
        } catch (error) {
            res
                .status(500)
                .json({error: error})
        }
    },
    getAllPosts: async (req, res) => {
        
        
        try {
            const posts = await Post.find();
            res
                .status(200)
                .json(posts)
        } catch (error) {
            res
                .status(400)
                .json({error: error})
        }
    },
    getPostById: async (req, res) => {
        const _id = req.params.id
        
        
        try {
            const post = await Post.findOne({_id})
            const permitted = post.user == req.body.user || req.body.user == 'admin'
            if (!permitted) {
                return res
                    .status(403)
                    .json({error: 'forbbiden'})
            }
            res
                .status(200)
                .json(post)
        } catch (error) {
            res
                .status(400)
                .json({error: error})
        }
    },
    getPostsByUser: async (req, res) => {
        const { user } = req.params
        const permitted = user == req.body.user || req.body.user == 'admin'

        if (!permitted ) {
            return res
                    .status(403)
                    .json({error: 'forbbiden'})
        }
        try {
            const posts = await Post.find({user : user});
            res
                .status(200)
                .json(posts)
        } catch (error) {
            res
                .status(400)
                .json({error: error})
        }
    },
    deletById: async (req, res) => {
        const _id = req.params.id
        try {
            const postToDelete = await Post.findOne({_id})
            const permitted = postToDelete.user == req.body.user || req.body.user == 'admin'

            if (!permitted) {
                return res
                    .status(403)
                    .json({error: 'forbbiden'})
            } 
            const post = await Post.findByIdAndDelete({_id})
            if (!post) {
                return res.status(404).json({
                  message: 'not exist post'
                })
            }
            res
                .status(204)
                .send()
                
        } catch (error) {
            res
                .status(400)
                .json({error: error})
        }
    },
    updatePostById: async (req, res) => {
        const _id = req.params.id
        const { body } = req
        const { message } = body
        const postToUpdate = await Post.findOne({_id})
        const permitted = postToUpdate.user == req.body.user || req.body.user == 'admin'

            if (!permitted ) {
                return res
                    .status(403)
                    .json({error: 'forbbiden'})
        } 
        try {
            const post = await Post.findByIdAndUpdate(
                _id,
                { message : message },
                {new: true});
        
              if (!post) {
                return res.status(404).json({
                  message: 'not update post'
                })
              }
              res
                .status(200)
                .json(post)
            } catch (err) {
              res
                .status(500)
                .json({
                  message: err
                })
            }
          }
}

export default postController