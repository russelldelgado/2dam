import express from 'express'
import postController from '../controllers/post'
import userController from '../controllers/user'

const router = express.Router()

router.post('/',  userController.validateToken, postController.savePost)
router.get('/', postController.getAllPosts)
router.get('/:id', userController.validateToken, postController.getPostById)
router.get('/user/:user', userController.validateToken, postController.getPostsByUser)
router.delete('/:id',userController.validateToken, postController.deletById)
router.put('/:id',userController.validateToken, postController.updatePostById)




export default router