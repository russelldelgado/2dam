import postRouter from './routes/post'
import userRouter from './routes/user'

export default (app) => {

    app.get('/', async (req, res) => {
        res.send('Servicio web, recursos post')
    })
    app.use('/post', postRouter)
    app.use('/user', userRouter)

}