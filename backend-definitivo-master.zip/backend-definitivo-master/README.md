# Backend Museo

## Especificaciones

BackendMuseo es un proyecto hecho con Express de Node.js para listar, añadir, modificar y eliminar piezas de museo y categorías, usando Mongo para la persistencia.

## Funcionamiento

Explicado en el vídeo.

### Herramientas

- Node.js
- MongoDB
- Mongoose

### Endpoints API REST

#### CATEGORÍAS

| Método HTTP        | Endpoint           | Descripción  | Método Mongoose  |
| ------------- |:-------------:| :-----| :-----|
|   GET   | /categorias | Muestra las categorías disponibles | categoryController.getCategories() |
|    GET  |   /categoria/:id    |  Muestra información de la categoría  | categoryController.getCategory() |
|   POST   |    /guardar-categoria   |  Añade una categoría   | categoryController.saveCategory() |
|   DELETE   |    /eliminar-categoria/:id   |  Elimina una categoría   | categoryController.deleteCategory() |
|   PUT   |   /actualizar-categoria/:id    |   Actualiza una categoría  | categoryController.updateCategory() |

#### PIEZAS

| Método HTTP        | Endpoint           | Descripción  | Método Mongoose  |
| ------------- |:-------------:| :-----| :-----|
|   GET   | /piezas | Muestra las piezas disponibles | piezaController.getPiezas() |
|    GET  |   /pieza/:id    |  Muestra información de la categoría  | piezaController.getPieza() |
|   POST   |    /guardar-pieza   |  Añade una pieza   | piezaController.savePieza() |
|   DELETE   |    /eliminar-pieza/:id   |  Elimina una pieza   | piezaController.deletePieza() |
|   PUT   |   /actualizar-pieza/:id    |   Actualiza una pieza  | piezaController.updatePieza() |

#### USUARIOS

| Método HTTP        | Endpoint           | Descripción  | Método Mongoose  |
| ------------- |:-------------:| :-----| :-----|
|   POST   | /registrarUsuario | Registra un usuario | userController.saveUser() |
|    POST  |   /iniciarSesion    |  Inicia sesión  | userController.loginUser() |

### userController.validate() > Comprueba que el usuario con el que inicias sesión es válido

## Ejecutar el backend

```bash
npm run dev
```




