import mongoose from 'mongoose'
//https://carlosazaustre.es/como-relacionar-tus-modelos-en-mongodb
//var Pieza = mongoose.model('Pieza')
const Schema = mongoose.Schema;


const CategorySchema = Schema({
    nombre:{
        type:String,
        required:true,
        trim:true
    },
    imagenUrl:{
        type:String,
        trim:true
    },
    piezasDelMuseo:{
        type: [Schema.ObjectId],
        required:false,
        ref: "Pieza"
        
        
    },


},{versionKey : false});

const Category = mongoose.model('Category' , CategorySchema);

export default Category;