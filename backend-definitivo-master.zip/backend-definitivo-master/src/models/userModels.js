import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import validator from 'validator'



const Schema =mongoose.Schema;

const UserSchema = Schema({
    nombre:{
        type : String,
        required : true,
        trim:true,
    },
    apellido:{
        type:String,
        required:false,
    },
    edad:{
        type:Number,
        required:false,

    },
    email:{
        type:String,
        required:true,
        unique:true,
        trim:true,
        validate:value=>{
            if(!validator.isEmail(value)){
                throw new Error({error:'Email invalido'})
            }
        }
    },
    password:{
        type:String,
        required:true,
        minlength:7,
        trim:true

    }
},{versionKey:false});


//esta funcion se tiene que ejecutar antes de guardar la contraseña del usuario
UserSchema.pre('save' , async function(next){
    try{
        this.password = await bcrypt.hash(this.password,10)
    }catch(error){
        console.log(error);
    }
    next();
});

const User = mongoose.model('User' , UserSchema);
export default User;