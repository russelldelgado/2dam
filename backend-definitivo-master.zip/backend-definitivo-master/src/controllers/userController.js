import User from '../models/userModels'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
//import { response } from 'express';
//import { JsonWebTokenError } from 'jsonwebtoken';

const userController = {

    saveUser: async (req ,res) => {

        const {body} = req;
        console.log(req.headers)
        console.log(body)

        try{
            const userNew = await User.create(body);
            if(userNew != null){
                const token = jwt.sign({_id : userNew._id , nombre: userNew.nombre , email : userNew.email}, process.env.JWT_KEY, { expiresIn : '1h' })
                console.log(token)
                res
                    .status(201)
                    .json({message : 'valid user' , token : token });
            }else{
                res
                    .status(404)
                    .json({error : 'no se ha creado su usuario'})
            }

/*
            res
            .status(201)
            .json(userNew)
*/
        }catch(error){
            res
                .status(400)
                .json({error : error , message : "el usuario ya existe"})
        }

    },
    loginUser: async (req , res) =>{
        //console.log('en el login')
        const { body } = req; // en el cuerpo tiene que ir el correo y la contraseña

        const { password } = req.body
        const {email} = req.body
        //console.log(req.headers)
        try{

            const user = await User.findOne({email : body.email})
           // console.log('usuario completo : ' + user)
            if(!user){
                res
                    .status(401)
                    .json({error : 'usuario no valido'})
                throw new Error()
            }
            const validUser = await bcrypt.compare(body.password + "", user.password + "")
            //const validUser = true;
            //console.log(validUser);
            //console.log(typeof user.password)
            //console.log( typeof body.password)
            //console.log(process.env.JWT_KEY)
            if(validUser){
                //console.log("estamos dentro para hacer lo del token")

                const token = jwt.sign({_id : user._id , nombre: user.nombre , email : user.email}, process.env.JWT_KEY, { expiresIn : '1h' })
                //console.log(token)
                res
                    .status(200)
                    .json({message : 'valid user' , token : token})
            }else{
 
                res
                    .status(402)
                    .json({error : 'contrasena invalida'})
            }
            
        }catch(error){
            res 
                .status(403)
                .json({error : "error desconocido"})
        }


    },
    validate : async (req , res , next) => {
        console.log(req.headers)
        const token = req.headers['x-access-token']
        console.log(token)

        try{

            if(!token){
                res
                    .status(400)
                    .json({error : 'no hay token'})
                    throw new Error()
            }
            jwt.verify(token , process.env.JWT_KEY, function(err , decoded){
                if(err){
                    res
                        .status(400)
                        .json({error : 'token invalido'})
                    throw new Error()
                }
                next()
            })
        }catch(error){
            console.log(error)
            res
                .status(400)
                .json({message : 'error desconocido'})
        }

    }
};

export default userController;