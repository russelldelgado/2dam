import categoryModels from '../models/categoryModels'
import piezasModels from '../models/piezaModels'

let categoryController = {

    getCategories: async (req , res)=>{
        try{
          const categorias = await categoryModels.find();  
        
          //esta linea me vale para cuando hagan un get mandemos todos los datos de las piezas dentro de la categoria
          const piezas = await piezasModels.populate(categorias , {path: 'piezasDelMuseo'});
          res
            .status(200)
            .json(categorias);

        }catch(error){
            res
                .status(400)
                .json({error : error , mensaje : 'error al extraer los datos'})
            
        }
    },

    getCategory: async (req , res)=>{

        const _id = req.body._id;
        const _idNuevo = req.params.id
        console.log(_idNuevo);

        try{
            const categoria = await categoryModels.findById(_idNuevo)
            const piezas = await piezasModels.populate(categoria , {path: 'piezasDelMuseo'});

            if(!categoria){
                res
                    .status(404)
                    .json({mensaje : 'categoria no encontrada'})
                    throw new Error()
            }
            res
                .status(200)
                .json(categoria)
        }catch(error){
            res
                .status(400)
                .json({error:error})

        }

    },
    
    saveCategory: async (req , res) =>{

        const {body} = req;

        try {

            const categoriaGuardada = await categoryModels.create(body)
                res
                    .status(201)
                    .json(categoriaGuardada)

        } catch (error) {
            res
                .status(500)
                .json({mensaje : error})
        }

    },
    
    deleteCategory: async (req , res)=>{

        const _id = req.params.id
        try {
            const categoriaEliminada = await categoryModels.findByIdAndDelete({_id});

            if(!categoriaEliminada){
                res
                    .status(404)
                    .json({mensaje : 'no se ha podido eliminar la categoria'})
                throw new Error()
            }
           
            res
                .status(200)
                .json({categoriaEliminada : categoriaEliminada , mensaje : 'eliminado correctamente'})

        } catch (error) {
            res
                .status(400)
                .json({error : error , mensaje2 : 'NOS SALE UNDEFINED EL ID'})
        }


    },
    
    updateCategory: async (req , res) => {

        const  id  = req.params.id
        const { body }  =req

        console.log('id--------------------de la categoria -------' + id)
        console.log(body)

        try {

            const categoriaActualizada = await categoryModels.findByIdAndUpdate(id , body , {new:true});
            console.log(categoriaActualizada)
            if(!categoriaActualizada){
                res
                    .status(404)
                    .json({error : 'error al actualizar la categoria'})
                throw new Error()
            }

            res
                .status(201)
                .json(categoriaActualizada)

        } catch (error) {
            res
                .status(500)
                .json({error : error})
        }


    }

};

export default categoryController ;