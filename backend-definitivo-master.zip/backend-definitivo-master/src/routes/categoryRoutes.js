import express from 'express'
import categoryController from '../controllers/categoryControllers'
import userController from '../controllers/userController'

const routes = express.Router();


routes.get('/categorias',  categoryController.getCategories);
routes.get('/categoria/:id' , categoryController.getCategory);
routes.post('/guardar-categoria' ,userController.validate , categoryController.saveCategory);
routes.delete('/eliminar-categoria/:id' ,userController.validate , categoryController.deleteCategory);
routes.put('/actualizar-categoria/:id' ,userController.validate , categoryController.updateCategory);

export default routes;  