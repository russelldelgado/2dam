import 'dart:io';

//donde esta el directorio de documentos

Future<String> get rutaDelDirectorio async {
  final directory = await Directory.systemTemp.createTemp();
  
  return directory.path;
}

//crear un referencia a la ubicacion del archivo

Future<File> get ficheroLocal async {
  final path = await rutaDelDirectorio;
  return File('$path/counter.txt');
}

//escribir datos en el archivo

Future<File> escribirDatos(String datos) async {
  final file = await ficheroLocal;
  
  return file.writeAsString('$datos');
}


//leer los documentos del archivo

Future<int> leerDatos() async {
  try {
    final file = await ficheroLocal;

    var contents = await file.readAsString();

    return int.parse(contents);
  } catch (e) {
    // If we encounter an error, return 0
    return 0;
  }
}