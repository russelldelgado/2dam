import 'package:proyecto/modelos/persona.dart';

abstract class PersonasParseador{

  Future<List<Persona>> listaDePersonasParaParsear(); 
  Future<Persona> parseandoPersona(String nombre , String deporte);


}