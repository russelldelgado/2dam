import 'package:http/http.dart' as http;
import 'package:html/parser.dart' as html;
import 'package:proyecto/modelos/persona.dart';
import 'package:proyecto/parser/parseadorgeneral.dart';


class ClaseParseadoraEspecifica implements PersonasParseador{

  static const dominio = 'sportuniverse.com';
  static const uris = 'Instalaciones/Buscar';
  
  _devolverUriComoPaginaweb() => Uri.http(dominio, uris);

  @override
  Future<List<Persona>> listaDePersonasParaParsear() async {
   
 var personas = <Persona>[];
    var url = _devolverUriComoPaginaweb();
    var response = await http.get(url);
    if (response.statusCode == 200) {
      var document = html.parse(response.body);
      var nombreDePersonas = document.querySelectorAll('.text-name');
      var nombreDeDeporte = document.querySelectorAll('.event-organizacion');

    for(int i = 0 ; i< nombreDePersonas.length ; i++){

      var nombre = nombreDePersonas[i].text;
      var deporte = nombreDeDeporte[i].text;

      var estaSiEsUnapersona = await parseandoPersona(nombre, deporte);

      personas.add(estaSiEsUnapersona);
    }

/*
      for (var anchor in nombreDePersonas) {
        var estasiespersona = await parseandoPersona(anchor.text , "VACIO");
        personas.add(estasiespersona);
      }
*/

    }

    
    return personas;

  }



  @override
  Future<Persona> parseandoPersona(String nombre , String deporte) async{
  
    return Persona(nombre , deporte);

  }


}
