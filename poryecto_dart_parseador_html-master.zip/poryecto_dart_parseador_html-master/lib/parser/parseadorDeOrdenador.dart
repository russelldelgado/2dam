import 'package:proyecto/modelos/ordenador.dart' ;
import 'package:html/parser.dart' as html;
import 'package:http/http.dart' as http;


class ClaseParseadoraDeORdeanodres {

static const dominio = 'https://www.pccomponentes.com/';
static const topUri = '' ;

Uri devolverPaginaWeb() => Uri.https(dominio , topUri);

Future<List<Ordenador>> devolverListaDeOrdenadores() async{

  var ordenadores = <Ordenador>[];
  var url = devolverListaDeOrdenadores();

  var response = await http.get(url);
  print(response.body);

  if(response.statusCode == 200){
      var document = html.parse(response.body);
      var productos = document.querySelectorAll('.product');
      print(productos);
      for (var item in productos) {
        print(item.text);
        var producto = new Ordenador(item.text, 0);
        ordenadores.add(producto);
      }
  }

return ordenadores;

}


}