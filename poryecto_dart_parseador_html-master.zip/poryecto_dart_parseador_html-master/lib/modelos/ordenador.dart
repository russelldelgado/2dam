class Ordenador {

  String nombreProducto ;
  int preciProducto ;

  Ordenador(this.nombreProducto , this.preciProducto);

  @override
  String toString() {
    return '$nombreProducto , $preciProducto' ; 
  }


}