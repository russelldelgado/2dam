class Persona{
    String nombre;
    String deporte ;
  Persona(this.nombre , this.deporte);


@override
  String toString() {
    return '{$nombre} , {$deporte}';
  }
}