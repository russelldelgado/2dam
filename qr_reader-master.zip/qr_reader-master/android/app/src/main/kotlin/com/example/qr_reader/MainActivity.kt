package com.example.qr_reader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
