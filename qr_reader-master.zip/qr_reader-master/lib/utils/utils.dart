

import 'package:flutter/cupertino.dart';
import 'package:qr_reader/models/scan_model.dart';
import 'package:url_launcher/url_launcher.dart';

void launchURL(BuildContext context , ScanModel scan) async{

  final  url = scan.valor;
  print(url);

  if(scan.tipo == 'http'){
    //abrir el sitio wweb
      if(await canLaunch(url)){
        print('url correcta');
        await launch(url);
        print('url correcta');
      }else{
        print('error en la url');

        throw 'no funciona la url $url';
      }
  }else {
    Navigator.pushNamed(context, 'mapa' , arguments: scan);
  }


}
