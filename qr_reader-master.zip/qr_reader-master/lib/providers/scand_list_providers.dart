

import 'package:flutter/material.dart';
import 'package:qr_reader/providers/db_provider.dart';

class ScandListProdiver extends ChangeNotifier {

  List<ScanModel> scans = [];
  String tipoSeleccionado = 'http';



  Future<ScanModel>  nuevoScan(String valor) async{
    //esto crea la instancia pero no lo inserta ne la base de datos ;
    final nuevoScan = new ScanModel(valor: valor);
    final id = await DBProvider.db.nuevoScan(nuevoScan);
    //con esto asignamos el id de la base de datos al modelo
    nuevoScan.id = id;
    if(this.tipoSeleccionado == nuevoScan.tipo){
    this.scans.add(nuevoScan);
    notifyListeners();
    }

    return nuevoScan;
    
  }

  cargarScand()async{
    final scans = await DBProvider.db.getTodosLosScand();
     this.scans = [...scans]; //[...] esto quire decir que te cree un nuevo listado para no trabajar con las referencias
     notifyListeners();

  }

  cargarScandPorTipo( String tipo ) async{
    final scans = await DBProvider.db.getScandporTipo(tipo);
     this.scans = [...scans]; //[...] esto quire decir que te cree un nuevo listado para no trabajar con las referencias
    this.tipoSeleccionado = tipo;
  }
   
   borrarTodos()async{
     await DBProvider.db.deleteAllScand();
     this.scans = [];
     notifyListeners();
   }

   borrarScandPorId(int id) async{
    await DBProvider.db.deleteScnad(id);
   }

}