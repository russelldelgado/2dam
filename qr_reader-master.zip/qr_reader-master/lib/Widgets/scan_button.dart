import 'package:flutter/material.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:provider/provider.dart';
import 'package:qr_reader/providers/scand_list_providers.dart';
import 'package:qr_reader/utils/utils.dart';


class ScanButton extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      elevation: 0,
      child: Icon(Icons.filter_center_focus),
      onPressed: ()async{
      String barcodeScanRes = await FlutterBarcodeScanner.scanBarcode('#3D8BEF','CANCELAR',false,ScanMode.QR);
      //final barcodeScanRes = 'https://www.fernando-herrera.com/#/home';
      //final barcodeScanRes = 'geo:37.779353,-3.788050';
     // print(barcodeScanRes);37.779353, -3.788050

     if(barcodeScanRes == '-1') return;
      final scandListProvider = Provider.of<ScandListProdiver>(context , listen: false); // COMO ESTOY EN UN METODO O EN UNA FUNCION TENGO QUE PONER QUE NO SE VUELVA A REDIBUJAR
      final nuevoScan = await scandListProvider.nuevoScan(barcodeScanRes);
       //final nuevoScan = await scandListProvider.nuevoScan(geolocalizacion);

      launchURL(context, nuevoScan);

      }, 
      );
  }
}