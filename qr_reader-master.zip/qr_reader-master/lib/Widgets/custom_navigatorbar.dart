import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_reader/providers/ui_provider.dart';

class CustomNavigationBar extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
  final uiProvider = Provider.of<UiProvider>(context);
  final currenIndex = uiProvider.selectedMenuOpt;


    return BottomNavigationBar(
      onTap:( int value) {
        uiProvider.selectedMenuOpt = value;
      } ,
      elevation: 0,
      currentIndex: currenIndex,
      items: [
        BottomNavigationBarItem(label: 'MAPS', icon: Icon(Icons.map)),
        BottomNavigationBarItem(label: 'URL', icon: Icon(Icons.compass_calibration)),
      ]
    );
  }
}