import 'package:flutter/material.dart';
import 'package:qr_reader/Widgets/scan_tiles.dart';


class MapasPage extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
      return ScandTiles(tipo: 'http');
  }
}