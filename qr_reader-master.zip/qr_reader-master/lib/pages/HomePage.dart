
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_reader/Widgets/custom_navigatorbar.dart';
import 'package:qr_reader/Widgets/scan_button.dart';
import 'package:qr_reader/pages/direcciones_page.dart';
import 'package:qr_reader/providers/db_provider.dart';
import 'package:qr_reader/providers/scand_list_providers.dart';
import 'package:qr_reader/providers/ui_provider.dart';

import 'mapas_page.dart';

class HomePage extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(title: Text('Historial'), centerTitle: true,
      actions: [
        IconButton(
          icon:  Icon(Icons.delete_forever) , 
          onPressed: (){
            final lista =  Provider.of<ScandListProdiver>(context , listen: false);
            lista.borrarTodos();
          })
      ],
      ),
      body: _HomePageBody(),
        bottomNavigationBar: CustomNavigationBar(),
        floatingActionButton:ScanButton() ,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}


class _HomePageBody extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    //optener el selected menu opt

    final uiProvider = Provider.of<UiProvider>(context);


  //currenIndex --> opcion seleccionada
  //solo necesito cambiar esto para mostrar la pagina respectiva
    final currenIndex = uiProvider.selectedMenuOpt;

    //todo : temporal leer la base de datos
    final tempScan = ScanModel(valor: "http://google.com");
     //DBProvider.db.nuevoScan(tempScan);
      //DBProvider.db.deleteAllScand().then(print);
      //DBProvider.db.getScandById(13).then((value) => print(value.valor));
      //DBProvider.db.getTodosLosScand().then(print);

      //usar el scand list provider
      final scanListProvider = Provider.of<ScandListProdiver>(context , listen: false); //esto quiere decir que no se redibuje 
    switch(currenIndex){

      case 0:
      scanListProvider.cargarScandPorTipo('geo');
        return MapasPage();
      case 1:
      scanListProvider.cargarScandPorTipo('http');
      return DireccionesPage();
      default:
        return MapasPage();
    }

    
}

}