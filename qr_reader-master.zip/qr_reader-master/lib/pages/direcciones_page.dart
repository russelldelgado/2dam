import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_reader/Widgets/scan_tiles.dart';
import 'package:qr_reader/providers/scand_list_providers.dart';


class DireccionesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
     return ScandTiles(tipo: 'geo');
  }
}