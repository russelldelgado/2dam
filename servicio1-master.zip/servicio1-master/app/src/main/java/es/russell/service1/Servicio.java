package es.russell.service1;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Servicio extends Service {

//TextView textoCipote ;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }




    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(getApplicationContext() , "INICIANDO SERVICIO" , Toast.LENGTH_SHORT).show();

        //textoCipote = textoCipote.findViewById(R.id.textoCipote);



        try {
            Thread.sleep(3000);
            Toast.makeText(getApplicationContext() , "TEXTO PASADO 3 SEGUNDOS" , Toast.LENGTH_SHORT).show();

            MainActivity.textoCipote.setText("TERMINADO");
            //textoCipote.setText("TERMINADO");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(getApplicationContext() , "TERMINANDO SERVICIO" , Toast.LENGTH_SHORT).show();
    }
}


//debajo de los botones un text view qu epoinga cipote ne el xml
//en el servicio cunado se haya lanzado en el metod oon start que pongamos un contador de 10 segundos
//cunado temrine de pasar el timepo que cambie el contenido de ese texto que ponia cipote y poga terminado