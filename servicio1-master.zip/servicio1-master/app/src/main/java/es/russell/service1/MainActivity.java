package es.russell.service1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btninicio , btnfin;
    public static TextView textoCipote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btninicio = findViewById(R.id.btniniciarservicio);
        btnfin  =findViewById(R.id.btnpararservicio);
        btninicio.setOnClickListener(this);
        btnfin.setOnClickListener(this);

        textoCipote = findViewById(R.id.textoCipote);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.btniniciarservicio:
                startService(new Intent(getApplication() , Servicio.class));



                break;
            case R.id.btnpararservicio:
                stopService(new Intent(getApplication() , Servicio.class));
                break;

        }
    }
}