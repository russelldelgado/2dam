package com.example.nightprogramers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RealtimeDatabase extends AppCompatActivity implements View.OnClickListener {

    FloatingActionButton rtdb_boton1;
    //private DatabaseReference databaseEnTiempoRealmmm;
    private FirebaseDatabase databaseEnTiempoReal;
    EditText nombreDeUsuario;
    //EditText claveDeUsuario;
    EditText colorDeUsuario;

    EditText programador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_realtime_database);

    rtdb_boton1=(FloatingActionButton)findViewById(R.id.rtdb_boton1);
    rtdb_boton1.setOnClickListener(this);
    nombreDeUsuario=(EditText)findViewById(R.id.nombreDeUsuario);
    colorDeUsuario=(EditText)findViewById(R.id.colorDeUsuario);
    programador=(EditText)findViewById(R.id.programadorDeUsuario);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.rtdb_boton1:

                String nombreUsuario = nombreDeUsuario.getText().toString();
                String nusuario = colorDeUsuario.getText().toString();
                String programad = programador.getText().toString();
                Usuarios usuario = new Usuarios(nombreUsuario , nusuario, programad);


                databaseEnTiempoReal = FirebaseDatabase.getInstance();
                DatabaseReference mireferencia = databaseEnTiempoReal.getReference("usuarios");

                mireferencia.push().setValue(usuario);
                break;

        }

    }
}