package com.example.nightprogramers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Registrarte extends AppCompatActivity implements View.OnClickListener {

    Button botonRegistrarse ;
    Button botonCancelar;
    Button botonVolver ;

    EditText registro_nombre , registro_correo_electronico , registro_contraseña;

    FirebaseAuth baseDeDatosAutentificacion;


    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarte);

        registro_nombre =(EditText)findViewById(R.id.registro_nombre_usuario);
        registro_correo_electronico=(EditText)findViewById(R.id.registro_correo_electronico);
        registro_contraseña=(EditText)findViewById(R.id.registro_contraseña_usuario);

        baseDeDatosAutentificacion = FirebaseAuth.getInstance();

        botonRegistrarse=(Button)findViewById(R.id.registro_boton_registrar);
        botonRegistrarse.setOnClickListener(this);
        botonCancelar=(Button)findViewById(R.id.registro_boton_cancelar);
        botonVolver = (Button)findViewById(R.id.registro_boton_vovler);
        botonVolver.setOnClickListener(this);


        if (baseDeDatosAutentificacion.getCurrentUser() != null){

            startActivity(new Intent(getApplicationContext() ,MainActivity.class));
            finish();
        }


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.registro_boton_registrar:

                String nombre = registro_nombre.getText().toString().trim();
                String correo = registro_correo_electronico.getText().toString().trim();
                String contraseña = registro_contraseña.getText().toString().trim();

                if (TextUtils.isEmpty(correo)){
                    registro_correo_electronico.setError("EL CORREO ES REQUERIDO");
                    return;
                }
                if (TextUtils.isEmpty(contraseña)){
                    registro_contraseña.setError("LA CONTRASEÑA ES REQUERIDA");
                    return;
                }
                if (contraseña.length() < 6){
                    registro_contraseña.setError("CONTRASEÑA DEMASIADO CORTA");
                    return;
                }
                //ahora vamos a registrar al usuario con su contraseña y el su correo

                baseDeDatosAutentificacion.createUserWithEmailAndPassword(correo ,contraseña).addOnCompleteListener( this , new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(getApplicationContext() , "USUARIO CREADO" , Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext() , MainActivity.class));
                        }else{

                            Toast.makeText(getApplicationContext() , "ERROR : " + task.getException().getMessage() , Toast.LENGTH_SHORT).show();

                        }
                    }
                });


                break;
            case  R.id.registro_boton_cancelar:
                break;
            case R.id.registro_boton_vovler:
                Intent irAlInicioDeSecion = new Intent(this , Login.class);
                startActivity(irAlInicioDeSecion);
                break;

        }

    }
}