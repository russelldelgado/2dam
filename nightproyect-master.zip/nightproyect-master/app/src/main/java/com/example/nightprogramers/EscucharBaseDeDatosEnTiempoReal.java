package com.example.nightprogramers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EscucharBaseDeDatosEnTiempoReal extends AppCompatActivity {

    TextView leerBasededatos ;

    FirebaseDatabase basededatosparaleer  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escuchar_base_de_datos_en_tiempo_real);

        leerBasededatos = findViewById(R.id.leyendobasededatos);

        basededatosparaleer = FirebaseDatabase.getInstance();
        DatabaseReference referenciaBasededatosentera = basededatosparaleer.getReference("nombre");

        referenciaBasededatosentera.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String datos = snapshot.getValue(String.class);
                leerBasededatos.setText(datos);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}