package com.example.nightprogramers;

public class Usuarios {

    String nombre ;
    String color ;
    String programador ;


    public Usuarios() {
    }

    public Usuarios(String nombreUsuario, String nusuario, String programad) {

        this.nombre = nombreUsuario;
        this.color = nusuario;
        this.programador = programad;
    }

    public void setProgramador(String programador) {
        this.programador = programador;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getProgramador() {
        return programador;
    }
    
}
