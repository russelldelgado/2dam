package com.example.nightprogramers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button botonIniciarSecion;
    Button botonIrAlRegistro;

    EditText inicio_secion_correo , inicio_sesion_contraseña;

    private FirebaseAuth baseDeDatosInicioSecion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        botonIniciarSecion=(Button)findViewById(R.id.inicio_secion_boton_iniciar_secion);
        botonIrAlRegistro=(Button)findViewById(R.id.inicio_secion_boton_registrarse);
        botonIrAlRegistro.setOnClickListener(this);
        botonIniciarSecion.setOnClickListener(this);


        inicio_secion_correo=(EditText)findViewById(R.id.inicio_secion_correo_electronico);
        inicio_sesion_contraseña=(EditText)findViewById(R.id.inicio_secion_contraseña_usuario);

        baseDeDatosInicioSecion = FirebaseAuth.getInstance();

        FirebaseUser currentUser = baseDeDatosInicioSecion.getCurrentUser();
       // updateUI(currentUser);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.inicio_secion_boton_iniciar_secion:

                Toast.makeText(getApplicationContext() , "ESTAS PULSANDO PARA INICIAR SECION" , Toast.LENGTH_SHORT);

                String email = inicio_secion_correo.getText().toString().trim();
                String contraseña = inicio_sesion_contraseña.getText().toString().trim();

                baseDeDatosInicioSecion.signInWithEmailAndPassword(email, contraseña)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {


                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information

                                    FirebaseUser user = baseDeDatosInicioSecion.getCurrentUser();

                                    startActivity(new Intent(getApplicationContext() , MainActivity.class));

                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(getApplicationContext(), "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                break;
            case R.id.inicio_secion_boton_registrarse:
                Intent irAlRegistro = new Intent(this , Registrarte.class);
                startActivity(irAlRegistro);
                break;
        }
    }
}