

import 'package:hamburgueseria/modelos/productos.dart';

class ProductoTienda extends Producto {

  DateTime fechaDeCaducidad;
  int unidadesEnStock ;

  ProductoTienda(String nombre, String descripcion, int precio , this.fechaDeCaducidad , this.unidadesEnStock) : super(nombre, descripcion, precio);




  
}