

abstract class Producto{

  String nombre ;
  String descripcion;
  int precio ;

  Producto(this.nombre , this.descripcion , this.precio);

  @override
  String toString() {
    return 'NOMBRE : $nombre \nDESCRIPCION : $descripcion \nPRECIO : $precio';
  }



}