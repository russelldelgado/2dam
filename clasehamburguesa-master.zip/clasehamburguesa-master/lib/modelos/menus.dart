

import 'package:hamburgueseria/modelos/bebidas.dart';
import 'package:hamburgueseria/modelos/hamburguesa.dart';
import 'package:hamburgueseria/modelos/productoTienda.dart';

class Menu  extends ProductoTienda{

  Hamburguesa hamburguesa;
  Bebidas bebidas ;

  Menu(String nombre, String descripcion, int precio, DateTime fechaDeCaducidad, int unidadesEnStock , this.hamburguesa , this.bebidas) : super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock);


}