




import 'package:hamburgueseria/modelos/productoTienda.dart';

class Bebidas extends ProductoTienda {

  TipoDeBebida tipoDeBebida ;

  bool bebidaAlcoholica;

  Bebidas(String nombre, String descripcion, int precio, DateTime fechaDeCaducidad, int unidadesEnStock , TipoDeBebida tipoDeBebida , bool bebidaAlcoholica) : super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock);

  

Bebidas.alcoholicas(String nombre, String descripcion, int precio, DateTime fechaDeCaducidad, int unidadesEnStock , TipoDeBebida tipoDeBebida , bool bebidaAlcoholica ) 
 :super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock){this.bebidaAlcoholica = true;}



  

  @override
  String toString() => 'Bebidas(: $tipoDeBebida, bebidaAlcoholica: $bebidaAlcoholica)';
}

enum TipoDeBebida{

  ZERO , LIGHT , NORMAL
}