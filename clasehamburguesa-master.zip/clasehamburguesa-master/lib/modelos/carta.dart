

import 'package:hamburgueseria/modelos/bebidas.dart';
import 'package:hamburgueseria/modelos/hamburguesa.dart';
import 'package:hamburgueseria/modelos/menus.dart';
import 'package:hamburgueseria/modelos/postre.dart';

class Carta {

  Menu menu;
  Bebidas bebidas ;
  Hamburguesa hamburguesa ;
  Postres postres ;
  

}