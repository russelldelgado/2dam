

import 'package:hamburgueseria/modelos/productoTienda.dart';

class Hamburguesa extends ProductoTienda {

bool vegetariana;
TipoDeCarne tipoDeCarne;

  Hamburguesa(String nombre, String descripcion, int precio, DateTime fechaDeCaducidad, int unidadesEnStock ,  this.vegetariana,
    this.tipoDeCarne) : super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock);


 Hamburguesa.pollo({String nombre = 'hamburguesa de pollo', String descripcion = 'esta es una super hamburguesa de pollo', int precio = 19, DateTime fechaDeCaducidad , int unidadesEnStock = 100 ,  this.vegetariana = false,
    this.tipoDeCarne}) : super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock){
      this.tipoDeCarne = TipoDeCarne.POLLE;
    }

Hamburguesa.vegetariana({String nombre = 'hamburguesa de pollo', String descripcion = 'esta es una super hamburguesa de pollo', int precio = 19, DateTime fechaDeCaducidad , int unidadesEnStock = 100 ,  this.vegetariana = true,
    this.tipoDeCarne}) : super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock){
      this.tipoDeCarne = TipoDeCarne.VEGETARIANA;
    }

  @override
  String toString() => 'Hamburguesa(vegetariana: $vegetariana, tipoDeCarne: $tipoDeCarne)';


  get esVegetariana {

    if(TipoDeCarne == 'VEGETARIA'){
      return 'VEGETARIANA';
    }else{
      return 'NO VEGETARIANA';
    }

  }
//este no llegue a entenderlo muy bien asiqeu bueno lo pongo asi pero se que no es asi del todo.
  Set setesVegetariana(String tipoDeCarne){

    this.tipoDeCarne = TipoDeCarne.POLLE;
  }

}

enum TipoDeCarne{

  POLLE,TERNERA ,VEGETARIANA
}