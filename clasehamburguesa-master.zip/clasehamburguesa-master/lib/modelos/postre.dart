
import 'package:hamburgueseria/modelos/productoTienda.dart';

class Postres extends ProductoTienda{

TipoDePostre tipoDePostre;
bool postreGrande;

  Postres(String nombre, String descripcion, int precio, DateTime fechaDeCaducidad, int unidadesEnStock  ,this.tipoDePostre , this.postreGrande) : super(nombre, descripcion, precio, fechaDeCaducidad, unidadesEnStock);







  @override
  String toString() => 'Postres(tipoDePostre: $tipoDePostre, postreGrande: $postreGrande)';
}

enum TipoDePostre{

CHOCOLATE , VAINILLA , FRESA

}