//archivo para configurar  la coneccion de nuestra base de datos;
import mongoose from "mongoose";

let uri = process.env.MONGO_URI;
let uriInternet = process.env.MONGO_URI_INTERNET;
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useFindAndModify: false,
  useCreateIndex: true
};

//'mongodb://172.17.0.2:7000/ejemplo'
//'mongodb://0.0.0.0:7000/ejemplo'
//'mongodb+srv://rdandy:USUARIO@cluster0.60zda.mongodb.net/museo?retryWrites=true&w=majority'
//127.0.0.1:51614
//mongodb://localhost:27017/ejemplo
mongoose.Promise = global.Promise;
mongoose
  .connect(uriInternet, options)
  .then(() => {
    console.log("Conectado a MongoDB 💾");
  })
  .catch(err => {
    console.error(err);
    console.log(uriInternet)
  });