import express from 'express'
import piezaControllers from  '../controllers/piezaControllers'
import userController from  '../controllers/userController'
const route = express.Router();

route.get('/piezas' , piezaControllers.getPiezas)
route.get('/pieza/:id',piezaControllers.getPieza)
route.post('/guardar-pieza'  ,userController.validate ,piezaControllers.savePieza)
route.put('/actualizar-pieza/:id' ,userController.validate , piezaControllers.updatePieza)
route.delete('/eliminar-pieza/:id' ,userController.validate , piezaControllers.deletePieza)

export default route;

