console.log("API REST CREADA 😎"); 
import 'core-js/stable'
import 'regenerator-runtime/runtime'
import express from "express";
import config from "./config";
import router from './router'
import "./database";
const app = express();

// Config
config(app);

//añadimos las rutas
router(app);



app.listen(process.env.PORT, () =>
  console.log(`El servidor ha sido inicializado: http://${process.env.HOST}:${process.env.PORT}`)
);
