import mongoose from 'mongoose'
//https://carlosazaustre.es/como-relacionar-tus-modelos-en-mongodb
//https://apuntes.de/nodejs-desarrollo-web/esquemas-en-mongoose/#gsc.tab=0
//var Category = mongoose.model("Category")
const Schema = mongoose.Schema;

const objectid = mongoose.Schema.Types.ObjectId;

const PiezaSchema = Schema({
    nombre:{
        type:String,
        required :false,
        unique:false,
    },
    rutaImagen:{
        type:String,
        required:true,
        default: 'https://www.iesvirgendelcarmen.com/moodle/pluginfile.php/1/theme_moove/logo/1609800566/ESCUDO_CHICO.jpg',
    },
    descripcion:{
        type:String,
        required:false,
        default:'descripcion por defecto',
        minlength:20,
        unique:false,
        trim:true
    },
    fechaCreacion :{
        type:Date,
        default: Date.now
    },
    idCategoria : {
        type :  objectid, //para saber que es un array de objetos objectid ponemos esto entre []
//        type :Schema.Types.Array,
//        type :Array.Schema.ObjectId,
        ref: "Category"
    }
},{versionKey : false});


const Pieza = mongoose.model('Pieza',PiezaSchema);

export default Pieza;


/**
 * ejemplo de parse de la fecha para tener un formato que quiero
 * lugar de la informacion
 * 
 * https://es.stackoverflow.com/questions/253375/nodejs-establecer-un-campo-date-solo-con-el-patron-yyyy-mm-dd-en-un-schema-d
 * 
 * const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  nombre: String,
  apel_1: String,
  apel_2: String,
  email:String,
  fecha_nacimiento_iso: Date  // he cambiado el nombre del atributo para diferenciarlo del campo virtual
});

// Establecemos un campo virtual
UserSchema.virtual('fecha_nacimiento')
  .set(function(fecha) {
    // El formato esperado es 'yyyy-mm-dd' que es el devuelto por el campo input
    // el valor recibido se almacenará en el campo fecha_nacimiento_iso de nuestro documento
    this.fecha_nacimiento_iso = new Date(fecha);
  })
  .get(function(){
    // el valor devuelto será un string en formato 'yyyy-mm-dd'
    return this.fecha_nacimiento_iso.toISOString().substring(0,10);
  });

// Ya podemos exportar el modelo
module.exports = mongoose.model('User', UserSchema);
 * 
 * 
 */


4