import userRoutes from './routes/userRoutes'
import categoryRoutes from './routes/categoryRoutes'
import piezarRoutes from './routes/piezaRoutes'
const router =  (app) => {

    app.get('/', async (req, res) => {
        res.send('Routerr 💻');
    });

    app.use('/usuario' , userRoutes);
    app.use('/category' , categoryRoutes);
    app.use('/pieza',piezarRoutes);
  }

  export default router
