import piezaModels from '../models/piezaModels'
import categoriaModels from   '../models/categoryModels'
//import mongoose from 'mongoose'


let piezaControllers = {

    getPiezas: async (req , res) =>{

        try {

            const piezas = await piezaModels.find();
            //esta linea me vale para cuando hagan un get mandemos todos los datos de las piezas dentro de la categoria
            //const categoriaa = await categoriaModels.populate(piezas , {path:"idCategoria"}) 
            //console.log(categoriaa)

            res
                .status(200)
                .json({piezas :piezas})
            
        } catch (error) {
            res
            .status(400)
            .json({error : error})
        }
    },


    getPieza: async (req , res) =>{

        const _id = req.params.id

        console.log(_id)

        try {
            console.log("antes de hacer el piezafindone")
            const pieza = await piezaModels.findOne({_id});

            console.log(pieza)

            if(!pieza){
                res
                    .status(404)
                    .json({mensaje:'no hemos encontrado LA PIEZA'})
            }else{
                res
                    .status(200)
                    .json({pieza})
            }

        } catch (error) {
            res
            .status(400)
            .json({error : error})
        }
    },


    savePieza: async (req , res) =>{

        const {body} = req
        console.log('cuerpo---------------- ------------' + body)

        console.log('probando la cabecera para subir una pieza ------------' + req.params)

        try {
            const piezaGuardada = await piezaModels.create(body);
            console.log(piezaGuardada);
            console.log(req.body)
            console.log(body)
            res
                .status(201)
                .json({piezaGuardada})
            
        } catch (error) {
            res
            .status(500)
            .json({error : error})
        }
    },


    deletePieza: async (req , res) =>{
        console.log('--------------------------------------------------------------------------------------------')
        const _id = req.params.id;
        console.log(_id)
        try {
        console.log('--------------------------------------------parte 1------------------------------------------------')

        //const piezaEliminada = await piezaModels.findByIdAndRemove(_id);
        //const piezaEliminada = await piezaModels.findOneAndRemove(_id);
        const piezaEliminada = await piezaModels.findByIdAndDelete({_id});

        console.log(piezaEliminada);
            console.log('--------------------------------------------parte 2 despues de el console de la pieza------------------------------------------------')

            if(!piezaEliminada){
                res
                    .status(444)
                    .json({mensaje : 'Fallo al eliminar'})
                    throw new Error()
            }
            console.log('--------------------------------------------parte 3 despues de if de pieza eliminada------------------------------------------------')
            

            res
                .status(200)
                .json({piezaEliminada:piezaEliminada})

        } catch (error) {
            res
            .status(400)
            .json({error : error , mensaje :'algo anda mal pelotudo'})
        }
    },


    updatePieza:  async (req , res) =>{

        const _id = req.params.id;
        const { body } = req;
        console.log('-----------------------------------------------fallo con el cuerpo por el id diria yo--------')
        console.log(body)

        try {

            const piezaActualizada = await piezaModels.findByIdAndUpdate(_id , body,{new : true});

            if(!piezaActualizada){
                res
                    .status(404)
                    .json({mensaje : 'FALLO AL ACTUALIZAR'})
                    throw new Error();
            }

            res
                .status(200)
                .json(piezaActualizada)
            
        } catch (error) {
            res
            .status(500)
            .json({error : error})
        }
    },

}

export default piezaControllers;

