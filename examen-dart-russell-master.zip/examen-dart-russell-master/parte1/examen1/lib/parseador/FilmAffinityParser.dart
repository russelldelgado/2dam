import 'package:examen1/modelo/pelicula.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart';

class FilmAffinityParser {
 static const domain = 'www.imdb.com';
 static const topUrl = 'chart/top/';

    
    _rutaWebProductos() => Uri.https(domain, topUrl , {'ref' : '_nv_mv_250'});


    @override
    Future<List<Peliculas>> getTopFilmList() async {
      var arrayPelis =<Peliculas>[];

    var url = Uri.https(domain, topUrl, {'ref' : '_nv_mv_250'});

    print(url);
    var response = await get(url);
    if (response.statusCode == 200) {
    var document = parse(response.body);
    //var filmsHref = document.querySelectorAll('.clase a');
    var filmsHref = document.querySelectorAll('.titleColumn > a');
   // var filmsHref = document.querySelectorAll(' tbody .titleColumn > a');
    for (var anchor in filmsHref) {
     // print(anchor);
    var film = await filmParse(anchor.attributes['href']);
    arrayPelis.add(film);
      }
      }
      return arrayPelis;
      }

//-------------------------------parseador especifico
      
          
            filmParse(String attribut) async{

          var ruta = Uri.https(domain, attribut);

          var rutabien = ruta.toString().replaceAll('%3F', '?');
          var respuesta = await get(rutabien);
         // print(ruta);
          var titulo ='' ;
          var resumen = '';
          var puntuacion= 0.0;
          var puntuacionstring = '';
          if (respuesta.statusCode == 200) {

              var documento = parse(respuesta.body);
              titulo = documento.querySelector('.title_wrapper h1').text;
             // resumen = documento.querySelector('.ipc-html-content--base div').text;
              puntuacionstring = documento.querySelector('.ratingValue span').text;
              puntuacion = double.parse(puntuacionstring);
              //print(titulo);
              //print(resumen);
              //print(puntuacionstring);
            //  print(puntuacion);


          }else{
            print(respuesta.statusCode);
            print('mala coneccion chaval');
          }
        return Peliculas(titulo: titulo , resumen: resumen , puntucacion: puntuacion);
            }
}

main(List<String> args) {
  var pruebas = FilmAffinityParser();
  print(pruebas.getTopFilmList());
}

//https://www.imdb.com/title/tt0111161/?pf_rd_m=A2FGELUUNOQJNL&pf_rd_p=e31d89dd-322d-4646-8962-327b42fe94b1&pf_rd_r=Q6J5C5TK20CQV5CK7DT4&pf_rd_s=center-1&pf_rd_t=15506&pf_rd_i=top&ref_=chttp_tt_1
//https://www.imdb.com/title/tt0111161/%3Fpf_rd_m=A2FGELUUNOQJNL&pf_rd_p=e31d89dd-322d-4646-8962-327b42fe94b1&pf_rd_r=9FB4W8VDMZJHAJ9KNKG1&pf_rd_s=center-1&pf_rd_t=15506&pf_rd_i=top&ref_=chttp_tt_1