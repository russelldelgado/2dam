import 'dart:io';


class Peliculas{

static var peliculas = <Peliculas>[];

String titulo ;
String resumen ;
double puntucacion;

Peliculas({this.titulo = 'TITULO POR DEFECTO', this.resumen = 'RESUMEN POR DEFECTO', this.puntucacion = 0.0});

Peliculas.exito({this.titulo , this.resumen }){
  this.puntucacion = 10.0;
}


cambiarPuntucacion(double nuevaPuntuacion){

      if(nuevaPuntuacion > 10){
      this.puntucacion = 10;
    } 
    else if(nuevaPuntuacion < 0) {
      this.puntucacion = 0.0;
    }else{
      this.puntucacion = nuevaPuntuacion;
    }

}

visualizarPeliculas(){

    peliculas.forEach((pelicula) {print(pelicula.toString()); });
}

  void meterPelicula(Peliculas peli){
    peliculas.add(peli);
  }


  bool eliminarPelicula(int posicion){

      

    peliculas.remove(peliculas[posicion]);

  }


  @override
    String toString() {
      return 'titulo : ${titulo} , resumen ${resumen} , puntuacion ${puntucacion} ';
    }

 

}

