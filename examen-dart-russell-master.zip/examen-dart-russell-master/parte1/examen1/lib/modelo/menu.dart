import 'dart:io';


class Menu{

int menu() {
  
  print('''
  PORFAVOR SELECCIONES UNA OPCION
  1-PARSEADOR
  2-CREAR NUEVA PELICULA
  3-VISUALIZAR LISTA DE PELICULAS
  4-ELIMINAR PELICULA
  5-TERMINAR EL PROGRAMA
  ''');

  var linea = stdin.readLineSync();
  var opcion = int.tryParse(linea);
  return opcion;

}

}