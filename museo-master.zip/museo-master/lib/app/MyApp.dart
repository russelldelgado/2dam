import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/pages/LoginUsuario.dart';
import 'package:museo/pages/Museo.dart';
import 'package:museo/pages/errorPage.dart';
import 'package:museo/routes/routes.dart';
import 'package:scoped_model/scoped_model.dart';


class MyApp extends StatelessWidget {
//como necesitamos el metodo para ver si un token ha expirado o no creamos un instancia de la calse 
  AppViewModels appViewModels;

  MyApp(){
  //EN EL CONSTRUCTOR INICIALIZAMOS EL NOTES VIEW MODEL PARA QUE SE HAGA SOLO UNA VEZ
    appViewModels = AppViewModels();
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModel(
        model: appViewModels,
        child: ScopedModelDescendant<AppViewModels>(
          builder: (context, child, model) {

            var initialRouter = LoginUsuario.route;
            if(appViewModels.isTokenValid()){
            initialRouter = Museo.route;
            }

            return MaterialApp(
               debugShowCheckedModeBanner: false,
               key: UniqueKey(),
              routes: getRoutesApplication(),
              initialRoute:  initialRouter,
              title : 'MUSEO IES VIRGEN DEL CARMEN',
              theme: ThemeData(
              primaryColor: Colors.deepPurple[400], 
              accentColor: Colors.deepPurple[700]
              ),
            );
          },
        ),
    );
  }
}