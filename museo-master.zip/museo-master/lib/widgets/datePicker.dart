import 'package:flutter/material.dart';


class DatePickerWidgetPersonalizado extends StatefulWidget {

  @override
  _DatePickerWidgetPersonalizadoState createState() => _DatePickerWidgetPersonalizadoState();
}

class _DatePickerWidgetPersonalizadoState extends State<DatePickerWidgetPersonalizado> {

  String _fecha = '';
  TextEditingController _inputFieldDateController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ListView(
        children: [
          _crearFecha(context),
        ],
    );
  }

Widget _crearFecha(BuildContext context){
      return TextField(
        controller: _inputFieldDateController,
        enableInteractiveSelection: false,
        decoration: InputDecoration(
          
          //suffixIcon: Icon(Icons.calendar_today),
          icon: Icon(Icons.calendar_today_rounded),
          border:OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          hintText: 'FECHA DE FABRICACION DE LA PIEZA',
          labelText: 'Fecha de fabricacion',
        ),
        onTap: () {
          //quitar el foco de aqui hay varias maneras
          FocusScope.of(context).requestFocus(new FocusNode());
          //con esta funciona nos devulve una ventana para poder seleccionar la fecha
          _selectedData(context);
        },
      );
}


  _selectedData(BuildContext context) async{

    DateTime picker = await showDatePicker(
      context: context, 
      initialDate: new DateTime.now(), 
      firstDate: new DateTime(1500), 
      lastDate: new DateTime(20000));

      if(picker!=null){
        setState(() {
          _fecha = picker.toString();
          _inputFieldDateController.text = _fecha;
        });
      }

  }

}