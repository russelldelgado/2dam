import 'package:flutter/material.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/utilities/constants.dart';


class CardPersonalizadaPieza extends StatelessWidget{


 final Color color;
 final void Function({PiezaModels extra}) onChange;
 final PiezaModels piezaModels;

 const CardPersonalizadaPieza({this.color = Colors.deepPurple,
  this.piezaModels,
  this.onChange 
    });

  @override
  Widget build(BuildContext context) {

    final datos = Container(

      decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40),
           
          ),
      
      child:Column(
          children: [
            FadeInImage(
              placeholder:AssetImage('assets/imagenes/loading.gif') ,  
              image: NetworkImage('${piezaModels.rutaImagen}'),
              fit: BoxFit.cover,
              fadeInDuration: Duration(milliseconds: 3000),
              height: 150,
              width: double.infinity,
              ),
              Container(
                alignment: Alignment.center,
                width: double.infinity,
                child: Text('${piezaModels.nombre}' , style: TextStyle(fontWeight: FontWeight.bold , color: Colors.white), maxLines: 1, overflow: TextOverflow.ellipsis, ),
                padding: EdgeInsets.all(10),
                //color: color,
                decoration: boxDecoration,
              )
          ],

      ),

    ); 

     
    return GestureDetector(
          onTap: () {
           onChange();
          },
          child: Container(
          margin: EdgeInsets.all(20),
          child: ClipRRect(
            child: datos,
            borderRadius: BorderRadius.circular(40),
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: color,
                blurRadius: 1.0,
                spreadRadius: 1.0,
                offset: Offset(2,5) 
              ),
            ]
          ),

      ),
    );
  }

}