
import 'package:flutter/material.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/pages/piezasPorCategoria.dart';
import 'package:museo/utilities/constants.dart';


class CardPersonalizadaCategoria extends StatefulWidget{

 final Color color;
 final CategoriaModels categoria;

 const CardPersonalizadaCategoria({this.color = Colors.deepPurple, @required this.categoria});

  @override
  _CardPersonalizadaCategoriaState createState() => _CardPersonalizadaCategoriaState();
}

class _CardPersonalizadaCategoriaState extends State<CardPersonalizadaCategoria> {
  @override
  Widget build(BuildContext context) {

    final datos = Container(
      decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40),
          ),
      
      child:Column(
          children: [
            FadeInImage(
              placeholder:AssetImage('assets/imagenes/loading.gif') ,  
              image: NetworkImage('${widget.categoria.imagenUrl}'),
              fit: BoxFit.fill,
              fadeInDuration: Duration(milliseconds: 3000),
              height: 250,
              ),
              Container(
                alignment: Alignment.center,
                width: double.infinity,
                child: Text('${widget.categoria.nombre}' , style: TextStyle(fontWeight: FontWeight.bold ,color: Colors.white ), maxLines: 1, overflow: TextOverflow.ellipsis,),
                padding: EdgeInsets.all(10),
                //color: widget.color,
                decoration: boxDecoration,
              )
          ],

      ),

    ); 

     
    return GestureDetector(
          onTap: () {
             // print('--------------------------------' + widget.categorias.toString());
              print('PON AQUI LA RUTA A LA OTRA IMAGEN PASANDO LOS ARGUMENTOS');
              //print('--------------------------------' + widget.categorias.toJson());
              Navigator.pushNamed(context, PiezasPorCategoria.route ,arguments: widget.categoria.toMap());

          },
          child: Container(
          margin: EdgeInsets.all(20),
          child: ClipRRect(
            child: datos,
            borderRadius: BorderRadius.circular(40),
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: widget.color,
                blurRadius: 1.0,
                spreadRadius: 1.0,
                offset: Offset(2,5) 
              ),
            ]
          ),

      ),
    );
  }
}