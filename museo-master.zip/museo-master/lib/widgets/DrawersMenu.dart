

import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/pages/administradores.dart';
import 'package:museo/pages/formularios/actualizarCategoria.dart';
import 'package:museo/pages/formularios/actualizarPieza.dart';
import 'package:museo/pages/formularios/borrarCategoria.dart';
import 'package:museo/pages/formularios/borrarPieza.dart';
import 'package:museo/pages/formularios/crearCategoria.dart';
import 'package:museo/pages/formularios/crearPieza.dart';
import 'package:scoped_model/scoped_model.dart';


class DrawersMenu extends StatelessWidget {
  const DrawersMenu({Key key}) : super(key: key);

Widget _createHeader() {
  return DrawerHeader(
      margin: EdgeInsets.zero,
      padding: EdgeInsets.zero,
      decoration: BoxDecoration(
          image: DecorationImage(
              fit: BoxFit.fill,
              image:  AssetImage('assets/imagenes/loading.gif'))),
      child: Stack(children: <Widget>[
        Positioned(
            bottom: 12.0,
            left: 16.0,
            child: Text("CONFIGURACION...",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                    fontWeight: FontWeight.w500))),
      ]));
}

Widget _createDrawerItem( {IconData icon = Icons.cached, String text = "nulo", GestureTapCallback onTap , GestureLongPressCallback longpress}) {
  return ListTile(
    title: Row(
      children: <Widget>[
        Icon(icon),
        Padding(
          padding: EdgeInsets.only(left: 8.0),
          child: Text(text),
        )
      ],
    ),
    onTap: onTap,
    onLongPress: longpress,
  );
}


  @override
  Widget build(BuildContext context) {
   return ScopedModelDescendant<AppViewModels>(
     builder: (context, child, model) {
       final _administrador = PreferencesModels().administrador;
          if(_administrador)
          return Drawer(
              child:ListView(
                  children: [
                    _createHeader(),
                    
                    Text('Piezas' , style: TextStyle(fontWeight: FontWeight.bold , fontSize: 20), ),
                    Divider(),
                    _createDrawerItem(
                      icon: Icons.add_to_photos , 
                      text: "Crear nueva pieza",
                      onTap: () {
                        Navigator.pushNamed(context, CrearPieza.route);
                      },),
                     _createDrawerItem(
                      icon: Icons.edit , 
                      text: "Editar pieza",
                      onTap: () {
                        Navigator.pushNamed(context, ActualizarPieza.route);
                      },),
                    _createDrawerItem(
                      icon: Icons.delete , 
                      text: "Eliminar pieza",
                      onTap: () {
                        Navigator.pushNamed(context , BorrarPieza.route );
                      },),
                      Text('Categorias' , style: TextStyle(fontWeight: FontWeight.bold , fontSize: 20), ),
                      Divider(),
                    _createDrawerItem(
                      icon: Icons.addchart_outlined, 
                      text: "Crear categoria",
                      onTap: () {
                        Navigator.pushNamed(context, CrearCategoria.route);
                      },),
                    _createDrawerItem(
                      icon: Icons.edit_outlined , 
                      text: "Editar categoria",
                      onTap: () {
                        Navigator.pushNamed(context, ActualizarCategoria.route);
                      },),
                     _createDrawerItem(
                      icon: Icons.delete_outline_outlined , 
                      text: "Eliminar categoria",
                      onTap: () {
                        Navigator.pushNamed(context , BorrarCategoria.route);
                      },),
                      SizedBox(height: 60,),
                      _createDrawerItem(
                      icon: Icons.logout , 
                      text: "Cerrar sesión",
                      onTap: () {
                        model.logout();
                      },
                      longpress: () {
                        PreferencesModels().adminstrador = false;
                        model.refres();
                      },   
                      ),
                    

                  ],
              )
            );

             return Drawer(
              child:ListView(
                  children: [
                    _createHeader(),
                    
                    Text('SOLO PARA ADMINSTRADORES' , style: TextStyle(fontWeight: FontWeight.bold , fontSize: 20), ),
                    Divider(),
                    Text('INICIA SESIÓN COMO ADMINISTRADOR PARA PODER HACER EL CRUD' , style: TextStyle(fontWeight: FontWeight.bold , fontSize: 20), ),
                    SizedBox(height: 10,),
                      _createDrawerItem(
                      icon: Icons.logout , 
                      text: "Cerrar sesión",
                      onTap: () {
                        model.logout();
                      },  
                      longpress: () {
                        Navigator.pushNamed(context, Administradores.route);
                      },                    
                      ),
                  ],
              )
            ); 

            },
      
   );
  }
}


/*
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:flutter_application_1/pages/NotesForm.dart';
import 'package:flutter_application_1/pages/NotesList.dart';
import 'package:flutter_application_1/pages/NotesLogin.dart';
import 'package:flutter_application_1/pages/NotesSettings.dart';
import 'package:scoped_model/scoped_model.dart';

class NotesDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    //ESTO ES UNA FUNCION QUE ME RETORNA UN DRAWERS CON EL ESCOPE MODEL LO QUE HAGO ES ACCEDER AL ESTADO DE MI APLICACION 
    return ScopedModelDescendant<NotesViewModel>(
      builder: (context, child, model) =>  Drawer(
        child: ListView(
          children: [
            _buildDrawerHeader(model),

            ListTile(
              leading: Icon(Icons.login) ,
              title: Text('INICIAR SESION'),
              onTap: (){
                Navigator.pop(context);
                //si la ruta altual es distinta a la ruta de login
                if( ModalRoute.of(context).settings.name != NotesLogin.route){
                  //este ultimo false hace que se elimine todo lo anterior
                 Navigator.pushNamedAndRemoveUntil(context, NotesLogin.route, (route) => false);
                  }
              },
            ),

            if(model.logged)
            ListTile(
              leading: Icon(Icons.list) ,
              title: Text('VER MIS NOTAS'),
              onTap: (){
                Navigator.pop(context);
                if( ModalRoute.of(context).settings.name != NotesList.route){
                  //este ultimo false hace que se elimine todo lo anterior
                 Navigator.pushNamedAndRemoveUntil(context, NotesList.route, (route) => false);
                  //Navigator.pop(context);
                  }
              },
            ),

            if(model.logged)
            ListTile(
              leading: Icon(Icons.add) ,
              title: Text('NUEVA NOTA '),
              onTap: () {
                  Navigator.pop(context);
                 if( ModalRoute.of(context).settings.name != NotesForm.route){
                    Navigator.pushNamed(context, NotesForm.route);
                  }
              },
            ),
             ListTile(
              leading: Icon(Icons.settings) ,
              title: Text('PREFERENCIAS'),
              onTap: () async{
                  Navigator.pop(context);
                 if( ModalRoute.of(context).settings.name != NotesSettings.route ){
                    Navigator.pushNamed(context, NotesSettings.route);
                   
                  }
              },
            ),
            if(model.logged)
            ListTile(
              leading: Icon(Icons.logout) ,
              title: Text('CERRAR SESION'),
              onTap: (){
                Navigator.pop(context);
                 model.logout();
                 Navigator.pushNamedAndRemoveUntil(context, NotesLogin.route, (route) => false);
              },
            ),

          ],
        ),

        
      ),
    );
    
  }

  Widget _buildDrawerHeader(NotesViewModel model) {
    if(model.logged){

      return UserAccountsDrawerHeader(
        accountName: Text((model.user.fullName != null) ? model.user.fullName : "nombre Nulo" ), 
        accountEmail: Text(model.user.email),
        currentAccountPicture: CircleAvatar(
          backgroundImage:AssetImage('assets/images/myAvatar.png') ,
        )
        );
        
    }
    else{
    return DrawerHeader(
            child: Stack(
                    children: [
                      Center(
                      child: Text('MIS NOTAS' , style: TextStyle( 
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                      ),),
                      ),
                    Container(
                      child: Text('SESION CERRADA'),
                      alignment: Alignment.bottomLeft,
                    ),
                    ]
            ),
              decoration:BoxDecoration(
                color: Colors.yellow
              ) ,
              );
  }}
}
*/