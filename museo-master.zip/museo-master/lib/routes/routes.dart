import 'package:flutter/material.dart';
import 'package:museo/pages/LoginUsuario.dart';
import 'package:museo/pages/Museo.dart';
import 'package:museo/pages/RegistroUsuario.dart';
import 'package:museo/pages/administradores.dart';
import 'package:museo/pages/formularios/actualizarCategoria.dart';
import 'package:museo/pages/formularios/actualizarPieza.dart';
import 'package:museo/pages/formularios/borrarCategoria.dart';
import 'package:museo/pages/formularios/borrarPieza.dart';
import 'package:museo/pages/formularios/crearCategoria.dart';
import 'package:museo/pages/formularios/crearPieza.dart';
import 'package:museo/pages/piezaDetallePage.dart';
import 'package:museo/pages/piezasPorCategoria.dart';



Map<String, WidgetBuilder> getRoutesApplication(){

  return <String,  WidgetBuilder>{
    Museo.route            :(BuildContext context) => Museo(),
    LoginUsuario.route    :(BuildContext context) => LoginUsuario(),
    RegistroUsuario.route : (BuildContext context) =>RegistroUsuario(),
    PiezasPorCategoria.route :(BuildContext context) => PiezasPorCategoria(),
    PiezaDetalle.route       :(BuildContext context) => PiezaDetalle(),
    CrearPieza.route       :(BuildContext context) => CrearPieza(),
    CrearCategoria.route       :(BuildContext context) => CrearCategoria(),
    BorrarPieza.route       :(BuildContext context) => BorrarPieza(),
    BorrarCategoria.route       :(BuildContext context) => BorrarCategoria(),
    ActualizarPieza.route       :(BuildContext context) => ActualizarPieza(),
    Administradores.route       :(BuildContext context) => Administradores(),
    ActualizarCategoria.route :(BuildContext context) => ActualizarCategoria(),

  };

}
