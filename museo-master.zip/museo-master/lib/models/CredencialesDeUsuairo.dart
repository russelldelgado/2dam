import 'dart:convert';


class CredencialesDeUsuario {

  String email;
  String password;

  CredencialesDeUsuario({
    this.email,
    this.password,
  });


  CredencialesDeUsuario copyWith({
    String email,
    String password,
  }) {
    return CredencialesDeUsuario(
      email: email ?? this.email,
      password: password ?? this.password,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'password': password,
    };
  }

  factory CredencialesDeUsuario.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return CredencialesDeUsuario(
      email: map['email'],
      password: map['password'],
    );
  }

  String toJson() => json.encode(toMap());

  factory CredencialesDeUsuario.fromJson(String source) => CredencialesDeUsuario.fromMap(json.decode(source));

  @override
  String toString() => 'CredencialesDeUsuario(email: $email, password: $password)';

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;
  
    return o is CredencialesDeUsuario &&
      o.email == email &&
      o.password == password;
  }

  @override
  int get hashCode => email.hashCode ^ password.hashCode;
}
