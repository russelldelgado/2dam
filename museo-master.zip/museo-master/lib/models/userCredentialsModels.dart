

import 'dart:convert';

import 'package:flutter/material.dart';

class UserCredentials {

  String email;
  String password;


  UserCredentials({@required this.email ,this.password });




  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'password': password,
    };
  }

  factory UserCredentials.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return UserCredentials(
      email: map['email'],
      password: map['password'],
    );
  }

  String toJson() => json.encode(toMap());

  factory UserCredentials.fromJson(String source) => UserCredentials.fromMap(json.decode(source));
}
