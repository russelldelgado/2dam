
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:museo/models/userCredentialsModels.dart';
class UsuarioModels extends UserCredentials {
  String id;
  String nombre;
  String apellido;
  int edad ;
  UsuarioModels({
    this.id,
    this.nombre,
    this.apellido,
    this.edad,
    @required email,
    password,
  }) : super(email: email , password: password);

  UsuarioModels copyWith({
    String id,
    String nombre,
    String apellido,
    int edad ,
  }) {
    return UsuarioModels(
      id: id ?? this.id,
      nombre: nombre ?? this.nombre,
      apellido: apellido ?? this.apellido,
     edad : edad  ?? this.edad,
     email: email ?? this.email,
     password: password ?? this.password
    );
  }

  Map<String, dynamic> toMap() {
    return {
      '_id': id,
      'nombre': nombre,
      'apellido': apellido,
      'edad': edad,
      'email': email,
      'password':password
    };
  }

  factory UsuarioModels.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return UsuarioModels(
      id: map['_id'],
      nombre: map['nombre'],
      apellido: map['apellido'],
      edad : map['edad'],
      email: map['email'],
    );
  }

  String toJson() => json.encode(toMap());

  factory UsuarioModels.fromJson(String usuarioJson) => UsuarioModels.fromMap(json.decode(usuarioJson));

  @override
  String toString() {
    return 'UsuarioModels(id: $id, nombre: $nombre, apellido: $apellido, edad: $edad ,email : $email)';
  }
}
