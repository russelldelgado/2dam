import 'dart:convert';



class Usuario {

  int id;
  String nombre;
  String apellido;
  int edad;

  
  Usuario({
    this.id,
    this.nombre,
    this.apellido,
    this.edad,
  });


  Usuario copyWith({
    int id,
    String nombre,
    String apellido,
    int edad,
  }) {
    return Usuario(
      id: id ?? this.id,
      nombre: nombre ?? this.nombre,
      apellido: apellido ?? this.apellido,
      edad: edad ?? this.edad,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nombre': nombre,
      'apellido': apellido,
      'edad': edad,
    };
  }

  factory Usuario.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return Usuario(
      id: map['id'],
      nombre: map['nombre'],
      apellido: map['apellido'],
      edad: map['edad'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Usuario.fromJson(String source) => Usuario.fromMap(json.decode(source));

  @override
  String toString() {
    return 'Usuario(id: $id, nombre: $nombre, apellido: $apellido, edad: $edad)';
  }

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;
  
    return o is Usuario &&
      o.id == id &&
      o.nombre == nombre &&
      o.apellido == apellido &&
      o.edad == edad;
  }

  @override
  int get hashCode {
    return id.hashCode ^
      nombre.hashCode ^
      apellido.hashCode ^
      edad.hashCode;
  }
}
