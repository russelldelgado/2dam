import 'dart:convert';


class PiezasModels{

  List<PiezaModels> piezas = List();

  PiezasModels();

  PiezasModels.fromJsonList(List<dynamic> jsonList){
    if(jsonList == null) return ;

    for(var item in jsonList){
      final pieza = PiezaModels.fromMap(item);
      piezas.add(pieza);
    }
  
  }


}


class PiezaModels {
  String id;
  String rutaImagen;
  String descripcion;
  String nombre;
  DateTime fechaCreacion;
  String idCategoria;

  PiezaModels({
    this.id,
    this.rutaImagen,
    this.descripcion,
    this.nombre,
    this.fechaCreacion,
    this.idCategoria,
  });



  PiezaModels copyWith({
    String id,
    String rutaImagen,
    String descripcion,
    String nombre,
    DateTime fechaCreacion,
    String idCategoria,
  }) {
    return PiezaModels(
      id: id ?? this.id,
      rutaImagen: rutaImagen ?? this.rutaImagen,
      descripcion: descripcion ?? this.descripcion,
      nombre: nombre ?? this.nombre,
      fechaCreacion: fechaCreacion ?? this.fechaCreacion,
      idCategoria: idCategoria ?? this.idCategoria,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id ?? '',
      'rutaImagen': rutaImagen,
      'descripcion': descripcion,
      'nombre': nombre,
      'fechaCreacion': fechaCreacion.toString(), //?.millisecondsSinceEpoch,
      'idCategoria': idCategoria,
    };
  }

  factory PiezaModels.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return PiezaModels(
      id: map['_id'],
      rutaImagen: map['rutaImagen'],
      descripcion: map['descripcion'],
      nombre: map['nombre'],
      fechaCreacion: DateTime.parse(map['fechaCreacion'].toString()),
      //fechaCreacion: DateTime.fromMillisecondsSinceEpoch(map['fechaCreacion']),
      idCategoria: map['idCategoria'],
    );
  }

  String toJson() => json.encode(toMap());

  factory PiezaModels.fromJson(String source) => PiezaModels.fromMap(json.decode(source));

  @override
  String toString() {
    return 'PiezaModels(id: $id, rutaImagen: $rutaImagen, descripcion: $descripcion, nombre: $nombre, fechaCreacion: $fechaCreacion, idCategoria: $idCategoria)';
  }

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;
  
    return o is PiezaModels &&
      o.id == id &&
      o.rutaImagen == rutaImagen &&
      o.descripcion == descripcion &&
      o.nombre == nombre &&
      o.fechaCreacion == fechaCreacion &&
      o.idCategoria == idCategoria;
  }

  @override
  int get hashCode {
    return id.hashCode ^
      rutaImagen.hashCode ^
      descripcion.hashCode ^
      nombre.hashCode ^
      fechaCreacion.hashCode ^
      idCategoria.hashCode;
  }
}
