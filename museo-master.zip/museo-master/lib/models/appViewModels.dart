
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/models/userCredentialsModels.dart';
import 'package:museo/models/usersModels.dart';
import 'package:museo/providers/api_providers.dart';
import 'package:museo/providers/categoria_provider.dart';
import 'package:museo/providers/pieza_providers.dart';
import 'package:museo/providers/user_providers.dart';
import 'package:scoped_model/scoped_model.dart';

class AppViewModels extends Model{

PiezaProvider piezaApi = PiezaProvider();
CategoriaProvider categoriaApi = CategoriaProvider();
UserProviders userApi = UserProviders();
PreferencesModels _preferencesModels  = PreferencesModels();


  AppViewModels(){

    if(isTokenValid()){
      piezaApi = PiezaProvider(token: _preferencesModels.token);
      categoriaApi = CategoriaProvider(token: _preferencesModels.token);
      userApi = UserProviders(token: _preferencesModels.token);
    }

  }


  //---------------------metodos de coneccion de las piezas 

  Future<List<PiezaModels>> get piezas async{
    if(isTokenValid()){
      final piezas = await piezaApi.getPiezas();
      return piezas;
    }else{
      logout();
      notifyListeners();
    }
    return null;
  }

  Future<PiezaModels>  pieza(String idPieza) async{

    if(isTokenValid()){
      final pieza = await piezaApi.getPieza(idPieza);
      if(pieza!=null){
       return pieza;
      }else{
        return null;
      }
    }
    return null;
  }

  Future<bool> addPieza(PiezaModels piezaModels) async{
    final added = await piezaApi.addPieza(piezaModels);
    if(added)notifyListeners();
    return added;
  }


  Future<PiezaModels> addPiezaAndActualiceCategoria(PiezaModels piezaModels) async{
    final pieza = await piezaApi.addPiezaAndActualiceCategoria(piezaModels);
    if(pieza!=null)notifyListeners();
    return pieza;
  }


  Future<bool> deletePieza(PiezaModels piezaModels)async{
    final delete = await piezaApi.deletePieza(piezaModels);
    if(delete)notifyListeners();
    return delete;
  }

  Future<bool> updatePieza(PiezaModels piezaModels)async{
    final update = await piezaApi.updatePieza(piezaModels);
   // if(update) notifyListeners();
    return update;
  }
  //---------------------metodos de coneccion de las categorias


  Future<List<CategoriaModels>> get categorias async{
    final categorias = await categoriaApi.getCategorias();

    if(categorias!=null){
     
      return categorias;
    }else{
      return null;
    }

  }

  Future<CategoriaModels> categoria(String idCategoria) async{
    final categoria = await categoriaApi.getCategoria(idCategoria);
    if(categoria !=null){
      return categoria;
    }else{
      return null;
    }
  }

  Future<bool> addCategoria(CategoriaModels categoria)async{
    final added = await categoriaApi.addCategoria(categoria);
    if(added)
      notifyListeners();
    return added;
  }

  Future<bool> deleteCategoria(String categoria)async{
    final delete = await categoriaApi.deleteCategoria(categoria);
    if(delete) notifyListeners();
    return delete;
  }


  Future<bool> updateCategoria(CategoriaModels categoria)async{
    final update = await categoriaApi.updateCategoria(categoria);
    if(update) notifyListeners();
    return update;
  }

  Future<bool> updateCategoria2(CategoriaModels categoria)async{
    print("--------------------------------------probando uno-----------------------");
    final update = await categoriaApi.updateCategoria2(categoria);
    if(update) notifyListeners();
    return update;
  }

  //---------------------metodos de coneccion de los usuarios 

  Future<bool> login(UserCredentials userCredentials)async{
    final token = await userApi.usuarioLogin(userCredentials);
    _preferencesModels.adminstrador = false;
    return _setLoginStatus(token);

  }


  Future<bool> register(UsuarioModels usuarioModels)async{

    final token = await userApi.usuarioRegister(usuarioModels);
    _preferencesModels.adminstrador = false;  
    if(token!=null){
     return _setLoginStatus(token);
    }else{
      return false;
    }

  }



  //------------------------metodos de comprobacion

  bool isTokenValid(){
    final token = _preferencesModels.token;

    if(token!= null || token!=''){
      return UserProviders(token: token).isTokenValid();
    }else{
      return false;
    }

  }

  logout(){
    _preferencesModels.token = null;
    ApiService.header['x-access-token'] = null;
    _preferencesModels.adminstrador = false;  

    notifyListeners();
  }

  _setLoginStatus(String token){

    if(token!=null){
      piezaApi = PiezaProvider(token: token);
      categoriaApi = CategoriaProvider(token: token);
      userApi = UserProviders(token: token);

      _preferencesModels.token = token;
      return true;
    }else{
      _preferencesModels.token = null;
      //notifyListeners();
      return false;
    }

  }

  set token(String token){
    _preferencesModels.token = token;
    piezaApi = PiezaProvider(token: token);
    categoriaApi = CategoriaProvider(token: token);
    userApi = UserProviders(token: token);
  }

  Future<void>refres()async{
    notifyListeners();
  }


}