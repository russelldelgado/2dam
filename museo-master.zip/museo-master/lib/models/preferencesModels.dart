

import 'package:shared_preferences/shared_preferences.dart';

class PreferencesModels{

  static final PreferencesModels _instance = PreferencesModels._internal();
  static final String tokenKey = "museo_token";
  static final String administradorKey ="museo_administrador";

  SharedPreferences _preferences;

  factory PreferencesModels(){
    return _instance;
  }

  PreferencesModels._internal();

  initPreferences() async{
    _preferences = await SharedPreferences.getInstance();
  }

  set token(String token){
    _preferences.setString(tokenKey, token);
  }

  String get token{
    return _preferences.getString(tokenKey);
  }

  set adminstrador(bool administrador){
    _preferences.setBool(administradorKey, administrador);
  }

  bool get administrador{
    return _preferences.getBool(administradorKey);
  }
}