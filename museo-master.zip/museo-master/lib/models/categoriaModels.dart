import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:museo/models/piezaModels.dart';

class CategoriasModels{

  List<CategoriaModels> itemsCategoria = List();

  CategoriasModels();

  CategoriasModels.fromJsonList(List<dynamic> jsonList){
    if(jsonList == null)return ;

    for (var item in jsonList) {
      final categoria = CategoriaModels.fromMap(item);
      itemsCategoria.add(categoria);
    }
  }

}


class CategoriaModels {
  List<PiezaModels> piezasDelMuseo;
  String id;
  String nombre;
  String imagenUrl;

  CategoriaModels({
    this.piezasDelMuseo,
    this.id,
    this.nombre,
    this.imagenUrl,
  });

  CategoriaModels copyWith({
    List<PiezaModels> piezasDelMuseo,
    String id,
    String nombre,
    String imagenUrl,
  }) {
    return CategoriaModels(
      piezasDelMuseo: piezasDelMuseo ?? this.piezasDelMuseo,
      id: id ?? this.id,
      nombre: nombre ?? this.nombre,
      imagenUrl: imagenUrl ?? this.imagenUrl,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'piezasDelMuseo': piezasDelMuseo?.map((x) => x?.toMap())?.toList(),
      'id': id,
      'nombre': nombre,
      'imagenUrl': imagenUrl,
    };
  }

  factory CategoriaModels.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return CategoriaModels(
      piezasDelMuseo: List<PiezaModels>.from(map['piezasDelMuseo']?.map((x) => PiezaModels.fromMap(x))),
      id: map['_id'],
      nombre: map['nombre'],
      imagenUrl: map['imagenUrl'],
    );
  }

  String toJson() => json.encode(toMap());

  factory CategoriaModels.fromJson(String source) => CategoriaModels.fromMap(json.decode(source));

  @override
  String toString() {
    return 'CategoriaModels(piezasDelMuseo: $piezasDelMuseo, id: $id, nombre: $nombre, imagenUrl: $imagenUrl)';
  }

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;
  
    return o is CategoriaModels &&
      listEquals(o.piezasDelMuseo, piezasDelMuseo) &&
      o.id == id &&
      o.nombre == nombre &&
      o.imagenUrl == imagenUrl;
  }

  @override
  int get hashCode {
    return piezasDelMuseo.hashCode ^
      id.hashCode ^
      nombre.hashCode ^
      imagenUrl.hashCode;
  }
}


class CategoriaAddAndUpdate {

   List<String> piezasDelMuseo;
  String id;
  String nombre;
  String imagenUrl;

  CategoriaAddAndUpdate({
    this.piezasDelMuseo,
    this.id,
    this.nombre,
    this.imagenUrl,
  });



  CategoriaAddAndUpdate copyWith({
    List<String> piezasDelMuseo,
    String id,
    String nombre,
    String imagenUrl,
  }) {
    return CategoriaAddAndUpdate(
      piezasDelMuseo: piezasDelMuseo ?? this.piezasDelMuseo,
      id: id ?? this.id,
      nombre: nombre ?? this.nombre,
      imagenUrl: imagenUrl ?? this.imagenUrl,
    );
  }

  CategoriaAddAndUpdate.desdeUnCategoriaModels(CategoriaModels categoria){
    this.id = categoria.id;
    this.imagenUrl = categoria.imagenUrl;
    this.nombre = categoria.nombre;
    List<String> datos = List();
    for (var idPiezaModels in categoria.piezasDelMuseo) {
      var idTemporalDePieza = idPiezaModels.id;
      datos.add(idTemporalDePieza);
    }
    this.piezasDelMuseo = datos;
    
  }

  CategoriaAddAndUpdate.desdeUnCategoriaModelsSinPiezas(CategoriaModels categoria){
    this.id = categoria.id;
    this.imagenUrl = categoria.imagenUrl;
    this.nombre = categoria.nombre;
    this.piezasDelMuseo = List();
    
  }


  Map<String, dynamic> toMap() {
    return {
      'piezasDelMuseo': piezasDelMuseo,
      '_id': id,
      'nombre': nombre,
      'imagenUrl': imagenUrl,
    };
  }

  factory CategoriaAddAndUpdate.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return CategoriaAddAndUpdate(
      piezasDelMuseo: List<String>.from(map['piezasDelMuseo']),
      id: map['_id'],
      nombre: map['nombre'],
      imagenUrl: map['imagenUrl'],
    );
  }

  String toJson() => json.encode(toMap());

  factory CategoriaAddAndUpdate.fromJson(String source) => CategoriaAddAndUpdate.fromMap(json.decode(source));

  @override
  String toString() {
    return 'CategoriaAddAndUpdate(piezasDelMuseo: $piezasDelMuseo, id: $id, nombre: $nombre, imagenUrl: $imagenUrl)';
  }

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;
  
    return o is CategoriaAddAndUpdate &&
      listEquals(o.piezasDelMuseo, piezasDelMuseo) &&
      o.id == id &&
      o.nombre == nombre &&
      o.imagenUrl == imagenUrl;
  }

  @override
  int get hashCode {
    return piezasDelMuseo.hashCode ^
      id.hashCode ^
      nombre.hashCode ^
      imagenUrl.hashCode;
  }



}
