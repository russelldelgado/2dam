import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/userCredentialsModels.dart';
import 'package:museo/pages/Museo.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';

import 'RegistroUsuario.dart';

class LoginUsuario extends StatefulWidget {

  static final route = '/loginUsuario';

  LoginUsuario({Key key}) : super(key: key);

  @override
  _LoginUsuarioState createState() => _LoginUsuarioState();
}

class _LoginUsuarioState extends State<LoginUsuario> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  UserCredentials _credentials = UserCredentials();
  var _error = false;
  _login()async{
    if(_formKey.currentState.validate()){
      _formKey.currentState.save();
      //con esto accedo al scope model y al metodo que hace login con mi usuario

      var logged = await ScopedModel.of<AppViewModels>(context , rebuildOnChange: true).login(_credentials);

      if(logged){
        Navigator.of(context).pushReplacementNamed(Museo.route);
      }else{
        setState(() {   
        _error = true;
      });
      }
      
    }
  }

  _onChange(){
    setState(() {
      _error = false;
    });
  }

  String _emailValidator(String email){
    final emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^-`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email);
    if(!emailValid){
      return 'El email insertado no es valido';
    }
  }

  String _passwordValidator(String password){
      if(password.length < 7){
        return "La contraseña no puede tener menos de 3 caracteres";
      }
  }

  Column _buildEmail() {
    return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Correo electrónico', style: kLabelStyle),
                    SizedBox(height: 10),
                    Container(
                      alignment: Alignment.centerLeft,
                      decoration: kBoxDecorationStyle,
                      height: 60.0,
                      child: TextFormField(
                        validator: _emailValidator,
                        onSaved: (newValue) => _credentials.email = newValue,
                        initialValue: "probando2@probando.com",
                        onChanged:(value) => _onChange(),
                        keyboardType: TextInputType.emailAddress,
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                        ),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(top: 14.0),
                          prefixIcon: Icon(
                            Icons.email,
                            color: Colors.white,
                          ),
                          hintText: 'Introduce tu correo electrónico',
                          hintStyle: kHintTextStyle,
                        ),
                      ),
                      )
                    ],
                  );
    }

  Widget _buildPasswordTF() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          'Contraseña',
          style: kLabelStyle,
        ),
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            validator: _passwordValidator,
            onSaved: (newValue) => _credentials.password = newValue,
            initialValue: 'proband2',
            onChanged:(value) => _onChange(),
            obscureText: true,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.lock,
                color: Colors.white,
              ),
              hintText: 'Introduce tu contraseña',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildForgotPasswordBtn() {
    return Container(
      alignment: Alignment.centerRight,
      child: FlatButton(
        onPressed: () => print('Botón de contraseña olvidada pulsado'),
        padding: EdgeInsets.only(right: 0.0),
        child: Text(
          '¿Has olvidado la contraseña?',
          style: kLabelStyle,
        ),
      ),
    );
  }

  Widget _buildLoginBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: _login,
        //onPressed: () => print('Botón Login pulsado'),
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'LOGIN',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  Widget _buildSignupBtn() {
    return GestureDetector(
      onTap: () => print('Botón de registro pulsado'),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '¿Todavía no tienes cuenta?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.w400,
              ),
            ),
            TextSpan(
              text: ' Regístrate',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
              recognizer: TapGestureRecognizer()..onTap = () => Navigator.pushNamed(context, RegistroUsuario.route)
            ),
          ],
        ),
      ),
    );
  }

  Widget _errorUsuarioPssword() {
    return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Text("usuario o contraseña incorrecta"
            ,style:TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 18,
              ) ,
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromARGB(255, 92, 107, 192),
                  Color.fromARGB(255, 65, 83, 198),
                  Color.fromARGB(255, 63, 81, 181),
                  Color.fromARGB(255, 40, 53, 147),
                ], 
                stops: [0.1, 0.4, 0.7, 0.9]
              )
            ),
          ),
          Container(
            height: double.infinity,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(
                horizontal: 40,
                vertical: 120
              ),
              child: Form(
                        key: _formKey,
                        child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('Inicio de sesión', style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'OpenSans',
                            fontSize: 30, 
                            fontWeight: FontWeight.bold
                          )),
                          SizedBox(height: 30),
                          _buildEmail(),
                          SizedBox(height: 30.0,),
                          _buildPasswordTF(),
                          _buildForgotPasswordBtn(),
                          _buildLoginBtn(),
                          _buildSignupBtn(),
                          if(_error)
                          _errorUsuarioPssword(),
                          ],
                        ),
                    ),
              ),
            )
          ],
        ),
      );
    }

  
  }