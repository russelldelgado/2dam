import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/pages/formularios/crearPieza.dart';
import 'package:museo/pages/piezaDetallePage.dart';
import 'package:museo/widgets/cardPersonalizadaPieza.dart';

class PiezasPorCategoria extends StatelessWidget{
  
  static final route = '/piezasPorCategoria';
  CategoriaModels categoria;
  PiezasPorCategoria({this.categoria});


  @override
  Widget build(BuildContext context) {
    //en el museo le he pasado aqui los argumentos que quiero y necesito.
  final arguments = ModalRoute.of(context).settings.arguments;
  categoria = CategoriaModels.fromMap(arguments);

List<Widget> _componente() {
   List<Widget> datos = [];
    categoria.piezasDelMuseo.forEach((pieza) {
        final Widget widgetTemporal = CardPersonalizadaPieza(piezaModels: pieza,
        onChange: ({extra}) {Navigator.pushNamed(context, PiezaDetalle.route , arguments: pieza.toMap());},
        );
        datos..add(widgetTemporal)
              ..add(Divider());
    });
    return datos;

 }

 Widget _componentes() {
    return ListView(
      children: _componente(),
    );
  }

      return Scaffold(
        appBar: AppBar( title: Text('${categoria.nombre}') ,centerTitle: true,),
        floatingActionButton: (PreferencesModels().administrador) ? FloatingActionButton(
          onPressed: () {
          Navigator.pushNamed(context, CrearPieza.route);
          },
          child: Icon(Icons.add),
         
        ) : null,
        body: _componentes(),
      );    
  }

  



 

}