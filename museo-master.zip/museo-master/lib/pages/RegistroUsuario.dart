import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/usersModels.dart';
import 'package:museo/pages/Museo.dart';
import 'package:museo/utilities/constants.dart';
import 'package:museo/widgets/datePicker.dart';
import 'package:scoped_model/scoped_model.dart';

import 'LoginUsuario.dart';

class RegistroUsuario extends StatefulWidget {

  static final route = '/RegistroUsuario';

  RegistroUsuario({Key key}) : super(key: key);

  @override
  _RegistroUsuarioState createState() => _RegistroUsuarioState();
}

class _RegistroUsuarioState extends State<RegistroUsuario> {

  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();
  UsuarioModels usuarioModels = UsuarioModels();
  var _error = false;

  //---------------codigo a pegar para crear lo que es una fecha
   String _fecha = '';
  TextEditingController _inputFieldDateController = new TextEditingController();

    Widget _crearFecha(BuildContext context){
      return TextField(
        controller: _inputFieldDateController,
        enableInteractiveSelection: false,
        decoration: InputDecoration(
          
          //suffixIcon: Icon(Icons.calendar_today),
          icon: Icon(Icons.calendar_today_rounded),
          border:OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          hintText: 'FECHA DE FABRICACION DE LA PIEZA',
          labelText: 'Fecha de fabricacion',
        ),
        onTap: () {
          //quitar el foco de aqui hay varias maneras
          FocusScope.of(context).requestFocus(new FocusNode());
          //con esta funciona nos devulve una ventana para poder seleccionar la fecha
          _selectedData(context);
        },
      );
}

  _selectedData(BuildContext context) async{

    DateTime picker = await showDatePicker(
      context: context, 
      initialDate: new DateTime.now(), 
      firstDate: new DateTime(1500), 
      lastDate: new DateTime(20000));

      if(picker!=null){
        setState(() {
          _fecha = picker.toString();
          _inputFieldDateController.text = _fecha;
        });
      }

  }

  //---------------aqui acaba el motodo solo tengo que instanciar lo que es _crear fecha y pasarle el contexto

  _register() async{
    if(_registerKey.currentState.validate()){
      _registerKey.currentState.save();

      //con esto accedemos al scope model para coger el metodo que acceda a nuestro backend y hace el register

      final register = await ScopedModel.of<AppViewModels>(context , rebuildOnChange: true).register(usuarioModels);

      if(register){
        Navigator.of(context).pushReplacementNamed(Museo.route);
      }else{
        setState(() {
          _error = true;
        });
      }
    }
  }

  _onChange(){
    setState(() {
      _error = false;
    });
  }

  String _emailValidator(String email){
    final emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^-`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email);
    if(!emailValid){
      return 'El email insertado no es valido';
    }
  }

  String _passwordValidator(String password){
      if(password.length < 7){
        return "La contraseña no puede tener menos de 3 caracteres";
      }
  }

  String _nombreValidator(String valor){
    if(valor==null || valor.length <4 ){
      return "demasiado corto";
    }
  }

  String _edadValidator(String edad){
    int edadNumerica = int.parse(edad);
    if(edad == null){
      return "el campo no puede estar vacio";
    }else if(edadNumerica.isNaN){
      return "tiene que introducir un numero";
    }else if(edadNumerica < 10){
      return "Eres muy joven para registrarte";
    }
  }


  Column _buildFirstname() {
    return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Nombre', style: kLabelStyle),
                    SizedBox(height: 10),
                    Container(
                      alignment: Alignment.centerLeft,
                      decoration: kBoxDecorationStyle,
                      height: 60.0,
                      child: TextFormField(
                        validator: _nombreValidator,
                        onSaved: (newValue) => usuarioModels.nombre = newValue,
                        onChanged: (value) => _onChange(),
                        keyboardType: TextInputType.name,
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                        ),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(top: 14.0),
                          prefixIcon: Icon(
                            Icons.person_add_alt,
                            color: Colors.white,
                          ),
                          hintText: 'Introduce tu nombre',
                          hintStyle: kHintTextStyle,
                        ),
                      ),
                      )
                    ],
                  );
    }

  Column _buildLastname() {
    return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(padding: EdgeInsets.only(top: 10), child: Text('Apellidos', style: kLabelStyle)),
                    SizedBox(height: 10),
                    Container(
                      alignment: Alignment.centerLeft,
                      decoration: kBoxDecorationStyle,
                      height: 60.0,
                      child: TextFormField(
                        validator: _nombreValidator,
                        onSaved: (newValue) => usuarioModels.apellido =  newValue,
                        onChanged: (value) => _onChange(),
                        keyboardType: TextInputType.name,
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                        ),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(top: 14.0),
                          prefixIcon: Icon(
                            Icons.person_add_alt,
                            color: Colors.white,
                          ),
                          hintText: 'Introduce tus apellidos',
                          hintStyle: kHintTextStyle,
                        ),
                      ),
                      )
                    ],
                  );
    }

  Column _buildAge() {
    return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(padding: EdgeInsets.only(top: 10),child: Text('Edad', style: kLabelStyle)),
                    SizedBox(height: 10),
                    Container(
                      alignment: Alignment.centerLeft,
                      decoration: kBoxDecorationStyle,
                      height: 60.0,
                      child: TextFormField(
                        validator: _edadValidator,
                        onSaved: (newValue) => usuarioModels.edad = int.parse(newValue),
                        onChanged: (value) => _onChange(),
                        keyboardType: TextInputType.number,
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                        ),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(top: 14.0),
                          prefixIcon: Icon(
                            Icons.calendar_today,
                            color: Colors.white,
                          ),
                          hintText: 'Introduce tu edad',
                          hintStyle: kHintTextStyle,
                        ),
                      ),
                      )
                    ],
                  );
    }

  Column _buildEmail() {
    return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(padding: EdgeInsets.only(top: 10),child: Text('Correo electrónico', style: kLabelStyle)),
                    SizedBox(height: 10),
                    Container(
                      alignment: Alignment.centerLeft,
                      decoration: kBoxDecorationStyle,
                      height: 60.0,
                      child: TextFormField(
                        validator: _emailValidator,
                        onSaved: (newValue) => usuarioModels.email = newValue,
                        onChanged: (value) => _onChange(),
                        keyboardType: TextInputType.emailAddress,
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                        ),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(top: 14.0),
                          prefixIcon: Icon(
                            Icons.email,
                            color: Colors.white,
                          ),
                          hintText: 'Introduce tu correo electrónico',
                          hintStyle: kHintTextStyle,
                        ),
                      ),
                      )
                    ],
                  );
    }

  Widget _buildPasswordTF() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(top: 10),
          child: Text(
            'Contraseña',
            style: kLabelStyle,
          ),
        ),
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            validator: _passwordValidator,
            onSaved: (newValue) => usuarioModels.password = newValue,
            onChanged: (value) => _onChange(),
            obscureText: true,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.lock,
                color: Colors.white,
              ),
              hintText: 'Introduce tu contraseña',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildLoginBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: () => _register(),
       // onPressed: () => print('Botón Login pulsado'),
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'REGISTRO',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  Widget _buildSignupBtn() {
    return GestureDetector(
      onTap: () => print('Botón de registro pulsado'),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '¿Ya estás registrado?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.w400,
              ),
            ),
            TextSpan(
              text: ' Inicia sesión',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
              recognizer: new TapGestureRecognizer()..onTap = () => Navigator.pop(context, LoginUsuario.route)
            ),
          ],
        ),
      ),
    );
  }

  Widget _errorEnElRegistro() {
    return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Text("datos incorrector o usuario ya registrado"
            ,style:TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 18,
              ) ,
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromARGB(255, 92, 107, 192),
                  Color.fromARGB(255, 65, 83, 198),
                  Color.fromARGB(255, 63, 81, 181),
                  Color.fromARGB(255, 40, 53, 147),
                ], 
                stops: [0.1, 0.4, 0.7, 0.9]
              )
            ),
          ),
          Container(
            height: double.infinity,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(
                horizontal: 40,
                vertical: 50
              ),
              child: Form(
                  key: _registerKey,
                  child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text('Registro de usuario', style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'OpenSans',
                      fontSize: 30, 
                      fontWeight: FontWeight.bold,
                    )),                  
                    SizedBox(
                          height: 30.0,
                        ),
                        _buildFirstname(),
                        _buildLastname(),
                        _buildAge(),       
                        _buildEmail(),           
                        _buildPasswordTF(),
                        _buildLoginBtn(),
                        _buildSignupBtn(),
                        if(_error)
                        _errorEnElRegistro(),
                        //_crearFecha(context),
                        
                    ],
                  ),
              ),
              ),
            )
          ],
        ),
      );
    }
  }