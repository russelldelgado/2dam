import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';


class Administradores extends StatelessWidget {
  static final route = '/administradores';
  final GlobalKey<FormState> _administradorKeyForm = GlobalKey<FormState>();
  String password ;

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<AppViewModels>(
      builder: (context, child, model) {


    

  String _almacenaPassword(String dato){
    password = dato;
    return null;
  }

  _comprobarPassword(){
    
    print("---------------comprobando password");
    print(password);
    if(_administradorKeyForm.currentState.validate()){  


    if(password.contains('contraseñadeadministradoresparalosprofesoresdelinstituto')){
          PreferencesModels().adminstrador = true;
          model.refres();
        return true;
    }
    
    }else{
      return false;
    }
  }

  
      
  Widget _accessAdmin() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: () => _comprobarPassword(),
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'LOGIN',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

          return Scaffold(
        appBar: AppBar(title: Text('ADMINISTRADOR'),),
        body: Stack(
          children: <Widget>[
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.fromARGB(255, 92, 107, 192),
                    Color.fromARGB(255, 65, 83, 198),
                    Color.fromARGB(255, 63, 81, 181),
                    Color.fromARGB(255, 40, 53, 147),
                  ], 
                  stops: [0.1, 0.4, 0.7, 0.9]
                )
              ),
            ),
            Container(
              height: double.infinity,
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.symmetric(
                  horizontal: 40,
                  vertical: 50
                ),
                child: Form(
                  key: _administradorKeyForm,
                    child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('ADMINSTRACION', style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'OpenSans',
                        fontSize: 30, 
                        fontWeight: FontWeight.bold,
                      )),     


                      TextFormField(

                        maxLines: 1,
                        validator: _almacenaPassword,
                        initialValue:'contraseñadeadministradoresparalosprofesoresdelinstituto' ,
                        obscureText: true,
                         decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.only(top: 14.0),
                        prefixIcon: Icon(
                          Icons.lock,
                          color: Colors.white,
                        ),
                        hintText: 'Introduce tu contraseña',
                        hintStyle: kHintTextStyle,
                      ),
                      ) ,

                      _accessAdmin(),            
                      
                      ],
                    ),
                ),
                ),
              )
            ],
          ),

      );}
    );
  }
}