
import 'package:flutter/material.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/pages/formularios/actualizarPieza.dart';
import 'package:museo/pages/formularios/borrarPieza.dart';
import 'package:museo/providers/pieza_providers.dart';
import 'package:museo/utilities/constants.dart';

class PiezaDetalle extends StatelessWidget {

  static final String route = "/piezaDetalle";

  @override
  Widget build(BuildContext context) {

    final piezaDesdeMap = ModalRoute.of(context).settings.arguments;
    final  PiezaModels piezaDetalle = PiezaModels.fromMap(piezaDesdeMap);
    

 Widget _crearAppbar(PiezaModels pieza){
    return SliverAppBar(
      elevation: 2.0,
      backgroundColor: Colors.deepPurple,
      expandedHeight: 200.0,
      floating: false,
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        centerTitle: true,
        title: Text(pieza.nombre ,
        style: TextStyle(color: Colors.white , fontSize: 16.0),),
        background: FadeInImage(
          image: NetworkImage(pieza.rutaImagen), 
          placeholder: AssetImage('assets/img/loading.gif'),
          fadeInDuration: Duration(seconds: 1),
          fit: BoxFit.cover,
        ),
      ),
    );
  }

Widget _posterTitulo(PiezaModels piezaDetalle ,BuildContext context){


    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.0),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20.0),
            child: Image(image: NetworkImage(piezaDetalle.rutaImagen) ,height: 150, width: 150,)),
          SizedBox(width :20.0),
          Flexible(
            child:Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("ANTIGUEDAD" , style: Theme.of(context).textTheme.headline6 , overflow: TextOverflow.ellipsis,),
                //Text(piezaDetalle.descripcion  ,style: Theme.of(context).textTheme.subtitle1, overflow: TextOverflow.ellipsis,),
                Row(
                  children: [
                    Icon(Icons.date_range),
                    SizedBox(width : 10),
                    Text(piezaDetalle.fechaCreacion.toString().substring(0 ,10),style: Theme.of(context).textTheme.subtitle1)
                  ],
                )
              ],
              ) )
        ],
      ),
    );
  }

 Widget _descripcion(PiezaModels piezaDetalle ,context){
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10 , vertical: 20),
      child: Column(
              children:[ 
                Text(piezaDetalle.nombre , style: TextStyle( color: Colors.deepPurple , fontSize: 20 , fontWeight: FontWeight.bold)  , overflow: TextOverflow.ellipsis),
                SizedBox(height: 10,),
                Text(' pues estamos probando a ver como va esto que creo que no deberia dar ningun fallo pero bueno nunca se sabe${piezaDetalle.descripcion}',
                 textAlign: TextAlign.justify,),
              ]),
    );
  }

Widget _botonesFormulario() {
    return Container(
  padding: EdgeInsets.all(0.0),
   decoration: boxDecoration,
  child: Row(
    mainAxisSize: MainAxisSize.max,
    children: <Widget>[
      SizedBox(width: 10,),
      Expanded(
      flex: 1,
      child: FlatButton.icon(
        onPressed: () {
          Navigator.pushNamed(context, ActualizarPieza.route , arguments: piezaDesdeMap);
        },
        icon: Icon(Icons.update),
        label: Text("UPDATE"),
        //color: Colors.deepPurple,

      ),
        ),
      SizedBox(width: 10,),
      Expanded(
          flex: 1,
          child: FlatButton.icon(
            onPressed: () {
             Navigator.pushNamed(context, BorrarPieza.route , arguments: piezaDesdeMap);
            },
            icon: Icon(Icons.delete),
            label: Text("DELETE"),
            //color:Colors.deepPurple,
          ),
        ),
      SizedBox(width: 10,),
    ],
  ),
);
  }


    return Scaffold(
      bottomNavigationBar: ( PreferencesModels().administrador)? _botonesFormulario() : null,
      body: CustomScrollView(
        slivers: <Widget>[
          _crearAppbar(piezaDetalle),
          SliverList(
            delegate: SliverChildListDelegate(
            [
              SizedBox(height: 10,),
              _posterTitulo(piezaDetalle , context),
              _descripcion(piezaDetalle , context),
              
            ]
          ),)
        ],
      ),
    );
}
}
