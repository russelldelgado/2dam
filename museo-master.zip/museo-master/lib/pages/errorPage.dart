
import 'package:flutter/material.dart';


class ErrorRoutesPage extends StatelessWidget {
  const ErrorRoutesPage({Key key}) : super(key: key);
  static final route = 'Error';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
          body:Card(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FadeInImage(
                        placeholder: AssetImage('assets/jar-loading.gif') ,
                        image:  NetworkImage('http://altaglatam.com/wp-content/uploads/2014/03/errores.png'),
                        fit: BoxFit.fill,
                        ),
                        SizedBox(height: 20,),
                        Text('ERROR CON LA RUTA ESPECIFICADA')
                    ],
                  ),
                ),
    );
  }
}