
import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/pages/formularios/crearCategoria.dart';
import 'package:museo/widgets/DrawersMenu.dart';
import 'package:museo/widgets/cardPersonalizadaCategoria.dart';
import 'package:museo/pages/piezasPorCategoria.dart';
import 'package:scoped_model/scoped_model.dart';

class Museo  extends StatelessWidget{
  static final route  ="/museo";

  Widget _listaCategorias(){

    return ScopedModelDescendant<AppViewModels>(
          builder: (context, child, model) => FutureBuilder(
            future: model.categorias,
            //initialData: [],
            builder: (context, AsyncSnapshot<List<CategoriaModels>> snapshot){ 
                switch(snapshot.connectionState){
                  case ConnectionState.active:
                  case ConnectionState.waiting:
                    return Container(child: Center(child: CircularProgressIndicator(),),);
                  case ConnectionState.none:
                    return Container(child : Center(child: Text('ERROR EN LA CONECCION'),));
                  case ConnectionState.done:
                    return ListView(children :_listaItems(snapshot.data , context));
                }
                return Container(child : Center(child: Text('ALGO ANDA MAL'),));
            } 
      ),
    ) ;
  }

  List<Widget> _listaItems(List<CategoriaModels> datos ,context) {
    final  List<Widget> opciones = [];
    datos.forEach((categoria) { 
       final Widget widgetTemporal = CardPersonalizadaCategoria(categoria: categoria);//_cardTipo2(categoria , context);

      opciones..add(widgetTemporal)
              ..add(Divider());
    });
  return opciones;
  }

//ESTE WIDGET SE ENCARGA DE DEVOLVERME UN LISTADO CON TODAS LAS CATEGORIAS QUE TENGO EN MI LISTA DE CATEGORIAS;
 Widget _cardTipo2(CategoriaModels categoria , context) {
    return Card(
      margin: EdgeInsets.all(20),
      elevation: 10,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
              child: Stack(
              alignment: AlignmentDirectional.center,
              children: [
                FadeInImage(
                  placeholder: AssetImage('assets/imagenes/loading.gif'), 
                  image:  NetworkImage(categoria.imagenUrl),
                  fadeInDuration: Duration(seconds: 2),
                  height: 100,
                  fit: BoxFit.cover,
                  ),
                Container(
                child: Text(categoria.nombre, style: TextStyle(fontSize:20 , fontWeight: FontWeight.bold , backgroundColor: Colors.white) ,),
                padding: EdgeInsets.all(10.0),
                ),
              ],
            ),

            onTap: (){
              //esto esra para hacer una prueva y pasar los elementos ya de tipo categoria y luego poder trabajar con ellos
             // Categoria categoria = Categoria.fromMap(element);
              //final piezas = PiezasPorCategoria(categoria: categoria); 

             // print('ME ESTAS TOCANDO HP TUS DATOS SON ${categoria.toString()}');
              //esta ruta pasa como argumentos el elemento tocado
              Navigator.pushNamed(context, PiezasPorCategoria.route ,arguments: categoria.toMap());
            },
          ),
        ],
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
   return Scaffold(
     floatingActionButton: (PreferencesModels().administrador) ? FloatingActionButton(
          onPressed: () {
          Navigator.pushNamed(context, CrearCategoria.route);
          },
          child: Icon(Icons.add),
         
        ) : null,

     drawer: DrawersMenu(),
     appBar: AppBar(title: Text('MUSEOS'),
     centerTitle: true,
     //este actions luego lo podemos eliminar almenos la pagina de error si
     actions: [
       IconButton(
         icon: Icon(Icons.logout), 
         onPressed: () async{
          var logout = await ScopedModel.of<AppViewModels>(context , rebuildOnChange: true).logout();
         },)
     ],
     ),
     body: _listaCategorias(), //Container(child: Center(child: Text('LOGIN CORRECTAMENTE REALIZADO'),),)//_listaCategorias(),
   );
  }
}
