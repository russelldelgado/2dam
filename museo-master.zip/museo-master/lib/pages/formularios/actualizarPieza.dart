import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';

class ActualizarPieza extends StatefulWidget {
  static final route = '/ActualizarPieza';

  ActualizarPieza({Key key}) : super(key: key);

  @override
  _ActualizarPiezaState createState() => _ActualizarPiezaState();
}

class _ActualizarPiezaState extends State<ActualizarPieza> {
final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();
  List<PiezaModels> listaPiezas = List();
  PiezaModels piezaModels = PiezaModels();
  PiezaModels piezaModelsAntigua = PiezaModels();

  List<CategoriaModels> listaDeCategorias = List();
  CategoriaModels categoriaModels = CategoriaModels();

  bool _isVisible = false;
  bool _primeraEleccionCategoria = true;

  TextEditingController _inputFieldDateController = new TextEditingController();
  TextEditingController _idPieza = new TextEditingController();
  TextEditingController _nombrePieza = new TextEditingController();
  TextEditingController _rutaImagenPieza = new TextEditingController();
  TextEditingController _descripcionPieza = new TextEditingController();
  
  String categoriaAntigua = '';
  



Widget _selectCategorie() {
     

    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return Visibility(
      visible: _isVisible,
          child: FutureBuilder(
            future: ScopedModel.of<AppViewModels>(context).categorias,
            builder: (context, snapshot) {
                  if(snapshot.hasData){


                    listaDeCategorias = snapshot.data;

                    listaDeCategorias.forEach((element) {
                      if(piezaModels.idCategoria == element.id)
                      categoriaModels = element;
                    
                     });

                    
                    
                          return Listener(
                      onPointerDown: (_) => FocusScope.of(context).unfocus(),
                      child: DropdownButtonFormField(
                        value: categoriaModels,
                        isExpanded: true,
                        decoration: InputDecoration(
                            enabledBorder: UnderlineInputBorder(
                                borderSide:
                                    BorderSide(color: Color.fromARGB(255, 109, 168, 241)))),
                        icon: Icon(Icons.arrow_drop_down,
                            color: Color.fromARGB(255, 109, 168, 241)),
                        elevation: 16,
                        hint: Text('Selecciona categoria', style: kHintTextStyle),
                        items: listaDeCategorias.map((categoria) {
                          return DropdownMenuItem(
                            value: categoria, 
                            child: Text(categoria.nombre),
                            onTap: () {
                             // _primeraEleccionCategoria = false;
                              categoriaModels = categoria;
                              piezaModels.idCategoria = categoriaModels.id;

                            },
                            );
                        }).toList(),
                        //validator: _validateCategory,
                        onChanged: (value) {setState(() {
                            _isVisible = true;
                          });},
                        onSaved: (value) {        
                        },
                      ),
                    );
            }
            
              else return Text('ACTUALMENTE NO DISPONIBLE');

            },
           
      ),
    );
  }

  Widget _selectPiece() {
     

    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return Visibility(
          
          child: Listener(
        onPointerDown: (_) => FocusScope.of(context).unfocus(),
        child: DropdownButtonFormField(
          isExpanded: true,
          decoration: InputDecoration(
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: Color.fromARGB(255, 109, 168, 241)))),
          icon: Icon(Icons.arrow_drop_down,
              color: Color.fromARGB(255, 109, 168, 241)),
          elevation: 16,
          hint: Text('Selecciona una pieza', style: kHintTextStyle),
          items: listaPiezas.map((pieza) {
            return DropdownMenuItem(
              value: pieza, 
              child: Text(pieza.nombre),
              onTap: () {
  print("----------------------------------------------categoria antigua en seleccionar pieza $categoriaAntigua------------------------");

                piezaModels = pieza;
                categoriaAntigua = piezaModels.idCategoria;
                 piezaModelsAntigua = pieza;

  print("----------------------------------------------categoria antigua en seleccionar pieza $categoriaAntigua------------------------");

              },
              );
          }).toList(),
          //validator: _validateCategory,
         onChanged: (value) {setState(() {
                            _isVisible = true;
                          });},
          onSaved: (value) {        
          },
        ),
      ),
    );
  }

  Widget _buildId() {

      _idPieza.text = piezaModels.id;

    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding: EdgeInsets.only(top: 10), child: Text('ID', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              readOnly: true,
              controller: _idPieza,
              onChanged: (value) {
                piezaModels.id = value;
              },
              onSaved: (newValue) => piezaModels.id = newValue,
              //keyboardType: TextInputType.number,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.text_format,
                    color: Colors.white,
                  )),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildName() {

      _nombrePieza.text = piezaModels.nombre;

    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding:EdgeInsets.only(top: 10), child: Text('Nombre', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              controller: _nombrePieza,
              onChanged: (value){
                piezaModels.nombre = value;
              },
              onSaved: (newValue) => piezaModels.nombre = newValue,
              keyboardType: TextInputType.name,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.text_format,
                  color: Colors.white,
                ),
                hintText: 'Introduce un nombre',
                hintStyle: kHintTextStyle,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildImageUrl() {

    _rutaImagenPieza.text = piezaModels.rutaImagen;
    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              padding: EdgeInsets.only(top: 10),
              child: Text('Ruta de la imagen', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              controller: _rutaImagenPieza,
              onChanged: (value) {
                piezaModels.rutaImagen = value;
              },
              onSaved: (newValue) => piezaModels.rutaImagen = newValue,
              keyboardType: TextInputType.url,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.web,
                  color: Colors.white,
                ),
                hintText: 'https://',
                hintStyle: kHintTextStyle,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildDescripcion() {

      _descripcionPieza.text = piezaModels.descripcion;

    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              padding: EdgeInsets.only(top: 10),
              child: Text('Descripción', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 120.0,
              child: TextFormField(
                controller: _descripcionPieza,
                onChanged: (value) {
                  piezaModels.descripcion = value;
                },
                onSaved: (newValue) => piezaModels.descripcion = newValue,
                maxLines: null,
                keyboardType: TextInputType.multiline,
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.description,
                    color: Colors.white,
                  ),
                  hintText: 'Introduce una descripción',
                  hintStyle: kHintTextStyle,
                ),
              ),
            ),
        ],
      ),
    );
  }

  _selectedData(BuildContext context) async{

    DateTime picker = await showDatePicker(
      context: context, 
      initialDate: new DateTime.now(), 
      firstDate: new DateTime(1500), 
      lastDate: new DateTime(20000));

      if(picker!=null){
        setState(() {
          piezaModels.fechaCreacion = picker;
         // _fecha = picker.toString();
          //_inputFieldDateController.text = _fecha;
          
        });
      }

  }

  Widget _crearFechaPersonalizada(BuildContext context){

     _inputFieldDateController.text = piezaModels.fechaCreacion.toString();

    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding: EdgeInsets.only(top: 10), child: Text('Antigüedad de la pieza', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              
              controller: _inputFieldDateController,
              enableInteractiveSelection: false,
              onChanged: (value) {
               // piezaModels.fechaCreacion = DateTime.parse(_fecha);
              },
              keyboardType: TextInputType.name,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.calendar_today,
                  color: Colors.white,
                ),
                hintText: 'FECHA DE FABRICACION DE LA PIEZA',
                labelText: 'Fecha de fabricacion',
                hintStyle: kHintTextStyle,
              ),
              onTap: () {
                //quitar el foco de aqui hay varias maneras
                FocusScope.of(context).requestFocus(new FocusNode());
                //con esta funciona nos devulve una ventana para poder seleccionar la fecha
                _selectedData(context);
              },
            ),
          )
        ],
      ),
    );
  }

_anadirALaNuevaCategoria({BuildContext context})async{
          final categoriaNueva = await ScopedModel.of<AppViewModels>(context).categoria(piezaModels.idCategoria);
          categoriaNueva.piezasDelMuseo.add(piezaModels);
          final introducidoALaNuevaCategoria = await ScopedModel.of<AppViewModels>(context).updateCategoria2(categoriaNueva);
          if(introducidoALaNuevaCategoria){
          }

}

_eliminadoDeLaAntiguaCategoria(BuildContext context)async{
          final categoriaAEliminarNueva = await ScopedModel.of<AppViewModels>(context).categoria(categoriaAntigua);
          categoriaAEliminarNueva.piezasDelMuseo.remove(piezaModelsAntigua);
          final eliminadaLaAntiguaPiezaDeLaCategoria = await ScopedModel.of<AppViewModels>(context).updateCategoria2(categoriaAEliminarNueva);
          if(eliminadaLaAntiguaPiezaDeLaCategoria){
          }
           await ScopedModel.of<AppViewModels>(context).refres();
}

  Widget _buildLoginBtn(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: ()async{
          print('Botón Actualizar pulsado');
          print('PIEZA COMPLETA ------------------------------------------------$piezaModels');

          final piezaModificada = await ScopedModel.of<AppViewModels>(context).updatePieza(piezaModels);

          if(piezaModificada){

            _anadirALaNuevaCategoria(context : context);
            _eliminadoDeLaAntiguaCategoria(context);
          }

          (piezaModificada) ? print('MODIFICADA CORRECTAMENTE') : print('FALLO AL ELIMINAR');

        },
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'ACTUALIZAR',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  Future<List<PiezaModels>> _traerPiezas()async{
    return ScopedModel.of<AppViewModels>(context).piezas;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future:_traerPiezas() ,

      builder: (context, snapshot) {


            if(snapshot.hasData){
              listaPiezas = snapshot.data;
            

            return Scaffold(
              key:_scaffoldKey ,
                    appBar: AppBar(
                      title: Text('Actualizar pieza'),
                    ),
                    body: Stack(
                      children: <Widget>[
                        Container(
                          height: double.infinity,
                          width: double.infinity,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                Color.fromARGB(255, 122, 69, 194),
                                Color.fromARGB(255, 155, 40, 176)
                              ],
                                  stops: [
                                0.1,
                                0.9
                              ])),
                        ),
                        Container(
                          height: double.infinity,
                          child: SingleChildScrollView(
                            physics: AlwaysScrollableScrollPhysics(),
                            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 50),
                            child: Form(
                              key: _registerKey,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text('Actualizar pieza',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'OpenSans',
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                      )),
                                  SizedBox(
                                    height: 30.0,
                                  ),
                                  if(!_isVisible)
                                  _selectPiece(),
                                  _buildId(),
                                  _buildName(),
                                  _buildImageUrl(),
                                  _buildDescripcion(),
                                  _crearFechaPersonalizada(context),
                                  _selectCategorie(),
                                  _buildLoginBtn(context),
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  );
                  }
                 else return CircularProgressIndicator();
      }
      
    );
  }
}