import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';

class BorrarCategoria extends StatefulWidget {

  static final route = '/BorrarCategoria';
  List<CategoriaModels> listacategorias = List();
  BorrarCategoria({Key key}) : super(key: key);
  @override
  _BorrarCategoriaState createState() => _BorrarCategoriaState();
}
class _BorrarCategoriaState extends State<BorrarCategoria> {
 
  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();
  bool _isVisible = false;
  CategoriaModels categoriaModels = new CategoriaModels();
  int contador = 0;


   Future<List<CategoriaModels>> _traerCategorias() async{
    return await ScopedModel.of<AppViewModels>(context).categorias;
}

  Widget _selectCategory() {

    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return Listener(
        
        onPointerDown: (_) => FocusScope.of(context).unfocus(),
        child: DropdownButtonFormField(
          isExpanded: true,
          decoration: InputDecoration(
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: Color.fromARGB(255, 109, 168, 241)))),
          icon: Icon(Icons.arrow_drop_down,
              color: Color.fromARGB(255, 109, 168, 241)),
          elevation: 16,
          hint: Text('Selecciona una categoría', style: kHintTextStyle),
          items: widget.listacategorias.map((category) {
            return DropdownMenuItem(
              value: category, 
              child: Text(category.nombre),
              onTap: () {
               categoriaModels = category;
               setState(() {
              
            });
              },
              );
          }).toList(),
          //validator: _validateCategory,
          onChanged: (CategoriaModels value) {
                          categoriaModels = value;

            },
          onSaved: (value) {    
                
          },
        ),
      );
      

  }

  Widget _buildId() {
    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding: EdgeInsets.only(top: 10), child: Text('ID', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              readOnly: true,
             // onSaved: (newValue) => categoriaModels.id = newValue,
              keyboardType: TextInputType.number,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.text_format,
                    color: Colors.white,
                  )),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildName() {
    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding:EdgeInsets.only(top: 10), child: Text('Nombre', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
             // onSaved: (newValue) =>categoriaModels.nombre = newValue,
              keyboardType: TextInputType.name,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.text_format,
                  color: Colors.white,
                )
              ),
            ),
          )
        ],
      ),
    );
  }


  void _deleteCategoria( BuildContext context ) async{
    showDialog(
      context: context , 
      builder: (contextDialogo) => 
      AlertDialog( 
        title: Text('ELIMINAR CATEGORIA'), 
        content: Text('ESTAS SEGURO DE BORRAR ESTA CATEGORIA ?'),
        actions: [
          FlatButton(
            onPressed: ()=>Navigator.pop(context), 
            child: Text('CANCELAR')),
          ScopedModelDescendant<AppViewModels>(
               builder: (context, child, model) =>  
            FlatButton(
            onPressed: ()async {
              var msg = 'PULSADO ELIMINAR DE SCOPE MODAL DESCENDANT ${categoriaModels.id}';
              var delete = await ScopedModel.of<AppViewModels>(context).deleteCategoria(categoriaModels.id);
              
              (delete) ? print(msg) : print('NO SE HA PODIDO ELIMINAR LA CATEGORIA CON EL ID ${categoriaModels.id}'); 

              

                Navigator.pop(context);
            }, 
            child: Text('ELIMINAR')),
             ),
        ],
        ),
        );
  }

  Widget _buildLoginBtn(BuildContext context  ) {
    print("entrando en lo que el builogin--------------------------------------------------");
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: () {
          print('Botón Borrar pulsado');
          _deleteCategoria(context );

        },
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'BORRAR',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {


    return FutureBuilder(
      future: _traerCategorias(),
      builder: (context, snapshot) {
        
          if(snapshot.hasData){
            widget.listacategorias = snapshot.data;
            contador++;
            print('------------------------------inicializando lo que es la categoria $contador');
           
        
        return Scaffold(
        appBar: AppBar(
          title: Text('Borrar categoría'),
        ),
        body: Stack(
          children: <Widget>[
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                    Color.fromARGB(255, 122, 69, 194),
                    Color.fromARGB(255, 155, 40, 176)
                  ],
                      stops: [
                    0.1,
                    0.9
                  ])),
            ),
            Container(
              height: double.infinity,
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 50),
                child: Form(
                  key: _registerKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('Borrar categoría',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'OpenSans',
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          )),
                      SizedBox(
                        height: 30.0,
                      ),
                      _selectCategory( ),
                     // _buildName(),
                      _buildLoginBtn(context ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      );}
        else{
          return CircularProgressIndicator();
        }

       } 
       
       
       );
  }
}


/*

 Widget _selectCategory(CategoriaModels categoriasModels , List<CategoriaModels> listaDeCategorias) {
     List<CategoriaModels> categorias = List();

    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return FutureBuilder(
      future: _traerCategorias(),
      builder: (context, snapshot) {
        
        if(snapshot.hasData){
        categorias = snapshot.data;
        listaDeCategorias = categorias;
        categoriasModels = listaDeCategorias[0];
        }

                  return Listener(
        onPointerDown: (_) => FocusScope.of(context).unfocus(),
        child: DropdownButtonFormField(
          value: categoriasModels,
          /*
          value: product.category,
                      elevation: 16,
                      hint: Text('Seleccione la Categoría'),
                      items: CATEGORIES.map((ProductCategory category) {
                        return DropdownMenuItem<ProductCategory>(
                            value: category, child: Text(category.name));
                      }).toList(),
                      validator: _validateCategory,
                      onChanged: (value) {},
                      onSaved: (ProductCategory value) {
                        setState(() {
                          product.category = value;
                        });
                      },*/
          decoration: InputDecoration(
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: Color.fromARGB(255, 109, 168, 241)))),
          icon: Icon(Icons.arrow_drop_down,
              color: Color.fromARGB(255, 109, 168, 241)),
          elevation: 16,
          hint: Text('Selecciona una categoría', style: kHintTextStyle),
          items: categorias.map((category) {
     
            widget.categoriaModels = category;
            return DropdownMenuItem(
              value: category, 
              child: Text(category.nombre),
              onTap: () {
               widget.categoriaModels = category;
              },
              );
          }).toList(),
          //validator: _validateCategory,
          onChanged: (CategoriaModels value) {
                          widget.categoriaModels = value;

            },
          onSaved: (value) {    
                
          },
        ),
      );
      }


    );
  }

 */