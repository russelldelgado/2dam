import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';

class ActualizarCategoria extends StatefulWidget {

  static final route = '/ActualizarCategoria';

  ActualizarCategoria({Key key}) : super(key: key);
  @override
  _ActualizarCategoriaState createState() => _ActualizarCategoriaState();
}
class _ActualizarCategoriaState extends State<ActualizarCategoria> {

  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();
  //CategoriaModels piezaModels = CategoriaModels();
  CategoriaModels categoriaElejida = CategoriaModels();
  List<CategoriaModels> listaCategorias = List();
  bool tocado = false;
  bool _isVisible = false;



  TextEditingController _idpieza = new TextEditingController();
  TextEditingController _nombreCategoria = new TextEditingController();
  TextEditingController _rutaImagen = new TextEditingController();

  Future<List<CategoriaModels>> _traerCategorias()async{
    return await ScopedModel.of<AppViewModels>(context).categorias;
  }

  Widget _selectCategory() {
    return Listener(
      onPointerDown: (_) => FocusScope.of(context).unfocus(),
      child: DropdownButtonFormField(
        decoration: InputDecoration(
            enabledBorder: UnderlineInputBorder(
                borderSide:
                    BorderSide(color: Color.fromARGB(255, 109, 168, 241)))),
        icon: Icon(Icons.arrow_drop_down,
            color: Color.fromARGB(255, 109, 168, 241)),
        elevation: 16,
        hint: Text('Selecciona una categoría', style: kHintTextStyle),
        items: listaCategorias.map((category) {
          return DropdownMenuItem(
            value: category, 
            child: Text(category.nombre),
            onTap: () => categoriaElejida = category,
            );
        }).toList(),
        //validator: _validateCategory,
        onChanged: (value) {setState(() {
            _isVisible = true;
          });},
        onSaved: (value) {        
        },
      ),
    );
  }

  Widget _buildId() {

    _idpieza.text = categoriaElejida.id;

    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding: EdgeInsets.only(top: 10), child: Text('ID', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              controller: _idpieza,
              readOnly: true,
              //onSaved: (newValue) => categoriaElejida.id = newValue,
              //keyboardType: TextInputType.number,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(top: 14.0),
                  prefixIcon: Icon(
                    Icons.text_format,
                    color: Colors.white,
                  )),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildName() {
    _nombreCategoria.text = categoriaElejida.nombre; 

    return Visibility(
     // maintainState: true,
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              padding: EdgeInsets.only(top: 10),
              child: Text('Nombre', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              onChanged: (value) {
               // value = _nombreCategoria.text;
                categoriaElejida.nombre= value;
              },
              
              controller: _nombreCategoria,
              onSaved: (newValue) => categoriaElejida.nombre = newValue,
              keyboardType: TextInputType.name,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.text_format,
                  color: Colors.white,
                ),
                hintText: 'Introduce un nombre',
                hintStyle: kHintTextStyle,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildImageUrl() {

    _rutaImagen.text = categoriaElejida.imagenUrl;
    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              padding: EdgeInsets.only(top: 10),
              child: Text('Ruta de la imagen', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              onChanged: (value) {
                categoriaElejida.imagenUrl= value;
              },
              controller: _rutaImagen,
              onSaved: (newValue) => categoriaElejida.imagenUrl = newValue,
              keyboardType: TextInputType.url,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.web,
                  color: Colors.white,
                ),
                hintText: 'https://',
                hintStyle: kHintTextStyle,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildActualizarBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: ()async {
          print('Botón Actualizar pulsado');

          if(_registerKey.currentState.validate()){
            _registerKey.currentState.save();
          print('--------------------categoria completa ${categoriaElejida.id}----------------------------------------------------');

          var actualizado =  await ScopedModel.of<AppViewModels>(context).updateCategoria2(categoriaElejida);

          (actualizado) ? print('ACTUALIZADO CORRECTAMENTE') : print('NO ACTUALIZADO ALGO ANDA MAL');

          }

          print(categoriaElejida.toJson());

        }, 
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'ACTUALIZAR',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _traerCategorias(),
      builder: (context, snapshot) {
        

          if(snapshot.hasData){
             listaCategorias = snapshot.data;
             return Scaffold(
                  appBar: AppBar(
                    title: Text('Actualizar categoría'),
                  ),
                  body: Stack(
                    children: <Widget>[
                      Container(
                        height: double.infinity,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                              Color.fromARGB(255, 122, 69, 194),
                              Color.fromARGB(255, 155, 40, 176)
                            ],
                                stops: [
                              0.1,
                              0.9
                            ])),
                      ),
                      Container(
                        height: double.infinity,
                        child: SingleChildScrollView(
                          physics: AlwaysScrollableScrollPhysics(),
                          padding: EdgeInsets.symmetric(horizontal: 40, vertical: 50),
                          child: Form(
                            key: _registerKey,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text('Actualizar categoría',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'OpenSans',
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold,
                                    )),
                                SizedBox(
                                  height: 30.0,
                                ),
                                //_buildPieza(),
                                if(!_isVisible)
                                _selectCategory(),

                                _buildId(),
                                _buildName(),
                                _buildImageUrl(),
                                _buildActualizarBtn()
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
      );

          }

          else return CircularProgressIndicator();


      },
        
    );
  }
}