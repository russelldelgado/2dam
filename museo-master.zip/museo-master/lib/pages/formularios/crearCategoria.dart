import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';

class CrearCategoria extends StatefulWidget {
  static final route = '/CrearCategoria';

  CrearCategoria({Key key}) : super(key: key);

  @override
  _CrearCategoriaState createState() => _CrearCategoriaState();
}

class _CrearCategoriaState extends State<CrearCategoria> {
  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();
  CategoriaModels categoria = CategoriaModels();

_guardarCategoria()async{
    if(_registerKey.currentState.validate()){
      _registerKey.currentState.save();


      final added = await ScopedModel.of<AppViewModels>(context).addCategoria(categoria);
      if(added){
        print('CATEGORIA AÑADIDA CORRECTAMENTE');
        categoria = CategoriaModels();
        //await ScopedModel.of<AppViewModels>(context).refres();
      }else{
        print('fallo al añadir la categoria');
      }

    }
}


 String _nombreValidator(String valor){
    if(valor==null || valor.length <4 ){
      return "demasiado corto";
    }
  }

      String _urlValidar(String url){
    final urlValid = RegExp(r'^((?:.|\n)*?)((http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)([-A-Z0-9.]+)(/[-A-Z0-9+&@#/%=~_|!:,.;]*)?(\?[A-Z0-9+&@#/%=~_|!:‌​,.;]*)?)').hasMatch(url);
        if(!urlValid){
          return 'La url no valida';
        }
    
    }


  Column _buildName() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Nombre', style: kLabelStyle),
        SizedBox(height: 10),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            validator: _nombreValidator,
            onSaved: (newValue) => categoria.nombre = newValue,
            keyboardType: TextInputType.name,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.text_format,
                color: Colors.white,
              ),
              hintText: 'Introduce un nombre',
              hintStyle: kHintTextStyle,
            ),
          ),
        )
      ],
    );
  }

  Column _buildImageUrl() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
            padding: EdgeInsets.only(top: 10),
            child: Text('Ruta de la imagen', style: kLabelStyle)),
        SizedBox(height: 10),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            validator: _urlValidar,
            onSaved: (newValue) => categoria.imagenUrl = newValue,
            keyboardType: TextInputType.url,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.web,
                color: Colors.white,
              ),
              hintText: 'https://',
              hintStyle: kHintTextStyle,
            ),
          ),
        )
      ],
    );
  }

  /*Widget _buildPieza() {
    var CATEGORIES = [
      'categoría1',
      'categoría2',
      'categoría3',
      'categoría4',
    ];

    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return Listener(
      onPointerDown: (_) => FocusScope.of(context).unfocus(),
      child: DropdownButtonFormField(
        /*
        value: product.category,
                    elevation: 16,
                    hint: Text('Seleccione la Categoría'),
                    items: CATEGORIES.map((ProductCategory category) {
                      return DropdownMenuItem<ProductCategory>(
                          value: category, child: Text(category.name));
                    }).toList(),
                    validator: _validateCategory,
                    onChanged: (value) {},
                    onSaved: (ProductCategory value) {
                      setState(() {
                        product.category = value;
                      });
                    },*/
        decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color.fromARGB(255,109,168,241)))
        ),      
        icon: Icon(
          Icons.arrow_drop_down,
          color: Color.fromARGB(255,109,168,241)
        ),
        value: piezaModels.piezasDelMuseo,
        elevation: 16,
        hint: Text('Selecciona una pieza', style: kHintTextStyle),
        items: CATEGORIES.map((category) {
          return DropdownMenuItem(value: category, child: Text(category));
        }).toList(),
        //validator: _validateCategory,
        onChanged: (value) {},
        onSaved: (value) {
          setState(() {
            piezaModels.piezasDelMuseo = value;
          });
        },
      ),
    );
  }*/

  Widget _buildCrearBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: (){ 
          print('Botón Crear pulsado');
          _guardarCategoria();
          },
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'CREAR',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Crear categoría'),
      ),
      body: Stack(
        children: <Widget>[
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                  Color.fromARGB(255, 122, 69, 194),
                  Color.fromARGB(255, 155, 40, 176)
                ],
                    stops: [
                  0.1,
                  0.9
                ])),
          ),
          Container(
            height: double.infinity,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 50),
              child: Form(
                key: _registerKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text('Crear categoría',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'OpenSans',
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        )),
                    SizedBox(
                      height: 30.0,
                    ),
                    //_buildPieza(),
                    _buildName(),
                    _buildImageUrl(),
                    _buildCrearBtn()
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}