import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';

class BorrarPieza extends StatefulWidget {

  static final route = '/BorrarPieza';

  BorrarPieza({Key key}) : super(key: key);

  @override
  _BorrarPiezaState createState() => _BorrarPiezaState();
}

class _BorrarPiezaState extends State<BorrarPieza> {
  List<PiezaModels> listaDepiezas = List();
  PiezaModels piezaModels = PiezaModels();
  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();
  bool _isVisible = false;

 Future<List<PiezaModels>> _traerPiezas() async{
    return await ScopedModel.of<AppViewModels>(context).piezas;
}

  Widget _selectPiece() {

    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return Listener(

      onPointerDown: (_) => FocusScope.of(context).unfocus(),
      child: DropdownButtonFormField(
        isDense: true,
        isExpanded: true,
        decoration: InputDecoration(
            enabledBorder: UnderlineInputBorder(
                borderSide:
                    BorderSide(color: Color.fromARGB(255, 109, 168, 241)))),
        icon: Icon(Icons.arrow_drop_down,
            color: Color.fromARGB(255, 109, 168, 241)),
        elevation: 16,
        hint: Text('Selecciona una pieza', style: kHintTextStyle),
        items: listaDepiezas.map((pieza) {
          return DropdownMenuItem(
            value: pieza, 
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text( 'pieza : ' + pieza.nombre),
                Text( ' ID categoria : ' + pieza.idCategoria),

                
                ]),
            onTap: () {
              piezaModels = pieza;
            },
            
            );
        }).toList(),
        //validator: _validateCategory,
        onChanged: (value) {
          setState(() {
            _isVisible = true;
          });
        },
        onSaved: (value) {},
      ),
    );
  }

  Widget _buildName() {
    return Visibility(
      visible: _isVisible,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(padding:EdgeInsets.only(top: 10), child: Text('Nombre', style: kLabelStyle)),
          SizedBox(height: 10),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              onSaved: (newValue) => piezaModels.nombre = newValue,
              keyboardType: TextInputType.name,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.text_format,
                  color: Colors.white,
                )
              ),
            ),
          )
        ],
      ),
    );
  }


  void _deletePieza( BuildContext context ) async{
    showDialog(
      context: context , 
      builder: (contextDialogo) => 
      AlertDialog( 
        title: Text('ELIMINAR PIEZA'), 
        content: Text('ESTAS SEGURO DE BORRAR ESTA PIEZA ?'),
        actions: [
          FlatButton(
            onPressed: ()=>Navigator.pop(context), 
            child: Text('CANCELAR')),
          ScopedModelDescendant<AppViewModels>(
               builder: (context, child, model) =>  
            FlatButton(
            onPressed: ()async {
              var msg = 'PULSADO ELIMINAR DE SCOPE MODAL DESCENDANT ${piezaModels.id}';
              var delete = await ScopedModel.of<AppViewModels>(context).deletePieza(piezaModels);
              (delete) ? print(msg) : print('NO SE HA PODIDO ELIMINAR LA CATEGORIA CON EL ID ${piezaModels.id}'); 
              print(msg);
                Navigator.pop(context);
            }, 
            child: Text('ELIMINAR')),
             ),
        ],
        ),
        );
  }

  Widget _buildLoginBtn(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: (){
        //print(piezaModels.id);
         _deletePieza(context);
         print('Botón Borrar pulsado');



        } ,
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'BORRAR',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future:_traerPiezas() ,
      builder: (context, snapshot) {
        if(snapshot.hasData){
          listaDepiezas = snapshot.data;
           return Scaffold(
        appBar: AppBar(
          title: Text('Borrar pieza'),
        ),
        body: Stack(
          children: <Widget>[
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                    Color.fromARGB(255, 122, 69, 194),
                    Color.fromARGB(255, 155, 40, 176)
                  ],
                      stops: [
                    0.1,
                    0.9
                  ])),
            ),
            Container(
              height: double.infinity,
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 50),
                child: Form(
                  key: _registerKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('Borrar pieza',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'OpenSans',
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          )),
                      SizedBox(
                        height: 30.0,
                      ),
                      _selectPiece(),
                     // _buildName(),
                      _buildLoginBtn(context),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      );

        }

        else return CircularProgressIndicator();
        
      },
         
    );
  }
}
