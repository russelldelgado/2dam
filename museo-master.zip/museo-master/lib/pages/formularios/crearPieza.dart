import 'package:flutter/material.dart';
import 'package:museo/models/appViewModels.dart';
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/utilities/constants.dart';
import 'package:scoped_model/scoped_model.dart';
class CrearPieza extends StatefulWidget {
  static final route = '/CrearPieza';

  CrearPieza({Key key}) : super(key: key);

  @override
  _CrearPiezaState createState() => _CrearPiezaState();
}


class _CrearPiezaState extends State<CrearPieza> {
  final GlobalKey<FormState> _registerKey = GlobalKey<FormState>();

  PiezaModels piezaModels = PiezaModels();
   String _fecha = '';
  TextEditingController _inputFieldDateController = new TextEditingController();

  _subirPieza() async{
    if(_registerKey.currentState.validate()){
      _registerKey.currentState.save();
      piezaModels.id = "''"; //esto es necesario para que no me devuelva el id null cuando actualice y me lo suba a la bbdd como null
      //CON ESTE CODIGO SE SUBE TODO CORRECTAMENTE
      //final piezaSubida = await ScopedModel.of<AppViewModels>(context).addPieza(piezaModels);
     
      final piezaSubida = await ScopedModel.of<AppViewModels>(context).addPiezaAndActualiceCategoria(piezaModels);
 
      if(piezaSubida!=null){
      }else{
      }
      piezaModels = new PiezaModels();
      return;
    }
      print('-------------------no valida nada o poco  no se ya  --------');
  }
  Future<List<CategoriaModels>> _traerCategorias() async{
    return await ScopedModel.of<AppViewModels>(context).categorias;
}



  //--------------------------validadores----------------------------------------

    String _nombreValidator(String valor){
    if(valor==null || valor.length <4 ){
      return "demasiado corto";
    }
  }

    String _urlValidar(String url){
    final urlValid = RegExp(r'^((?:.|\n)*?)((http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)([-A-Z0-9.]+)(/[-A-Z0-9+&@#/%=~_|!:,.;]*)?(\?[A-Z0-9+&@#/%=~_|!:‌​,.;]*)?)').hasMatch(url);
        if(!urlValid){
          return 'La url no valida';
        }
    
    }

    String _descripcionValidator(String descripcion){
      if(descripcion.length < 100 ||  descripcion == null){
        return 'MIN 100 caracteres';
      }
    }


  Widget _crearFechaPersonalizada(BuildContext context){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Antigüedad de la pieza', style: kLabelStyle),
        SizedBox(height: 10),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            onSaved: (newValue) => piezaModels.fechaCreacion = DateTime.parse(newValue),
            controller: _inputFieldDateController,
            enableInteractiveSelection: false,
            keyboardType: TextInputType.name,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Colors.white,
              ),
              hintText: 'FECHA DE FABRICACION DE LA PIEZA',
              labelText: 'Fecha de fabricacion',
              hintStyle: kHintTextStyle,
            ),
            onTap: () {
              //quitar el foco de aqui hay varias maneras
              FocusScope.of(context).requestFocus(new FocusNode());
              //con esta funciona nos devulve una ventana para poder seleccionar la fecha
              _selectedData(context);
            },
          ),
        )
      ],
    );
  }

  _selectedData(BuildContext context) async{

    DateTime picker = await showDatePicker(
      context: context, 
      initialDate: new DateTime.now(), 
      firstDate: new DateTime(1500), 
      lastDate: new DateTime(20000));

      if(picker!=null){
        setState(() {
          _fecha = picker.toString();
          _inputFieldDateController.text = _fecha;
        });
      }

  }

  //---------------aqui acaba el motodo solo tengo que instanciar lo que es _crear fecha y pasarle el contexto

  Column _buildName() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Nombre', style: kLabelStyle),
        SizedBox(height: 10),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            initialValue: 'valores por defecto para ir probando cosas',
            validator: _nombreValidator,
            onSaved: (newValue) => piezaModels.nombre = newValue,
            keyboardType: TextInputType.name,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.text_format,
                color: Colors.white,
              ),
              hintText: 'Introduce un nombre',
              hintStyle: kHintTextStyle,
            ),
          ),
        )
      ],
    );
  }

  Column _buildImageUrl() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
            padding: EdgeInsets.only(top: 10),
            child: Text('Ruta de la imagen', style: kLabelStyle)),
        SizedBox(height: 10),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            initialValue: 'https://cdn.computerhoy.com/sites/navi.axelspringer.es/public/media/image/2018/12/moviles-relacion-calidad-precio.jpg',
            validator: _urlValidar,
            onSaved: (newValue) => piezaModels.rutaImagen = newValue,
            keyboardType: TextInputType.url,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'OpenSans',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.web,
                color: Colors.white,
              ),
              hintText: 'https://',
              hintStyle: kHintTextStyle,
            ),
          ),
        )
      ],
    );
  }

  Column _buildDescripcion() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
            padding: EdgeInsets.only(top: 10),
            child: Text('Descripción', style: kLabelStyle)),
        SizedBox(height: 10),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 120.0,
            child: TextFormField(
              initialValue: 'Estos son valores por defectos , necesarios para que mientras estamos desarrollando el codigo no haya que ir escribiendo uno por uno los caracteres , muchas gracias por su paciencia y le deseamos un buen dia.',
              validator: _descripcionValidator,
              onSaved: (newValue) => piezaModels.descripcion = newValue,
              maxLines: null,
              keyboardType: TextInputType.multiline,
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.description,
                  color: Colors.white,
                ),
                hintText: 'Introduce una descripción',
                hintStyle: kHintTextStyle,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildLoginBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,
        onPressed: (){
          print('Botón Crear pulsado');
          _subirPieza();
        } ,
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'CREAR',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  Widget _buildCategoria(BuildContext context ) {
    List<CategoriaModels> categorias = List();
     CategoriaModels categoriaModels = CategoriaModels();

     print('------------------------------------------------------------------------entramos metodo categorias');
    /*return Container(padding: EdgeInsets.only(top: 30), child: CustomDropdownButton(text: 'Categoría'));*/
    return FutureBuilder(
      future: _traerCategorias(),
      builder: (context, snapshot) {
        
        if(snapshot.hasData){
             categorias =  snapshot.data;
             //categoriaModels = categorias[0];  
          }

         return Listener(
        onPointerDown: (_) => FocusScope.of(context).unfocus(),
        child: DropdownButtonFormField(
          decoration: InputDecoration(
            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color.fromARGB(255,109,168,241)))
          ),      
          icon: Icon(
            Icons.arrow_drop_down,
            color: Color.fromARGB(255,109,168,241)
          ),
          //value: categoriaModels,
          elevation: 16,
          hint: Text('Selecciona una categoría', style: kHintTextStyle),
          items:  categorias.map((category) {
            return DropdownMenuItem(
              value: category, 
              child:Text(category.nombre, ),
              );
          }).toList(),
          onChanged: (value) {
            categoriaModels = value;
          },
          onSaved: (CategoriaModels categoriaParaGuardar) {
            setState(() {
              piezaModels.idCategoria = categoriaParaGuardar.id;
              categoriaModels = categoriaParaGuardar;
            });
          },
        ),
      );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
         return Scaffold(
                        appBar: AppBar(
                          title: Text('Crear pieza'),
                        ),
                        body: Stack(
                          children: <Widget>[
                            Container(
                              height: double.infinity,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                    Color.fromARGB(255, 122, 69, 194),
                                    Color.fromARGB(255, 155, 40, 176)
                                  ],
                                      stops: [
                                    0.1,
                                    0.9
                                  ])),
                            ),
                            Container(
                              height: double.infinity,
                              child: SingleChildScrollView(
                                physics: AlwaysScrollableScrollPhysics(),
                                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 50),
                                child: Form(
                                  key: _registerKey,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text('Crear pieza',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'OpenSans',
                                            fontSize: 30,
                                            fontWeight: FontWeight.bold,
                                          )),
                                      SizedBox(
                                        height: 30.0,
                                      ),
                                      _buildName(),
                                      _buildImageUrl(),
                                      _buildDescripcion(),
                                    // _buildCreationDate(),
                                      _crearFechaPersonalizada(context),
                                      _buildCategoria(context),
                                      _buildLoginBtn(),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                    );
  }
}