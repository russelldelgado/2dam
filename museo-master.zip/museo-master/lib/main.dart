import 'package:flutter/material.dart';
import 'package:museo/models/preferencesModels.dart';

import 'app/MyApp.dart';

void main() async{
//esto es importante ponerlo para inicializar solo una vez las preferencias
//aparte de eso es una unica instancia de preferencias.
  WidgetsFlutterBinding.ensureInitialized();
  var preferencias = PreferencesModels();
  await preferencias.initPreferences();
  runApp(MyApp());
}