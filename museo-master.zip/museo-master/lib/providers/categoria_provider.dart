import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/providers/api_providers.dart';
class CategoriaProvider extends ApiService{

  String _data;

  CategoriaProvider({@required token}) : super(token: token);


  Future<List<CategoriaModels>> getCategorias() async{
    _data = "category/categorias";
    print('-------------------probando cabeceras------------------');
    print(ApiService.header);
    final Uri url =  Uri.http(ApiService.url, _data);

    try {

        final response = await http.get(url , headers: ApiService.header);
        if(response.statusCode == 200){
        final decodificado = json.decode(response.body);

        final categorias = CategoriasModels.fromJsonList(decodificado);
        print(categorias);
        return categorias.itemsCategoria;
        }
      
    } catch (e) {
      return <CategoriaModels>[];
    }
      return <CategoriaModels>[];

  }


  Future<CategoriaModels> getCategoria(String idcategoria) async{

    _data = "category/categoria/$idcategoria";
    final Uri url = Uri.http(ApiService.url, _data);
    final response = await http.get(url , headers: ApiService.header);

    try {
      if(response.statusCode == 200){
      final decodificado = json.decode(response.body);
      final categoria = CategoriaModels.fromMap(decodificado);
      print(categoria.id);
      return categoria;
    }
    } catch (e) {
      return null;
    }
     return null;
  }

  Future<CategoriaModels> getCategoriav2(String nuevoid) async{

    _data = "category/categoria/$nuevoid";
    print(ApiService.header);
    final Uri url = Uri.http(ApiService.url, _data);
    final response = await http.get(url , headers: ApiService.header);
    try {
      if(response.statusCode == 200){
      final decodificadootro = json.decode(response.body);
      final categoriaNueva = CategoriaModels.fromMap(decodificadootro);
      return categoriaNueva;
    }
    } catch (e) {
     return null;
    }
      return null;
  }

  Future<bool> addCategoria(CategoriaModels categoria) async{

    _data = "category/guardar-categoria";
    final Uri url = Uri.http(ApiService.url, _data);
      CategoriaAddAndUpdate categoriaCorrecta = CategoriaAddAndUpdate.desdeUnCategoriaModelsSinPiezas(categoria);
    final body = categoriaCorrecta.toJson();
    try {
      final response = await http.post( url , headers: ApiService.header , body: body );
      if(response.statusCode == 201){
        return true;
      }else{
        return false;
      }
    } catch (e) {
    }
  }


  Future<bool> deleteCategoria(String categoria)async{

    _data = "category/eliminar-categoria/$categoria";
    final Uri url =  Uri.http(ApiService.url, _data);
      try {
        final response =await http.delete(url , headers : ApiService.header);
        if(response.statusCode == 200){
          return true;
        }
        else{
          return false;
        }
      } catch (e) {
      }
  }

 Future<bool> updateCategoria( CategoriaModels categoria) async{
    _data = "category/actualizar-categoria/${categoria.id}";
    final body = categoria.toJson();
    final Uri url = Uri.http(ApiService.url, _data);
      try {
        final response = await http.put(url , headers: ApiService.header , body: body);
        if(response.statusCode == 200){
          return true;
        }else {
          return false;
        }
        
      } catch (e) {
        return false;
      }
  }

  Future<bool> updateCategoria2( CategoriaModels categoria) async{
    _data = "category/actualizar-categoria/${categoria.id}";

    final categoriaUpdate = CategoriaAddAndUpdate.desdeUnCategoriaModels(categoria);
    final body = categoriaUpdate.toJson();
    final Uri url = Uri.http(ApiService.url, _data);
      try {
        final response = await http.put(url , headers: ApiService.header , body: body);
        if(response.statusCode == 201){
          return true;
        }else {
          return false;
        }
        
      } catch (e) {
        return false;
      }
  }


}