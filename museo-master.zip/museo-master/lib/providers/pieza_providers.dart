
//ruta 
//http://localhost:7000/pieza/piezas
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:museo/models/categoriaModels.dart';
import 'package:museo/models/piezaModels.dart';
import 'package:museo/providers/api_providers.dart';
import 'package:museo/providers/categoria_provider.dart';



class PiezaProvider extends ApiService{
  
  String _data ='';

  PiezaProvider({@required token}) : super (token: token);

  Future<List<PiezaModels>> _procesarRespuesta(Uri url)async {

    try {
        final respuesta = await  http.get(url , headers: ApiService.header);
     // print(respuesta.body);

      if(respuesta.statusCode == 200){
        final decode = json.decode(respuesta.body);
        final piezas = PiezasModels.fromJsonList(decode['piezas']);
        //print(piezas.piezas);
        return piezas.piezas;
    }
    } catch (e) {
    return <PiezaModels>[];
    }
    return <PiezaModels>[];
  }

  Future<List<PiezaModels>> getPiezas() async{
    _data = 'pieza/piezas';
    final url = Uri.http(ApiService.url, _data);
    //ApiService.header['x-access-token'] = "$token";   

    print(url);
    return await _procesarRespuesta(url);
  }


  Future<PiezaModels> getPieza(String idPieza) async{
    _data = 'pieza/pieza/{$idPieza}';
    //ApiService.header['x-access-token'] = "$token";   
    try {
       final uri = Uri.http(ApiService.url , _data);
    final respuesta = await http.get(uri , headers: ApiService.header);
    if(respuesta.statusCode ==200){
      final decode = json.decode(respuesta.body);
      final pieza = PiezaModels.fromMap(decode['pieza']);
      return pieza;
    }
    } catch (e) {
      return null;
    }
      return null;
  }

  Future<bool> addPieza(PiezaModels piezaModels) async{
    _data = "pieza/guardar-pieza";
     final body = piezaModels.toJson();
    //ApiService.header['x-access-token'] = "$token";   
    try {
        final uri = Uri.http(ApiService.url, _data);
      final response= await http.post(uri  ,headers: ApiService.header , body: body );
      if(response.statusCode == 201){
        return true;
      }
      else{
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  Future<PiezaModels> addPiezaAndActualiceCategoria(PiezaModels piezaModels) async{
    _data = "pieza/guardar-pieza";
     final body = piezaModels.toJson();
    //ApiService.header['x-access-token'] = "$token";   
    try {
        final uri = Uri.http(ApiService.url, _data);
        final response= await http.post(uri  ,headers: ApiService.header , body: body );
        if(response.statusCode == 201){
          //final decodificadov2 = PiezaModels.fromJson(response.body);
        final decode = jsonDecode(response.body);
        final pieza = PiezaModels.fromMap(decode['piezaGuardada']);
        final idCategoria = pieza.idCategoria;
    

        final actualizarCategoria = CategoriaProvider();
        CategoriaModels categoriaModels =  await actualizarCategoria.getCategoriav2(idCategoria);
        categoriaModels.piezasDelMuseo.add(pieza);

        final actualizado = await actualizarCategoria.updateCategoria2(categoriaModels);
        
        if(actualizado)print( '--------------------- TOMA YA NINGUN ERROR APARENTE------------------------' );

        return pieza;
      }
      else{
        return null;
      }
    } catch (e) {
      return null;
    }
  }



  Future<bool> deletePieza(PiezaModels piezaModels)async {
    _data = "pieza/eliminar-pieza/${piezaModels.id}";
    try {
      final uri = Uri.http(ApiService.url, _data);
      final response = await http.delete(uri , headers: ApiService.header);
      if(response.statusCode == 200){
        return true;
      }else{
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  Future<bool> updatePieza(PiezaModels piezaModels)async{
    _data = "pieza/actualizar-pieza/${piezaModels.id}";
    //ApiService.header['x-access-token'] = "$token";   
    final body = piezaModels.toJson();
    try {
      final Uri uri = Uri.http(ApiService.url, _data);
      final response = await http.put(
        uri , 
        headers: ApiService.header,
        body: body
        );
      if(response.statusCode ==200){
        return true;
      }else{
        return false;
      }
    } catch (e) {
      return false;
    }
  }

 


}