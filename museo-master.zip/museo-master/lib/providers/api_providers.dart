import 'package:flutter/material.dart';
import 'package:museo/models/preferencesModels.dart';
abstract class ApiService{
  String token ;
  ApiService({@required this.token});
  //static final String url = '192.168.1.110:7000';
  static final String url = '192.168.0.12:7000';
  static final Map<String,String> header = 
        { "content-type":"application/json",
          "x-access-token":"${PreferencesModels().token}",
        };
}

