import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:http/http.dart' as http;
import 'package:museo/models/preferencesModels.dart';
import 'package:museo/models/userCredentialsModels.dart';
import 'package:museo/models/usersModels.dart';
import 'package:museo/providers/api_providers.dart';
class UserProviders extends ApiService {

  String _data = '';

  UserProviders({@required token}) : super(token: token);



  Future<String> usuarioLogin(UserCredentials userCredentials)async{
    _data = 'usuario/iniciarSesion';
    //print('-----------------------------------------------------------' + userCredentials.toJson().toString());

    final cuerpo = userCredentials.toJson();
    final Uri uri = Uri.http(ApiService.url, _data);
    
    try {
      final response = await http.post(uri , headers: ApiService.header , body:cuerpo);
      if(response.statusCode == 200){
        final bodyDecodificado = jsonDecode(response.body);
        //aqui hay un logica estraña algo anda mal ya que el token no me lo coge donde me lo tendria que coger
        final token =  bodyDecodificado['token'];
        PreferencesModels().token= token;
        ApiService.header['x-access-token'] = token;
        return token;
      }else{
        //ApiService.header['x-access-token'] = null;
        return null;
      }
      
    } catch (e) {
    print('--------------------------saltando error catch--------------------------------' );
      return null;
    }
    

  }


  Future<String> usuarioRegister(UsuarioModels usuarioModels)async{
  
  _data = 'usuario/registrarUsuario';
   usuarioModels.id = null;
  final body = usuarioModels.toJson();
  final Uri uri = Uri.http(ApiService.url, _data);
  
  try {
    final response = await http.post(uri , headers : ApiService.header , body: body);
      if(response.statusCode == 201){
        final bodyDecodificado = jsonDecode(response.body);
        String token = bodyDecodificado['token'];
       // ApiService.header['x-access-token'] = token;

      return token;

  }else{
    //ApiService.header['x-access-token'] = null;
    return null;
  }
    
  } catch (e) {
    return null;
  }
  }


  bool isTokenValid(){
    return !JwtDecoder.isExpired(token);
  }

}

//averiguar para qeu sirve esta linea

//Navigator.of(context).pushReplacementNamed (NotesList.route);
