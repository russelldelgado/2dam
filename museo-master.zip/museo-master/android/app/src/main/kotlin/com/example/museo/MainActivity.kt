package com.example.museo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
