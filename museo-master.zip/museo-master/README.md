# MUSEO

Museo es un proyecto hecho con Flutter para listar, añadir, modificar y eliminar piezas de museo por categorías y obtener información detallada de las mismas.

## Modificar la IP para el anfitrión

lib > providers > api_providers

### `lib/main.dart`

La clase para ejecutar la aplicación.
### `lib/models/*`

Este directorio contiene las clases modelo que se se llaman en `main.dart`. Estas clases representan el estado de la aplicación.

### `lib/pages/*`

Este directorio contiene los widgets usados para construir las pantallas de la aplicación.

### `lib/pages/administradores.dart`

Dejando pulsado sobre «cerrar sesión» del navigation drawer, te lleva a la página para iniciar sesión como administrador. La contraseña viene
introducida por defecto por motivos de comodidad durante el desarrollo.

## Página de inicio

<img width="200" src="https://i.imgur.com/YnKLiwZ.png">

## Acciones

<img width="200" src="https://i.imgur.com/UF40DL4.png">