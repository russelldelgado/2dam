
//clase modelo para meter a los deportistas

class Deportistas {

  String nombre ; 
  String caracteristicas ;
  int edad ;
  bool activo ;
  Categoria categoria ;


  Deportistas({this.nombre ='POR DEFECTO', this.caracteristicas = 'POR DEFECTO', this.edad  = 22, this.activo = false , this.categoria });
  

   String activado(){
    if(activo){
      return 'ACTUALMENTE ESTA ACTIVO';
    }if(activo == false){
      return 'DESACTIVADO ';
    }
  }

  }
  

//clase modelo para ir metiendo datos de la categoria deportista

class Categoria {

    String nombreCategoria;
    String caracteristicasDeLaCategoria;

    
  Categoria(
    this.nombreCategoria ,{
    this.caracteristicasDeLaCategoria = 'AUN NO SE HA DEFINIDO UNA CARACTERISTICA',
  });

    
}
