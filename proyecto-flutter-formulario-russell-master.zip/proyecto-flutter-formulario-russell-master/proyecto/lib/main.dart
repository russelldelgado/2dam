import 'package:flutter/material.dart';
import 'package:proyecto/pages/formularioDeProductos.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DEPORTISTAS',
      debugShowCheckedModeBanner: false,
     theme: ThemeData(
        primaryColor: Color(0xFF18ffff),
        primaryColorBrightness: Brightness.light,
        canvasColor: Color(0xFFCCCFD3),
        buttonColor: Color(0xFF8C949C),
        accentColor: Color(0xFF14cba8),
        bottomAppBarColor: Color.fromRGBO(17, 39, 34, 1.0),
        colorScheme: ColorScheme.light(
        primary: Color(0xFFe8eaf6),
        ),
      ),
      home: FormularioDeportistas(),
    );
  }
}






