
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proyecto/pages/Listadojugadores.dart';
import 'package:proyecto/pages/formularioDeProductos.dart';

class Menu extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 5,
      child: ListView(
        children: [
          DrawerHeader(
            child: 
            Center(
              child:
               Text('CABECERA TODO GUAPA')),
          decoration: BoxDecoration(
            color: Colors.white54,
          ),
          ),
           ListTile(
            onTap: (){
            Navigator.push(
                           context, MaterialPageRoute(
                             builder: (context) => 
                             FormularioDeportistas()
                             
                             ));}
            ,
            title: Text('IR AL FORMULARIO'),
            subtitle: Text('rellena todo el formulario'),
          ),
          ListTile(
            onTap: (){
            Navigator.push(
                           context, MaterialPageRoute(
                             builder: (context) => ListaDeJugadores()
                             ));}
            ,
            title: Text('LISTA DE JUGADORES'),
            subtitle: Text('VER LA LISTA DE JUGADORES'),
          ),
          
        ],
      ),
    );
  }

  
}


