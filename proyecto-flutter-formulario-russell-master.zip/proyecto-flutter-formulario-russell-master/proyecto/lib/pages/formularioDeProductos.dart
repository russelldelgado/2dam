

import 'package:flutter/material.dart';
import 'package:proyecto/menuswidg/menusw.dart';
import 'package:proyecto/mock/datos.dart';
import 'package:proyecto/modelo/deportistas.dart';

import 'package:proyecto/pages/Listadojugadores.dart';

class FormularioDeportistas extends StatefulWidget{
  
  
  @override
  State<StatefulWidget> createState()=> _FormularioDeportistasState();
  
    
  }


  
  class _FormularioDeportistasState extends State<FormularioDeportistas> {
//creamos deportistas
//metodos para validar los campos introducidos
         var _formKey = GlobalKey<FormState>();
        Deportistas deportista = Deportistas();

          String _validarNombre(String nombre) {
            if(nombre.isEmpty){
              return 'tiene que meter datos';
            }
            if(nombre.length < 5 ){
              return 'nombre demasiado corto ';
            }if(nombre.length > 20){
              return 'nombre demasiado largo';
            }
            
           }

           String _validarEdad(String edad){
              var edadCorregida =  int.tryParse(edad);

              if(edadCorregida == null){
                return 'EL PRECIO DEBE SER UN VALOR NUMERICO';
              }if(edadCorregida < 18 ){
                return 'ESTE FORMULARIO ES SOLO PARA MAYORES DE 18 AÑOS';
              }
              
           }

           void _guardarFormulario(){
              if(_formKey.currentState.validate()){
                  _formKey.currentState.save();
                  setState(() {
                    DEPORTISTAS.add(deportista);
                  deportista = Deportistas();
                  });
                  _formKey.currentState.reset();

              }
           }


  @override
  Widget build(BuildContext context) {
   return Scaffold(
     drawer: Menu(),
      appBar: AppBar(
        title: Center(child: Text('RELLENE EL FORMULARIO')),
         elevation: 10,
      ),
      body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: 
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
                children: [

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      initialValue:deportista.nombre ,
                      decoration: InputDecoration(
                        hintText: 'NOMBRE DEL DEPORTISTA',
                        contentPadding: EdgeInsets.all(10),
                        border: InputBorder.none,
                        filled: true,
                        fillColor: Colors.green[50],
                      ),
                      validator: _validarNombre,
                      onSaved: (newValue) => deportista.nombre = newValue,
                    ),
                  ),
                  
                  
                   Padding(
                     padding: const EdgeInsets.all(8.0),
                     child: TextFormField(
                      initialValue:deportista.caracteristicas ,
                      decoration: InputDecoration(
                        hintText: 'CARACTERISTICAS DEL DEPORTISTA',
                        contentPadding: EdgeInsets.all(10),
                        border: InputBorder.none,
                        filled: true,
                        fillColor: Colors.green[50],
                      ),
                      
                      onSaved: (newValue) => deportista.caracteristicas = newValue,
                  ),
                   ),
                     Padding(
                     padding: const EdgeInsets.all(8.0),
                     child: TextFormField(
                     keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        hintText: 'EDAD DEL DEPORTISTA',
                        contentPadding: EdgeInsets.all(10),
                        border: InputBorder.none,
                        filled: true,
                        fillColor: Colors.green[50],
                      ),
                      validator: _validarEdad,
                      onSaved: (newValue) => deportista.edad = int.tryParse(newValue) ,
                  ),
                   ),
                  Row(
                   children: [

                      Text('ACTIVO : '),
                   Switch(
                     value: deportista.activo,
                      onChanged: (value)
                       {
                         setState(() {
                         deportista.activo = value;
                           
                         });
                        }),
                   ],
                        ),

                        DropDownDeportistaCategoria(deportista),


                   RaisedButton(
                     child: Text('GUARDAR'),
                     onPressed:  _guardarFormulario,),

                     Text('NUMERO DE DEPORTISTAS ${DEPORTISTAS.length}'),

                     RaisedButton(
                       child: Text('LISTADO DE JUGADORES'),
                       onPressed: () {
                         Navigator.push(
                           context, MaterialPageRoute(
                             builder: (context) => ListaDeJugadores()
                             ));
                       },)
                                    ],
                                ),
                              ))
                    
                          ) ,
                          
                    
                    
                    
                       );
                      }
                    
                    
                    
    
}

class DropDownDeportistaCategoria extends StatelessWidget{
    
    Deportistas deportista;
        
      String  _validarCategoriaDelDeportista(Categoria categoria){
        if(categoria == null){
          return 'La categoria no puede estar vacia';
        }
      }

  DropDownDeportistaCategoria(Deportistas this.deportista);

  @override
  Widget build(BuildContext context) {
    
    return DropdownButtonFormField(
      onSaved: (Categoria jugadores ) {
        deportista.categoria = jugadores;
      } ,
      validator: _validarCategoriaDelDeportista,
      hint: Text('SELECCIONE UNA CATEGORIA'),
      onChanged: (Categoria valor) {
       print(valor.nombreCategoria);
      },
      items: CATEGORIAS.map((Categoria categoriaDeJugador){
      return  DropdownMenuItem<Categoria>(
         value: categoriaDeJugador,
         child: Text(categoriaDeJugador.nombreCategoria));
        
    
      }).toList(),
      );
  }
}

