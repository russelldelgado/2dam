


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proyecto/mock/datos.dart';
import 'package:proyecto/modelo/deportistas.dart';

class DetallesDeJugadores extends StatelessWidget{

   Deportistas deportista ;

   DetallesDeJugadores(this.deportista);

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(

        appBar: AppBar(
          title: Text('DETALLES JUGADOR'),
        ),
        body: Card(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
                JugadoresDatosWidget(dato: 'NOMBRE DEL JUGADOR' , detalle:deportista.nombre ),
                JugadoresDatosWidget(dato: 'CARACTERISTICAS DEL JUGADOR' , detalle:deportista.caracteristicas ),
                JugadoresDatosWidget(dato: 'EDAD DEL JUGADOR' , detalle:deportista.edad.toString() ),
                JugadoresDatosWidget(dato: 'ACTIVO' , detalle: deportista.activado() ),



            ],
          ),
        ),
    );


  }

  
}


 class JugadoresDatosWidget extends StatelessWidget{

  final String dato ;
  final String detalle;


   const JugadoresDatosWidget( {@required this.dato , @required this.detalle});


  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max, children: [
    
      Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Expanded(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, 
              children: [
            Text(
              dato,
              style: TextStyle(fontSize: 18),
            ),
            Text(detalle,
            style: TextStyle(color: Colors.blue[700]),
            
            ),

          ]),
        ),
      )
    ]);
  }
  }

 