

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proyecto/menuswidg/menusw.dart';
import 'package:proyecto/mock/datos.dart';

import 'detallesDeJugadores.dart';

class ListaDeJugadores extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Menu(),

      appBar: AppBar(
        title: Text('LISTADO DE JUGADORES'),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
        Expanded(
          child:
           ListView.separated(
            itemCount: DEPORTISTAS.length,
            separatorBuilder: (context , index)=> Divider() , 
            
            itemBuilder: (context , index){
                 return GestureDetector(
                
                 onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => DetallesDeJugadores(DEPORTISTAS[index])));
                  },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                  Text(DEPORTISTAS[index].nombre),
                  Text(DEPORTISTAS[index].edad.toString())

                  ],
                  
                ),

                 );

            }
            
            , 
            
            
            
            ) ),

        ],
      ),
    );
  }

}