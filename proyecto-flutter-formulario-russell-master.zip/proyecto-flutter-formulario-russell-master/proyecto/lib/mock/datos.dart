

import 'package:proyecto/modelo/deportistas.dart';

var CATEGORIAS = <Categoria>[

  Categoria('CALISTENIA' ,caracteristicasDeLaCategoria: 'DEPORTE QUE SE REALIZA CON EL PROPIO CUERPO CORPORAL'),
  Categoria('ZUMO'),
  Categoria('FUTBOL'),
  Categoria('BOXEO') ,
  Categoria('ATLETISMO')

];


var DEPORTISTAS = <Deportistas>[
  Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
   Deportistas(activo: true),
  Deportistas(nombre: 'JUAN CARLOS PEDRO'),
  Deportistas(nombre: 'CHAMORRO GALAN'),
  Deportistas(activo: true , caracteristicas: 'jugador de lo que sea'),
  
];