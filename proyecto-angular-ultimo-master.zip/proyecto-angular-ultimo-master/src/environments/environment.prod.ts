export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyAccvLkWeKmKQ43FaPia-iuUMjMBFP9n84",
    authDomain: "biblioteca2-b7906.firebaseapp.com",
    projectId: "biblioteca2-b7906",
    storageBucket: "biblioteca2-b7906.appspot.com",
    messagingSenderId: "935580934972",
    appId: "1:935580934972:web:6ddc3aa705e0333cdb3439",
    measurementId: "G-4X4079D11Z"
  },
};
