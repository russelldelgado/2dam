// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase : {
    apiKey: "AIzaSyAccvLkWeKmKQ43FaPia-iuUMjMBFP9n84",
    authDomain: "biblioteca2-b7906.firebaseapp.com",
    projectId: "biblioteca2-b7906",
    storageBucket: "biblioteca2-b7906.appspot.com",
    messagingSenderId: "935580934972",
    appId: "1:935580934972:web:6ddc3aa705e0333cdb3439",
    measurementId: "G-4X4079D11Z"
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
