import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookListComponent } from './book-list/book-list.component';
import { ErrorComponent } from './error/error.component';
import { AddBookComponent } from './add-book/add-book.component';
import { AddPersonaComponent } from './add-persona/add-persona.component';
import { PersonaListComponent } from './persona-list/persona-list.component';

const routes: Routes = [
    {path : '' , component: PersonaListComponent},
  //{path : '' , component : BookListComponent},
  {path : 'nuevo' , component : AddBookComponent},
  {path : 'nuevo/:key' , component : AddBookComponent},
  {path : 'nuevaPersona' , component : AddPersonaComponent},
  {path : 'nuevaPersona/:key' , component : AddPersonaComponent},
  {path : '**' , component : ErrorComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
