import { Component, Input, OnInit } from '@angular/core';
import { Personas } from '../models/personas';
import { FireStorePersonasService } from '../services/fire-store-personas.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-persona-detail',
  templateUrl: './persona-detail.component.html',
  styleUrls: ['./persona-detail.component.css']
})
export class PersonaDetailComponent{

 @Input() persona : Personas;

  constructor(
    private router : Router,
    private fireStorePersonasService :FireStorePersonasService) { }

    delete(){
      if(this.persona != null){
        this.fireStorePersonasService.deletePersona(this.persona);
      }
    }

    edit(){
      this.router.navigate(['/nuevaPersona' , this.persona.key]);
    }

}

