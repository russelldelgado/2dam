import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FireStorePersonasService } from '../services/fire-store-personas.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { Personas } from '../models/personas';

@Component({
  selector: 'app-add-persona',
  templateUrl: './add-persona.component.html',
  styleUrls: ['./add-persona.component.css']
})
export class AddPersonaComponent implements OnInit {

  personaForm: FormGroup = new FormGroup({
    nombre : new FormControl('' , [Validators.required]),
    apellidos : new FormControl('' , [Validators.required]),
    direccion : new FormControl('' , [Validators.required]),
    genero :new FormControl('' , [Validators.required]),
    foto : new FormControl('https://live.mrf.io/statics/i/ps/www.movilzona.es/app/uploads/2019/05/Foto-de-Perfil-en-WhatsApp-696x364.jpg?width=1200&enable=upscale')

  });

  key :string;
  editMode :boolean = false;
  constructor(
    private fireStorePersonasService : FireStorePersonasService,
    private router : Router,
    private activatedRoute : ActivatedRoute

  ) { }


  save(){
    if(this.personaForm.valid){
      let persona : Personas = {
        nombre : this.personaForm.get('nombre').value,
        apellidos : this.personaForm.get('apellidos').value,
        direccion : this.personaForm.get('direccion').value,
        genero : this.personaForm.get('genero').value,
        foto : this.personaForm.get('foto').value,
      };
      if(this.editMode){

        this.fireStorePersonasService.updatePersonas(this.key , persona).then(
          _ => {this.router.navigateByUrl('/');}
        );

      }else{
        this.fireStorePersonasService.assPersona(persona).then( 
          _ => {this.router.navigateByUrl('/');}
        );
      }
    }

  }

  ngOnInit(): void {

    if( this.activatedRoute.snapshot.paramMap.has('key')){
      this.key = this.activatedRoute.snapshot.paramMap.get('key');
      this.editMode = true;
      this.fireStorePersonasService.getPersona(this.key).subscribe(
        editBook =>{
          let miPersona : Personas = editBook.data();
          this.personaForm.get('nombre').setValue(miPersona.nombre),
          this.personaForm.get('apellidos').setValue(miPersona.apellidos),
          this.personaForm.get('direccion').setValue(miPersona.direccion),
          this.personaForm.get('genero').setValue(miPersona.genero),
          this.personaForm.get('foto').setValue(miPersona.foto)
        }
      )
    }   
  
  
  
    }

}
