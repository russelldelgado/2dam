import { Injectable } from '@angular/core';
import { Personas } from '../models/personas';
import { FireStoreService } from './fireStore.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { pipe } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FireStorePersonasService {

  collection : string = "personas";

  constructor(private firestore : AngularFirestore) { }

  getPersonas(){
   return this.firestore.collection<Personas>(this.collection).snapshotChanges().pipe(
      map(
        personas =>{
          return personas.map(
            persona =>{
              const data = persona.payload.doc.data();
              const key = persona.payload.doc.id;
              return {key , ...data};
            }
          )
        }
      )
    )
  }
  getPersona(key : string){
   return this.firestore.collection<Personas>(this.collection).doc(key).get();
  }
  assPersona(persona :Personas){
    return  this.firestore.collection<Personas>(this.collection).add(persona);
  }
  deletePersona(persona : Personas){
    return this.firestore.collection<Personas>(this.collection).doc(persona.key).delete();
  }
  updatePersonas(key :string , persona : Personas){
    return this.firestore.collection<Personas>(this.collection).doc(key).update(persona);
  }
}
