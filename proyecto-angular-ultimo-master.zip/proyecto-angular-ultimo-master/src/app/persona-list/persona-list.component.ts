import { Component, OnInit } from '@angular/core';
import { Observable, pipe } from 'rxjs';
import { Personas } from '../models/personas';
import { FireStorePersonasService } from '../services/fire-store-personas.service';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-persona-list',
  templateUrl: './persona-list.component.html',
})
export class PersonaListComponent implements OnInit {

  personas:Observable<Personas[]> ;
  selectedPersona : Personas;

  constructor(private fireStorePersonasService : FireStorePersonasService) { }

  ngOnInit(): void {
    this.personas = this.fireStorePersonasService.getPersonas().pipe(
      tap(personas =>{
        this.selectedPersona = personas[0];
      })
    )
  }

  select(persona : Personas){
    this.selectedPersona = persona;
  }

}
