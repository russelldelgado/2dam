export interface Book{
    key? : string;
    title : string;
    isbn : string;
    description:string;

}