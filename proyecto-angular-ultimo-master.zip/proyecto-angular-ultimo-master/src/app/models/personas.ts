

export interface Personas{

    key? : string ;
    nombre : string ; 
    apellidos :string;
    direccion : string;
    genero : string;
    foto :string;

}