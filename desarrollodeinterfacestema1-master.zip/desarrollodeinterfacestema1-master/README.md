Listado 1 de ejercicios resueltos en Dart.

Tipos de datos, cadenas, listas, mapas, estructuras de control, funciones, etc.