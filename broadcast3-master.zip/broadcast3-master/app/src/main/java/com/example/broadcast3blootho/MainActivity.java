package com.example.broadcast3blootho;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button blutu ;
    View pagina ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        blutu = findViewById(R.id.btnBloto);

        blutu.setOnClickListener(this);

        pagina = findViewById(R.id.pagina);


    }

    @Override
    public void onClick(View v) {


       // if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){
            //el dispositivo soporta bluetoothle podemos usar esta api


             BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                    // Se ha encontrado el dispositivo. Podemos obtener la información
                    Log.i("DATOS DEL DISPOSITIVO", "Dispositivo BLE encontrado: " + device.getName() + "; MAC " + device.getAddress());
                }
            };
// Esta callback se añade como parámetro al método de inicio de escaneo de esta forma
// bleAdapter.startLeScan(mLeScanCallback);


        }
        /*
        else {



            // Snackbar.make( pagina, "LANZADO" , Snackbar.LENGTH_SHORT).show();
            BroadcastReceiver broadcastReceiverBlutu = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String accion = intent.getAction();
                    Snackbar.make( pagina, accion , Snackbar.LENGTH_SHORT).show();
                    Toast.makeText(context.getApplicationContext() , accion , Toast.LENGTH_SHORT).show();

                    if (BluetoothDevice.ACTION_FOUND.equals(accion)){
                        //se ha encontado un dispositivo bluetooth
                        //se obtinene la informacion del dispositivo del intent

                        BluetoothDevice divide = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        Log.i("DATOS", "DISPOSITIVO ENCONTRADO " + divide.getName() + " MAC " + divide.getAddress());
                        Snackbar.make( pagina, "DISPOSITIVO ENCONTRADO " + divide.getName() + " MAC " + divide.getAddress() , Snackbar.LENGTH_SHORT).show();
                    }


                }
            };

            BluetoothAdapter mBluetoot = BluetoothAdapter.getDefaultAdapter();
            if (mBluetoot == null){
                Snackbar.make( pagina, "SU DISPOSITIVO NO SOPORTA BLUETOOTH" , Snackbar.LENGTH_SHORT).show();
            }
            if (!mBluetoot.isEnabled()){
                //el bluetooht esta apagado solicitamos persmos al usuario para activarlo
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                //REQUEST_ENABLE_BT ES UN VALOR ENTERO QUE VALE 1
                int REQUEST_ENABLE_BT = 1;
                startActivityForResult(enableIntent ,  REQUEST_ENABLE_BT);
            }
            IntentFilter intentFilterBlutu = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            registerReceiver(broadcastReceiverBlutu , intentFilterBlutu);

            if (mBluetoot.isDiscovering()){
                mBluetoot.cancelDiscovery();
            }
            mBluetoot.startDiscovery();

        }


*/


   // }
}