//creamos un enun para abarcar todas las posibilidades que pueden pasar segun el registro que vayamos haciendo
enum RegisterResponseStatus{
SUCCESS , USERALREADYEXIST , PASSWORDSHORT , EMAILINVALID , EMAILPASSWORDREQUIRED ,NETWORKERROR ,UNKNOWERROR
}

//esta clase almacena toda la informacion necesaria para almacenar cualqueira de los errores que me puediera dar el registro en el front y el 
//backend
class RegisterResponse {
  String errorMessage;
  RegisterResponseStatus status;
  String token;

  RegisterResponse(
    this.status,
    this.errorMessage,
    [this.token] // parametro opcional sin nombre
  );

  RegisterResponse.success(token , errorMessage) : this(RegisterResponseStatus.SUCCESS , errorMessage , token);
  RegisterResponse.userAlreadyExist(errorMessage) : this(RegisterResponseStatus.USERALREADYEXIST , errorMessage );
  RegisterResponse.passwordShort(errorMessage) : this(RegisterResponseStatus.PASSWORDSHORT , errorMessage );
  RegisterResponse.emailInvalid(errorMessage) : this(RegisterResponseStatus.EMAILINVALID , errorMessage );
  RegisterResponse.emailPasswordRequired(errorMessage) : this(RegisterResponseStatus.EMAILPASSWORDREQUIRED , errorMessage );
  RegisterResponse.networkError(errorMessage) : this(RegisterResponseStatus.NETWORKERROR , errorMessage );
  RegisterResponse.unknowError(errorMessage) : this(RegisterResponseStatus.UNKNOWERROR , errorMessage );




}
