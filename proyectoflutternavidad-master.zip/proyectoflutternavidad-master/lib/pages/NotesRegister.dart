


import 'package:flutter/material.dart';
import 'package:flutter_application_1/Responses/RegisterResponses.dart';
import 'package:flutter_application_1/Widgets/LoginWidget.dart';
import 'package:flutter_application_1/Widgets/NotesDrawers.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:flutter_application_1/models/User.dart';
import 'package:flutter_application_1/models/UserCredentials.dart';
import 'package:scoped_model/scoped_model.dart';

import 'NotesList.dart';

class NotesRegister extends StatefulWidget {
  static final String route = '/notesRegister';
  NotesRegister({Key key}) : super(key: key);

  @override
  _NotesRegisterState createState() => _NotesRegisterState();
}

class _NotesRegisterState extends State<NotesRegister> {


 final GlobalKey<FormState>  _formkey = GlobalKey<FormState>(); 
  User _user = User();
  var _error = false;
  //instanciamos esto para que sea global y para que no sea null y evitar posibles errores lo que hacemos es instanciarlo con su construtor con nombre
  RegisterResponse registerResponse = RegisterResponse.unknowError("ERROR DESCONODICO VENTANA");


  _register()async{
    if(_formkey.currentState.validate()){
      _formkey.currentState.save();

//con esto ya tenemos la instancia de scope view model con el patro scopeModel y asi poder llamar al metodo Register
//este dato lo almacenamos ne una variable registerResponse que es una clase que hemos creado antes
//para registrar todos los posibles herrores que pueden ocurrir y segun el tipo de error devolver una respues u otra.  
//tenemos que esperar la respuesta y luego ya devolverla.
       registerResponse = await ScopedModel.of<NotesViewModel>(context , rebuildOnChange: true ,).register(_user);

      if(registerResponse.status == RegisterResponseStatus.SUCCESS){
        Navigator.pushNamedAndRemoveUntil(context, NotesList.route, (route) => false);
      }
      else{
       setState(() {
      _error = true;
    });
      }
    }
  }


  onChangeField(String value){
    setState(() {
      _error = false;
    });
  }

  String _nameNotEmpty(String name){
    if(name == null || name.length == 0){
      return ('FALTA RELLENAR CAMPO');
    }
  }



 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("REGISTRAR USUARIO"),),
      drawer: NotesDrawer(),
      body: SingleChildScrollView(
              child: Form(
          key: _formkey ,
          child: Column(
            children: [
              SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Icon(Icons.person_add , size: 100,color: Colors.yellow,),
                  ),
                  
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(70)
                  ),
                ),
              ),

              //aqui vamos refactorizar para  dejar el emain y la contraseña como un widget que podamos reutilizar despues


              LoginWidget(onChangeField: onChangeField, userCredentials: _user,), //le pasamos solo en nombre de la funcion no la llamada
               ListTile(
                    leading: Icon(Icons.person_outline),
                    title: TextFormField(
                      keyboardType: TextInputType.name,
                      textInputAction: TextInputAction.next,
                      decoration: InputDecoration(
                        hintText: "NOMBRE",
                      ),
                      validator: _nameNotEmpty,
                       onSaved: (newValue) => _user.firstName = newValue,
                       onChanged: onChangeField,

                    ), 
                  ),

                   ListTile(
                    leading: Icon(Icons.person),
                    title: TextFormField(
                      keyboardType: TextInputType.name,
                      textInputAction: TextInputAction.next,
                      decoration: InputDecoration(
                        hintText: "APELLIDOS",
                      ),
                      validator: _nameNotEmpty,
                       onSaved: (newValue) => _user.lastName = newValue,
                       onChanged: onChangeField,

                    ), 
                  ),


              //como estamos dentro de una lista dentro de aqui podemos meter if , y podemos meter bucles.
              //en este caso le estoy diciendo que puedo meter un objeto dentro de una lista si se cumple la condicion de error.
              if(_error)
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text('${registerResponse.errorMessage}'
                ,style:TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  ) ,
                ),
              ),

              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(child: Text("REGISTRAR USUARIO"), onPressed: (){
                    _register();
                  }),
                  RaisedButton(child: Text("CANCELAR"), onPressed: null)

                ],


              )

            ],
          )
          
          ),
      ),
    );
    
  }
}