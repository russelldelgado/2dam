

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Widgets/NotesBackground.dart';
import 'package:flutter_application_1/Widgets/NotesDrawers.dart';
import 'package:flutter_application_1/models/Note.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:flutter_application_1/models/Preferences.dart';
import 'package:flutter_application_1/models/PreferencesViewModel.dart';
import 'package:flutter_application_1/pages/NotesForm.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:scoped_model/scoped_model.dart';

import 'NotesSettings.dart';





class NotesList extends StatelessWidget {
  static final String route = 'notesList';

  @override
  Widget build(BuildContext context) {

    final preferences = Preferences();
    var background = preferences.notesBackground;

    return Scaffold(
      drawer: NotesDrawer(),
      appBar: AppBar(title: Text('Lista De Notas'),
      actions: [
        IconButton(
          icon: Icon(Icons.settings), onPressed: ()=>Navigator.pushNamed(context, NotesSettings.route)
          ,),
          ScopedModelDescendant<NotesViewModel>( builder: (context, child, model) =>  IconButton(icon: Icon(Icons.refresh), onPressed: (){
            model.token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InJ1c3NlbGxAaWVzdmlyZ2VuZGVsY2FybWVuLmNvbSIsImlhdCI6MTYxMTUyODMwMSwiZXhwIjoxNjExNTMxOTAxLCJzdWIiOiIxIn0.CJFN-XJfV0_u2LjZSx4kAoP0P5u-yOiG2MnIdbkXexw';
          })
          ),
      ],
      ),
      body: Stack(
        children: [
          ScopedModelDescendant<PreferencesViewModel>(builder: (context, child, model) => NotesBackground(image:model.background ,),),
          
          _buildFutureNotesListView(context),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: ()=>  Navigator.pushNamed(context, NotesForm.route),
          //rutas con push y pop
         // Navigator.push(context, MaterialPageRoute(builder: (context) => NotesForm()));
         ),
    );
  }

  Widget _buildFutureNotesListView(BuildContext context) {
    
    return ScopedModelDescendant<NotesViewModel>(
            builder: (context, child, model) =>FutureBuilder<List<Note>>(
        future: model.notes,
        builder: (context, snapshot){
          var childWidget;
          switch(snapshot.connectionState){
            case ConnectionState.none:
            case ConnectionState.active:
            case ConnectionState.waiting:
             childWidget =  ListView(children:[ Center(child: CircularProgressIndicator())]);
             break;
            case ConnectionState.done:
                if(snapshot.hasError){
                  childWidget =  ListView(children:[Center(child: Text('ERROR DE CONECCION'),)]);
                }else{
                  if(snapshot.data == null || snapshot.data.length == 0 ){
                    childWidget =  _warningEmptyNoteList();
                  }else{
                    childWidget = _buildNotesList(snapshot.data);
                  }
                }
                 break;
            default:
                childWidget = ListView(children :[ Center(child: Text('TEXTO'))]);
               break;

            }
          return RefreshIndicator(
              onRefresh:  
                model.refres ,//model.notes , //model.api.getNote()
              child: childWidget
              );
        }),
    );
  }

  Widget _buildNotesList(List<Note> notes){
    
    return ListView.builder(
      itemCount: notes.length,
      itemBuilder: ( context ,  index){
        var note = notes[index];
        return Padding(
          padding: const EdgeInsets.only(top: 15 , left: 10 , right: 10),
          child: Slidable( 
            actionPane: SlidableDrawerActionPane(),
            secondaryActions: [
              IconSlideAction(
                caption: 'BORRAR',
                color: Colors.red,
                icon: Icons.delete,
                onTap: () => _deleteNote(note , context),
              ),

            ],
            
                child: Card(
              color: note.getMaterialColor(),
              elevation: 10,
              child: ListTile(
                title: Text(note.titulo) ,
                subtitle: Text(note.contenido),
                onTap: ()async {
                  var msg;
                 var updated =  await Navigator.pushNamed(context, NotesForm.route , arguments: note);
                 if(updated == null){
                   updated = false;
                 }
                 if(updated){ 
                   msg='actualizado correctamente';
                 }else{
                   msg = 'NO SE HA PODIDO EDITAR LA NOTA';

                 }
                   Scaffold.of(context).showSnackBar(SnackBar(content: Text(msg) , duration: Duration(seconds: 10),));

                }  
              ),
            ),
          ),
        );
      },
      );
  }

  Widget _warningEmptyNoteList() {
    return ListView(
      children: [
  Padding(
      padding: const EdgeInsets.only(top: 15 , ),
      child: Card(
        color: Colors.orangeAccent,
        child:ListTile(
          leading: Icon(Icons.warning),
          title: Text('NO HAY NOTAS CREADAS',
          ),
          subtitle: Text('PULSE EL ICONO + PARA CREAR NUEVAS NOTAS'),
        ) ,
      ),
    )
      ],
    );


    
  }

  void _deleteNote(Note note , BuildContext context) async{
    showDialog(
      context: context , 
      builder: (contextDialogo) => 
      AlertDialog( 
        title: Text('ELIMINAR NOTA'), 
        content: Text('ESTAS SEGURO DE BORRAR LA NOTA ${note.titulo}?'),
        actions: [
          FlatButton(
            onPressed: ()=>Navigator.pop(context , false), 
            child: Text('CANCELAR')),
             ScopedModelDescendant<NotesViewModel>(
               builder: (contextDialogo, child, model) =>  FlatButton(
            onPressed: ()async {
              var msg;
               var deleted = await model.deleteNote(note);
               if(deleted){
                 msg = 'ELIMINADO CORRECTAMENTE';
                 
               }else{
                 msg = 'NO SE HA PODIDO ELIMINAR LA NOTA';
               }
               Scaffold.of(context)
                 .showSnackBar(SnackBar(content: 
                 Text(msg) , duration: Duration(seconds: 5),));
                Navigator.pop(contextDialogo , true);
            }, 
            child: Text('ELIMINAR')),
             ),
        ],
        ),
        );
  }
}