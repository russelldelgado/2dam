import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Widgets/NotesDrawers.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:scoped_model/scoped_model.dart';
import '../Widgets/ColorPicker.dart';
import '../models/Note.dart';

import 'NotesList.dart';


//este es un widget sin estado no se repinta y siempre es estatico
class NotesForm extends StatelessWidget {
  //llave global que nos indica el estado del formulario y para poder acceder a el.
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  //creamos este atributo estatico para indicarlo en la ruta de Materialdesign
  static final String route = '/notesForm';
  //instanciamos una nueva nota para crearla.
  Note note = Note();
  //esta es una nota que nos indica si se ha actualizado o no una nota
  Note updateNote;
  //y un atributo que nos indica si es o no actualizada
  bool isEditing =false ;

  //valida que el titulo de la Nota sea correcto es un metodo

    String _validateTitle(String value ){

      if(value == null || value == ''){
        return 'El titulo de la nota es obligatorio';
      }if(value.length < 5){
        return 'el titulo de la nota tiene que tener al menos 5 caracteres';
      }
      
    }

    //guarda el formulario , pasandole un contexto , y dependiendo si el formulario es creado
    //o editado hace un cosa u otra.

    saveForm(BuildContext context) async{
      //esto devuelve true o false segun se validen on no todos los campos
      if(_formkey.currentState.validate()){
        _formkey.currentState.save();
        var updated = true ;
        if(isEditing){
         // updateNote.copyFrom(note);
         updated = await  ScopedModel.of<NotesViewModel>(context , rebuildOnChange: true ,).updateNote(note);

        }else{
         updated = await  ScopedModel.of<NotesViewModel>(context , rebuildOnChange: true ,).addNote(note);
        }
        note = Note();
        Navigator.pop(context ,updated);
      }
    }

  @override
  Widget build(BuildContext context) {
    var arguments = ModalRoute.of(context).settings.arguments;
    if(arguments!=null){
      updateNote = arguments;
      note.id = updateNote.id;
      note.userId = updateNote.userId;
      isEditing = true;
    }
  return Scaffold(
    drawer: NotesDrawer(),
    appBar: AppBar(
      title: Text('BLOCK DE NOTAS')
    ),
    bottomNavigationBar: _buildButtomNavigationBar(context),
    body: _buildForm(context) ,
    
  );
  }

  Padding _buildButtomNavigationBar(BuildContext context) {
    return Padding(
    padding: const EdgeInsets.all(10.0),
    child: Row(
      children: [
        FlatButton(onPressed: (){
          Navigator.pop(context);
        }, child: Text('CANCELAR')),
        FlatButton(onPressed: (){
          saveForm(context);

        }, child: Text('GUARDAR'))
      ],
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
    ),
  );
  }

  Form _buildForm(BuildContext context) {
    return Form(
    key: _formkey,
    child: Column(
      children: [
        ListTile(
          leading: Icon(Icons.title),
          title: TextFormField(
            initialValue: isEditing  ? updateNote.titulo : note.titulo,
            validator: _validateTitle,
            decoration: InputDecoration(
              hintText: 'Titulo de la nota'
            ),
            onSaved:(newValue) => note.titulo = newValue,
          ),
        ),
        ListTile(
          leading: Icon(Icons.content_copy),
          title: TextFormField(
            initialValue: isEditing ? updateNote.contenido : note.contenido,
            maxLines: 6,
            decoration: InputDecoration(
              hintText: 'Descripcion de la nota' ,
            ),
            onSaved: (newValue)=> note.contenido = newValue,
          ),
        ),
        ListTile(
          leading: Icon(Icons.palette),
          title: ColorPicker(
            onChange : (color){
              note.color = color;
              FocusScope.of(context).unfocus();
            },
            //color: note.color
            initialValue: isEditing ? updateNote.color : note.color,
          ),
           ),
        

      ],
    ));
  }
}
