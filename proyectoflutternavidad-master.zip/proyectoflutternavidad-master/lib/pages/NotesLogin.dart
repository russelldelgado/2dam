

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_application_1/Widgets/LoginWidget.dart';
import 'package:flutter_application_1/Widgets/NotesDrawers.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:flutter_application_1/models/User.dart';
import 'package:flutter_application_1/models/UserCredentials.dart';
import 'package:flutter_application_1/pages/NotesList.dart';
import 'package:flutter_application_1/pages/NotesRegister.dart';
import 'package:scoped_model/scoped_model.dart';

class NotesLogin extends StatefulWidget {
  static final String route = "/notesLogin";

  NotesLogin({Key key}) : super(key: key);

  @override
  _NotesLoginState createState() => _NotesLoginState();
}

class _NotesLoginState extends State<NotesLogin> {
  //esta llave nos permite acceder a este formulario para hacer todo lo que tengamos que hacer con el  .
  final GlobalKey<FormState>  _formkey = GlobalKey<FormState>(); 
  UserCredentials _credentials = UserCredentials();
  var _error = false;


  _login()async{
    if(_formkey.currentState.validate()){
      _formkey.currentState.save();

//con esto ya tenemos la instancia de scope view model con el patro scopeModel y asi poder llamar al metodo login
//este dato lo almacenamos ne una variable logged para ver si el usuario ha hecho login o no , pero como es  un future  
//tenemos que esperar la respuesta y luego ya devolverla.
      var logged = await ScopedModel.of<NotesViewModel>(context , rebuildOnChange: true ,).login(_credentials);
      if(logged){
        Navigator.of(context).pushReplacementNamed (NotesList.route);
      }else{
        _error = true;
      }
      setState(() {
        
      });
    }
  }

  onChangeField(String value){
    setState(() {
      _error = false;
    });
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("INICIAR SECION"),),
      drawer: NotesDrawer(),
      body: SingleChildScrollView(
              child: Form(
          key: _formkey ,
          child: Column(
            children: [
              SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(Icons.person , size: 100,color: Colors.yellow,),
                  ),
                  
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(70)
                  ),
                ),
              ),

              //aqui vamos refactorizar para  dejar el emain y la contraseña como un widget que podamos reutilizar despues


              LoginWidget(onChangeField: onChangeField, userCredentials: _credentials,), //le pasamos solo en nombre de la funcion no la llamada



              //como estamos dentro de una lista dentro de aqui podemos meter if , y podemos meter bucles.
              //en este caso le estoy diciendo que puedo meter un objeto dentro de una lista si se cumple la condicion de error.
              if(_error)
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text("usuario o contraseña incorrecta"
                ,style:TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  ) ,
                ),
              ),

              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(child: Text("INICIAR SECION"), onPressed: (){
                    _login();
                  }),
                  RaisedButton(child: Text("REGISTRARSE"), onPressed: (){
                    Navigator.pushNamed(context, NotesRegister.route);
                  })

                ],


              )

            ],
          )
          
          ),
      ),
    );
    
  }
}