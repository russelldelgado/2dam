
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/Preferences.dart';
import 'package:flutter_application_1/models/PreferencesViewModel.dart';
import 'package:scoped_model/scoped_model.dart';

class NotesSettings extends StatefulWidget {
  static final  String route = '/NotesSettings';  

  @override
  _NotesSettingsState createState() => _NotesSettingsState();
}

class _NotesSettingsState extends State<NotesSettings> {
  String _background ;
    final _preferences = Preferences();

  _onChange(String value){
     setState(() {
    _background = value;
    });
  }

  @override
  void initState() {
    super.initState();
    _background = _preferences.notesBackground;

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PREFERENCIAS'),
        ),
      body:buildColumnSettings() ,
      bottomNavigationBar: buildButtons(),
    );
  }


  Column buildColumnSettings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text('SELECCIONE UN FONDO' , style: TextStyle( fontSize: 20),),
        ),

        RadioListTile(
          title: Container(
            width: 75,
            height: 100,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/images1.jpg'),
                fit: BoxFit.contain
              ) ,
            ),
          ),
          value: 'assets/images/images1.jpg', 
          groupValue: _background, 
          onChanged: _onChange),
          RadioListTile(
          title: Container(
            width: 75,
            height: 100,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/images2.jpg'),
                fit: BoxFit.contain
              ) ,
            ),
          ),
          value: 'assets/images/images2.jpg', 
          groupValue: _background, 
          onChanged: _onChange),
      ],
    );
  }

  Padding buildButtons() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
        FlatButton(onPressed: 
        ()=>Navigator.pop(context), child: Text('CANCELAR')
        ),
        ScopedModelDescendant<PreferencesViewModel>(
          builder: (context, child, model) =>  FlatButton(onPressed: (){
              model.background = _background;
              //_preferences.notesBackground = _background;
              Navigator.pop(context);
          }, child: Text('GUARDAR')),
        ),
      ],
      
      ),
    );
  }

}