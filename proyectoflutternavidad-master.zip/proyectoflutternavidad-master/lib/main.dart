import 'package:flutter/material.dart';
import 'package:flutter_application_1/app/NoteAppe.dart';
import 'models/Preferences.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  var preferencias = Preferences();
  await preferencias.initPreferences();
  runApp(NotesApp());
}


