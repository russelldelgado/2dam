

import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/UserCredentials.dart';

class LoginWidget extends StatefulWidget {
  
  UserCredentials userCredentials;
  Function(String) onChangeField; // esto es un atributo mas de dart , pero en dar las funciones se pueden guardar en variables. y tiene un parametro de tipo String
  
  LoginWidget({this.onChangeField , this.userCredentials});

  @override
  _LoginWidgetState createState() => _LoginWidgetState();
}



class _LoginWidgetState extends State<LoginWidget> {
  var _showPassword = false ;

  
  //estos metodos van a ser creados para validar el usuario y la contraseña que coloques

  String _emailValidator(String email){
    final emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^-`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email);

    if(!emailValid){
      return 'El email insertado no es valido';
    }
  }
  String _passwordValidator(String password){
      if(password.length < 3){
        return "La contraseña no puede tener menos de 3 caracteres";
      }
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
                    leading: Icon(Icons.email),
                    title: TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      decoration: InputDecoration(
                        hintText: "CORREO ELECTRONICO",
                      ),
                      validator: _emailValidator,
                       onSaved: (newValue) => widget.userCredentials.email = newValue,
                       onChanged: widget.onChangeField,
                      initialValue: "russell@iesvirgendelcarmen.com",


                    ), 
                  ),
                   ListTile(
                leading: Icon(Icons.security),
                title: TextFormField(
                  initialValue: "russell",
                  obscureText: !_showPassword,
                  decoration: InputDecoration(
                    hintText: "PASSWORD",
                    suffixIcon: IconButton(
                      icon: Icon(_showPassword ? Icons.visibility_off: Icons.visibility),
                      onPressed: () {
                        
                        setState(() {
                          _showPassword = !_showPassword;
                        });
                      } ,
                    )
                    
                  ),
                  validator: _passwordValidator,
                  onSaved: (newValue) => widget.userCredentials.password = newValue,
                   onChanged: widget.onChangeField,

                ),
              )
      ],
    );
             
  }
}