
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:flutter_application_1/pages/NotesForm.dart';
import 'package:flutter_application_1/pages/NotesList.dart';
import 'package:flutter_application_1/pages/NotesLogin.dart';
import 'package:flutter_application_1/pages/NotesSettings.dart';
import 'package:scoped_model/scoped_model.dart';

class NotesDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    //ESTO ES UNA FUNCION QUE ME RETORNA UN DRAWERS CON EL ESCOPE MODEL LO QUE HAGO ES ACCEDER AL ESTADO DE MI APLICACION 
    return ScopedModelDescendant<NotesViewModel>(
      builder: (context, child, model) =>  Drawer(
        child: ListView(
          children: [
            _buildDrawerHeader(model),

            ListTile(
              leading: Icon(Icons.login) ,
              title: Text('INICIAR SESION'),
              onTap: (){
                Navigator.pop(context);
                //si la ruta altual es distinta a la ruta de login
                if( ModalRoute.of(context).settings.name != NotesLogin.route){
                  //este ultimo false hace que se elimine todo lo anterior
                 Navigator.pushNamedAndRemoveUntil(context, NotesLogin.route, (route) => false);
                  }
              },
            ),

            if(model.logged)
            ListTile(
              leading: Icon(Icons.list) ,
              title: Text('VER MIS NOTAS'),
              onTap: (){
                Navigator.pop(context);
                if( ModalRoute.of(context).settings.name != NotesList.route){
                  //este ultimo false hace que se elimine todo lo anterior
                 Navigator.pushNamedAndRemoveUntil(context, NotesList.route, (route) => false);
                  //Navigator.pop(context);
                  }
              },
            ),

            if(model.logged)
            ListTile(
              leading: Icon(Icons.add) ,
              title: Text('NUEVA NOTA '),
              onTap: () {
                  Navigator.pop(context);
                 if( ModalRoute.of(context).settings.name != NotesForm.route){
                    Navigator.pushNamed(context, NotesForm.route);
                  }
              },
            ),
             ListTile(
              leading: Icon(Icons.settings) ,
              title: Text('PREFERENCIAS'),
              onTap: () async{
                  Navigator.pop(context);
                 if( ModalRoute.of(context).settings.name != NotesSettings.route ){
                    Navigator.pushNamed(context, NotesSettings.route);
                   
                  }
              },
            ),
            if(model.logged)
            ListTile(
              leading: Icon(Icons.logout) ,
              title: Text('CERRAR SESION'),
              onTap: (){
                Navigator.pop(context);
                 model.logout();
                 Navigator.pushNamedAndRemoveUntil(context, NotesLogin.route, (route) => false);
              },
            ),

          ],
        ),

        
      ),
    );
    
  }

  Widget _buildDrawerHeader(NotesViewModel model) {
    if(model.logged){

      return UserAccountsDrawerHeader(
        accountName: Text((model.user.fullName != null) ? model.user.fullName : "nombre Nulo" ), 
        accountEmail: Text(model.user.email),
        currentAccountPicture: CircleAvatar(
          backgroundImage:AssetImage('assets/images/myAvatar.png') ,
        )
        );
        
    }
    else{
    return DrawerHeader(
            child: Stack(
                    children: [
                      Center(
                      child: Text('MIS NOTAS' , style: TextStyle( 
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                      ),),
                      ),
                    Container(
                      child: Text('SESION CERRADA'),
                      alignment: Alignment.bottomLeft,
                    ),
                    ]
            ),
              decoration:BoxDecoration(
                color: Colors.yellow
              ) ,
              );
  }}
}