
import 'package:flutter/cupertino.dart';
import 'package:flutter_application_1/models/Note.dart';

class ColorPicker extends StatefulWidget {
  void Function(NoteColor) onChange;
  NoteColor initialValue = NoteColor.Blue;
  ColorPicker({this.onChange , this.initialValue}){
  }

  @override
  _colorPickerState createState() => _colorPickerState();
}

class _colorPickerState extends State<ColorPicker> {

  NoteColor _selecterColor;
    
  @override
  Widget build(BuildContext context) {
    if(_selecterColor == null){
      _selecterColor = widget.initialValue;
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: 
    
      NoteColor.values.map((NoteColor enumColor) {
        return GestureDetector(
          onTap: (){
            setState(() {
            _selecterColor = enumColor;
            });
            widget.onChange( _selecterColor);

          },
             child: Container(
            width:  _selecterColor == enumColor ? 45 : 35 ,
            height:  _selecterColor == enumColor ? 45 : 35,
            decoration: BoxDecoration(
              color: Note.getMaterialEnunColor(enumColor),
              borderRadius: BorderRadius.circular(50)
            ),
          ),
        );
      }).toList()
     ,);
  }
}