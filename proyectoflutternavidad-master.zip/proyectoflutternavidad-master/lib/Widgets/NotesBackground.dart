

import 'package:flutter/cupertino.dart';

class NotesBackground extends StatelessWidget {

  String image ;

  NotesBackground({this.image = 'assets/images/images1.jpg'});

  @override
  Widget build(BuildContext context) {
   return Container(
     width: double.infinity,
     height: double.infinity,
     decoration: BoxDecoration(
       image: DecorationImage(
         image: AssetImage(image,
         ),
         fit: BoxFit.fill,
       )
     ),
   );
  }
}