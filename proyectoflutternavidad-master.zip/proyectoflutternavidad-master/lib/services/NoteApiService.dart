import 'package:flutter_application_1/models/Note.dart';
import 'package:flutter_application_1/services/ApiService.dart';
import 'package:http/http.dart' as http;
import 'package:jwt_decoder/jwt_decoder.dart';

//vamos a implementar los distintos metodos de acceso al badkend
//aquí metemos los demotos para eliminar , crear , actualizar y traerme todas las notas del backend


//connecting to VM service at ws://127.0.0.0.1:50243/NSOKTfrObok=/ws <<< esto sale al conectar por si vale para un error futuro
class NotesApiServices extends ApiService{

 // static final  baseUrl = "http://192.168.0.12:3000";
  //static final  baseUrl = "http://172.24.240.1:3000";

  //172.24.240.1 esto da error igual
  //static final ruta = "notes/"; http://192.168.0.12:3000/

//estamos refactorizando para hacer una autenticacion , ahora bien lo que podriamos hacer es pasarle a cada metodo lo que es el token
//o mas bien pasarselo por el constructor
  NotesApiServices(String token) : super(token : token);


//creamos un metodo para traernos datos del token


//al ser datos que vamos a pedir y a enviar a un servidor hace falta que sea future ya que va a ser asyncrono y va a tardar en recibir una respuesta
  Future<List<Note>> getNote() async {
    final respuesta = await http.get("${ApiService.baseUrl}/notes" , headers: {"Authorization" : "Bearer $token"});
    if(respuesta.statusCode==200){

    int  filterId= getUserIdFromToken();
     return Note.notesFromJson(respuesta.body , filterId);
    }else{
      print(respuesta.statusCode);
    }
  }


//metodo para crear una nueva nota , para ello le tenemos que pasar una nota como tal pero en formato json
//es future porque tiene que conectarse a la base de dtos y luego indicarnos si se creo o no la nota.
//segun la respuesta hacemos una cosa u otra.
  Future<bool> addNote(Note note) async{

    int filterId = getUserIdFromToken();
    note.userId = filterId;

    try {

       final response = await http
                .post("${ApiService.baseUrl}/notes" , headers: {"Content-type" : "application/json" , "Authorization" : "Bearer $token"} , body: note.toJson());
  if (response.statusCode == 201){

    //creamos en la clase nota un metodo estatico que nos devuelva la nota creada en el body
    //pero esta vez con el id , ya que si devuelvo la nota de arriba me la devolveria sin el id.
    
    return true;
      //return Note.fromJson(response.body);
    }
      
    } catch (e) {
      return false ;
    }
   
   return false;

  }

  Future<bool> removeNote(Note note)async {
    //como puede que haya un error al no tener coneccion nos devolveria una execcion asique vamos a meter
    //dentro de un try cath todo para atrapar ese posible error

    try {
       final response = await http.delete("${ApiService.baseUrl}/notes/${note.id}" , headers: {"Content-type" : "application/json" , "Authorization" : "Bearer $token"});
      if(response.statusCode == 200){
        return true;
      }else{
        return false ;
      }
      
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateNote(Note note ) async{

    try {
      final response = await http
                            .put("${ApiService.baseUrl}/notes/${note.id}" ,
                              headers: {"Content-type" : "application/json" , "Authorization" : "Bearer $token"} , 
                              body: note.toJson());
      
      if(response.statusCode == 200){
        return true;
      }else{
        return false;
      }
    } catch (e) {
      return false ;
    }
    

  }



}