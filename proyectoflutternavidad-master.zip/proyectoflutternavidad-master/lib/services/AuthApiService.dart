

import 'dart:convert';

import 'package:flutter_application_1/Responses/RegisterResponses.dart';
import 'package:flutter_application_1/models/User.dart';
import 'package:flutter_application_1/models/UserCredentials.dart';
import 'package:flutter_application_1/services/ApiService.dart';
import 'package:http/http.dart' as http;
import 'package:jwt_decoder/jwt_decoder.dart';

//que necesitamos para hacer login , para eso lo vemos en el login
//1-necesitamos hacer el metodo post
//en la cabecera tenemos que poner que vamos a mandar datos en formato json. contenttype -- application/json
//tenemos que mandar un usuario y un acontraseña
//nos devuelve un joson con una propiedad accessToken y un token de validación del usuario actual para ese correo.



class AuthApiService extends ApiService{

  AuthApiService({String token = ""}) : super(token: token);

  

Future<String> login(UserCredentials credentials) async{
  final response  = await http.post(
    "${ApiService.baseUrl}/login" , 
    headers: {"Content-type" : "application/json"} , 
    body: credentials.tojson()
    );

    if(response.statusCode == 200){
      final body  = jsonDecode(response.body);
      //como no le pongo final estoy modificando la instancia token del padre y ya la retorno tambien , es decir no creo una nueva instancia.
      token = body['accessToken'];
      return token;
    }

}

//implementamos un metodo que nos diga si el token es valido o no es valido;
//lo hacemos  con el token que recibimos del constructor por eso no le pasamos ningun token ni nada.

  bool isTokenValid(){
    return !JwtDecoder.isExpired(token);
  }


  Future<User> getUser() async{
      //primero necesitamos el token y luego el id del usuario para poder acceder porque hay que usarlo en la url del endpoint
      //par obtener un usuario si necesitamos el token , podemos usar el que tenemos en la clase.

      //como esta clase extiende de apiservice y api service nos devuelve el id del token entonces puedo llamar a su metodo que es de esta clase
      //y usarlo para almacenar el id del token.
      final idUser = getUserIdFromToken();
      final response  = await http.get("${ApiService.baseUrl}/users/$idUser" , headers: {'Authorization':'Bearer $token'});
      print(response.body);
    //si la coneccion es correcta tengo que devolver una instancia del usuario y ese metodo ya lo tengo implementado.
    if(response.statusCode == 200){
        return User.userjson(response.body);
    }

  }

  //METODO QUE CONTROLARA EL REGISTRO DEL USUARIO , PARA ESTO HEMOS CREADO UNA CLASE QUE CONTROLE LOS DIFERENTES TIPOS DE ERRORES QUE PUEDEN OCURRIR Y SEGUN
  //EL TIPO DE ERROR NOS DEVUELVA UNA COSA U OTRA.

  Future<RegisterResponse> register(User user) async{
        try {
           final response  = await http.post("${ApiService.baseUrl}/register" ,headers: {"Content-type" : "application/json"} ,body: user.tojson()
        );
        if(response.statusCode == 201){
          final body  = jsonDecode(response.body);
          //como no le pongo final estoy modificando la instancia token del padre y ya la retorno tambien , es decir no creo una nueva instancia.
          token = body['accessToken'];
          return RegisterResponse.success(token, 'USUARIO REGISTRADO CON EXITO');
        }else if(response.statusCode == 400){
          
          String error = response.body;
       
          switch(error){
            case '"Email already exists"':
             return RegisterResponse.userAlreadyExist("EL USUARIO YA EXISTE");
            case '"Password is too short"':
              return RegisterResponse.passwordShort("CONTRASEÑA DEMASIADO CORTA");
            case '"Email format is invalid"':
              return RegisterResponse.emailInvalid("CORREO ELECTRONICO NO VALIDO");
            case '"Email and password are required"':
              return RegisterResponse.emailPasswordRequired("EMAIL Y CONTRASEÑA OBLIGATORIOS");
            default:
              return RegisterResponse.unknowError("ERROR DESCONOCIDO");
          }
        }
         return RegisterResponse.unknowError("ERROR DESCONOCIDO");
        } catch (e) {
        //si no hay internet nos devulve otro tipo de error , una exeption , o que el servidor este caido

          print("error de algo mas coneccion o algo asi");
          return RegisterResponse.networkError("ERROR DE CONECCION");
          }
  } 

}