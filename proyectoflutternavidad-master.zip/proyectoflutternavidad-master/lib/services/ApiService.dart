
import 'package:jwt_decoder/jwt_decoder.dart';

//todos los metodos que vayamos a necesitar en las otras clases los vamos a traer aqui para utilizarlos solo una vez en todo el codigo
//y si tenemos que hacer cambios sean fáciles de implementar y no muy complicados.
//haremos herencia , es decir que esta sea la clase padre de las otras dos

//ponemos esta clase abstracta para que no se pueda instanciar de ella nada. pero si de sus clases hijas.
abstract class ApiService{

    static final  baseUrl = "http://192.168.0.12:3000";
    //static final  baseUrl = "http://localhost:3000";
    String token;

    ApiService({this.token = ""});


        
    int getUserIdFromToken(){
      
      //este es el id del token 
        final mapJwt =  JwtDecoder.decode(token);
        int filterId = int.parse(mapJwt["sub"]);

        return filterId;
    }

}