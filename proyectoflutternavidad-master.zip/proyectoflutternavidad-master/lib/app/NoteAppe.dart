


import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/NotesViewModel.dart';
import 'package:flutter_application_1/models/PreferencesViewModel.dart';
import 'package:flutter_application_1/pages/NotesForm.dart';
import 'package:flutter_application_1/pages/NotesList.dart';
import 'package:flutter_application_1/pages/NotesLogin.dart';
import 'package:flutter_application_1/pages/NotesRegister.dart';
import 'package:flutter_application_1/pages/NotesSettings.dart';
import 'package:scoped_model/scoped_model.dart';

class NotesApp extends StatelessWidget{
//como necesitamos el metodo para ver si un token ha expirado o no creamos un instancia de la calse 
  NotesViewModel notesViewModel ;

  NotesApp(){
  //EN EL CONSTRUCTOR INICIALIZAMOS EL NOTES VIEW MODEL PARA QUE SE HAGA SOLO UNA VEZ
   notesViewModel = NotesViewModel();
  }

  @override
  Widget build(BuildContext context) {
    

   return ScopedModel(
     model: notesViewModel,
        child: ScopedModel(
        model: PreferencesViewModel() ,
          child: ScopedModelDescendant<NotesViewModel>(builder:(context, child, model) {  
    //aqui la instanciamos , en el propio metodo build , o en el constructor
            var initialRouter = NotesLogin.route;
            if(notesViewModel.isTokenValid()){
            initialRouter = NotesList.route;
            }

            return MaterialApp(
         debugShowCheckedModeBanner: false,
         key: UniqueKey(),
         routes: {
             NotesList.route :(context) => NotesList(), 
             NotesForm.route :(context) => NotesForm(),
             NotesSettings.route : (context)=>NotesSettings(),
             NotesLogin.route : (context)=>NotesLogin(),
             NotesRegister.route : (context)=>NotesRegister(),
         },
       title: 'BLOG DE NOTAS',
       theme: ThemeData(
       primaryColor: Colors.yellow , 
       accentColor: Colors.orange
       ),
       initialRoute:  initialRouter,
       );}
          ),
     ),
   );
  }

  
}
