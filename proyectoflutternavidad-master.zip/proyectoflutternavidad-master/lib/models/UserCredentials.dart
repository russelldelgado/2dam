
import 'dart:convert';

import 'package:flutter/material.dart';

class UserCredentials {

String email;
String password;

UserCredentials({@required this.email , this.password});


 //al hacer login necesitamos enviar un json  con el email y la password para ello creamos un metodo que se encargue de hacer esto.
  //en este caso tengo datos de usuarios y tengo que generar un json
String tojson(){
  final loginData = {"email" : email , "password" : password};
  return json.encode(loginData); 
}

}