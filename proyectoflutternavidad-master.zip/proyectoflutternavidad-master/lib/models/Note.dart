import 'dart:convert';
import 'package:flutter/Material.dart';

//este es el enun de los colores que tiene mi app mis notas

enum NoteColor{
Red , Blue ,Green , Yello , Orange
}


//este es un metodo que le metetos dos parametros el primero un iterable una lista o algo asi
//y el segundo un string , la lista ira recorriendo el iterable y le asignara un valor que le pasemos
//con esto convertimos nuestro enum a un string

T enumFromString<T>(Iterable<T> values , String value){
  return values.firstWhere((color) => color.toString() == value , orElse: () => null,);
}


//esta es nuestra clase principal en la cual tenemos un id , un titulo de la nota , 
//un contenido de la nota y un color de nuestra nota
class Note {

  //atributos de nuestra clase
  int id ;
  String titulo ;
  String contenido ;
  NoteColor color ;
  int userId;


//metodo estatico para asignar a cada enun de color un color 
  static final NoteColorMap = <NoteColor , Color>{
    NoteColor.Red: Colors.red,
    NoteColor.Blue : Colors.blue,
    NoteColor.Green: Colors.green ,
    NoteColor.Yello :Colors.yellow ,
    NoteColor.Orange : Colors.orange
  };

  //devuelve un color de materialdesign gracias al metodo que hemos creado anteriormente 

  Color getMaterialColor(){
    return NoteColorMap[color];
  }

  //nos devuelve un color del unun pero le tenemos que pasar un color de tipo color

  static Color getMaterialEnunColor(NoteColor color){
      return NoteColorMap[color];
  }

  //constructor sugar de nuestras notas tienen un valor por defectoy donde pone required
    //quiere decir que si o si le tenemos que pasar ese valor 

  Note({this.id ,
   @required this.titulo  = '',
  this.contenido = '' ,
  @required this.color = NoteColor.Blue ,
  this.userId,
  });


  //metodo que nos devuelve una nota desde un mapa que tengamos 

  static Note fromMap(Map<String , dynamic> note)=> 
  Note(id:note['id'] , 
  titulo: note['titulo'] ,
   contenido: note['contenido'] ,
    color: enumFromString(NoteColor.values , note['color']),
    userId: note["userId"] );


  // nos devuelve una lista de notas de un formato json
  //con el filterId nos quedaremos solo con las notas del usuario que haya hecho login
  static List<Note> notesFromJson(String jsonData , int filterId){
    final data =  json.decode(jsonData);
    final notes =  List<Note>.from(data.map((note)=> Note.fromMap(note)));
    var filterNotes = <Note>[];
    notes.forEach((note) {
      if(note.userId == filterId){
        filterNotes.add(note);
      }
    });
    return filterNotes;

  }

  //convertimos en un mapa los datos de nuestras notas
  Map<String  , dynamic> toMap(){
    return {
      "id" : id,
      "titulo" : titulo,
      "contenido" :contenido,
       "color" : color.toString() ,
       "userId" : userId,
        };
  }

  //convertimos a json nuestra clase 

  String  toJson(){
    //convierte un objeto(con to map) a json.
   return jsonEncode(toMap());
  }

  //nos sirve para copiar una nota desde otra nota.

  //este metodo nos devuelve una nota dado un json

  static Note fromJson(String jsonData){
    final data = json.decode(jsonData);
    return fromMap(data);
  }
  
 void copyFrom(Note otherNote){
   id = otherNote.id;
   titulo = otherNote.titulo;
   contenido = otherNote.contenido;
   color = otherNote.color;
   userId = otherNote.userId;
   
 }

}


