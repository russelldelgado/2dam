
import 'package:flutter_application_1/Responses/RegisterResponses.dart';
import 'package:flutter_application_1/models/Note.dart';
import 'package:flutter_application_1/models/Preferences.dart';
import 'package:flutter_application_1/models/User.dart';
import 'package:flutter_application_1/models/UserCredentials.dart';
import 'package:flutter_application_1/services/AuthApiService.dart';
import 'package:flutter_application_1/services/NoteApiService.dart';
import 'package:scoped_model/scoped_model.dart';

//esta clase esta hecha para que automaticamente se nos actualice la lista de notas llamando al modelo.
class NotesViewModel extends Model{

//tengo que instanciar los objetos para conectarme a la base de datos desde la clase coneccion
NotesApiServices api ;
//instanciamos una api para hacer login y obtener los datos de usuario
AuthApiService authhapi ;
//creamos una variable booleana logged para ver si ha hecho bien o no el login del usuario
bool logged = false ;
//como vamos a guardar el token en las preferencias lo que tenemos que hacer es crear una instancia de preferencias , al ser una instancia
//singleton lo que pasa es que estemos donde estemos siempre nos devolvera la misma instancia.
Preferences _preferences = Preferences();
//creamos una variable de tipo user para almacenar los datos de usuario y no tener que hacer una coneccion a la api cada vez que abramos el drawers
User user;


NotesViewModel(){

//esto no vale para nada solo para hacer pruebas con falsos token y ver que no se guarda la instancia
  if(isTokenValid()){
    api = NotesApiServices(_preferences.token);
    authhapi= AuthApiService(token: _preferences.token);
    //una vez sabemos que hemos iniciado sesion con un usuairo llamamos a la instancia que se trae los datos del usuario y los guardamos
    //en la variable local user;

    getUser();
  //el usuario esta logeado 
    logged = true;
  }else{
    authhapi = AuthApiService();
  }

}


//aquí creamos un metodo que se conecta a nuestra base dedatos y nos devuleve las notas pero futuras lista
//de notas
Future<List<Note>> get notes{

  if(isTokenValid()){
  final notes = api.getNote();
  return notes;}
  else{
    logout();
    notifyListeners();
  }
}


//metodo para refrescar la ventana que sera utilizado cuando traigamos notas.
 Future<void> refres() async => notifyListeners();
  
  
//metodo para añadir una nota deberemos convertilo en un future addnote ya que tardara un poco en crearse una
//nota y no sera muy en el instante ,  el notifylisteners valepara refrescar las ventanas despues de añadir
//una nota y que se repinte el arbol dewidgets

addNote(Note note)async{
  //lo hacemos de tipo async y await para que esperemos que la nota se inserte correctamente y despues de 
  //que haya sido ensertada entonces refrezcamos lo que es la pantalla.
  
  var added =   await api.addNote(note);
  if (added)
  notifyListeners();
  return added;
}

Future<bool> deleteNote(Note note)async{
   var deleted = await api.removeNote(note);
   if(deleted){
    notifyListeners();}
   return deleted;
}

 Future<bool> updateNote(Note note )async{
  var update = await api.updateNote(note);
  
  if(update){
    notifyListeners();
  }
  return update;

}
//retornamos un booleano que nos diga si el usuario ha hecho login correctamente o no 
//le tenemos que pasar las credenciales de usuario con laas que queremos hacer login
//

Future<bool> login(UserCredentials credentials)async{
  final token = await authhapi.login(credentials);
 return _setLoginStatus(token);

}


  bool _setLoginStatus(String token){

     if(token!=null){
      logged = true;
      api = NotesApiServices(token);
      //si el usuario se logea bien nos traemos los datos del usuario
      getUser();
//si el token fuera correcto lo que tenemos que hacer es persistir el token para que la proxima vez que me meta a la app 
//no tenga que volver a iniciar sesion , para esto modificamos las preferencias y creamos una clave para almacenar un token seteartlo y devlverlo

  _preferences.token = token;
  return true;
  }else{
    logged = false;
    _preferences.token = null;
    return false;
  }

  }

//IMPLEMENTAMOS EL REGISTRO DEL USUARIO;

 Future<RegisterResponse> register(User user)async{
   final response = await  authhapi.register(user);

    if(response.status == RegisterResponseStatus.SUCCESS){
      //si el registro ha sido exitoso actualizo el estado de mi aplicación , en el NvModel para ver si no encontramos logeado ,
      //si el token esta persistido o no , etc...
      _setLoginStatus(response.token);
    }

    return response;
  }


//creamos un metodo que comprueve si el token esta persistido o no o si ha expirado

bool isTokenValid(){
  final token = _preferences.token;
  
  //si el token es distinto de null y de cadena vacia quiere decir que tenemos un inicio de seción anterior , pero claro
  //ese token puede que ya haya expirado asique tenemos que comprobar la fecha de caducidad con el metodo que hemos creado antes
  //en la clase de AuthApiService
  
  if(token!=null && token != '' ){
    //instanciamos la clase , le pasamos el token que es obligatoria y llamamos a la clase que necesitamos para comprobar eso.
    //este metodo de abajo me retorna true si el token ha inspirado y si no me retorna flase.
     return AuthApiService(token: token).isTokenValid();
  }
  return false;
}

//metodo que nos trae los datos del usuario para guardarlos en una variable local y no cada vez que abramos el menu haga la llamada.
  getUser()async{
  user =  await authhapi.getUser();
  }

//metodo para cerrar secion con el usuario.

  logout(){
    logged = false ;
    _preferences.token = null;
    
  }

  set token(String token){
   _preferences.token = token;
   api = NotesApiServices(token);
   authhapi = AuthApiService(token: token);
  }



}