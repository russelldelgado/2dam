
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/UserCredentials.dart';

class User extends UserCredentials{

  int id;
  
  String firstName;
  String lastName;

  User({this.id , @required email , password , this.firstName , this.lastName}) : super(email: email , password: password);

  //creamos un metodo full name que me retorne el nombre completo del usuario

 String get fullName{
    return "$firstName $lastName";
  }

//@override
String tojson(){
  final loginData = {"email" : email , "password" : password , "firstname" : firstName , "lastname" : lastName};
  return json.encode(loginData); 
}
 


  //tambien necesito descargarme todos los datos del usuario  eso se hace en la ruta localhost:3000/600/users/id
  //es decir tambien necesito un metodo que dado un json que recogo me genere un usuario.
  //en este caso dado un json que me descargo me genere una instancia

  static userjson(String userJson){
    final userMap = jsonDecode(userJson);

    return User(
      id: userMap["id"],
      email: userMap["email"],
      //password: userMap["password"],
      firstName: userMap["firstname"],
      lastName: userMap["lastname"]
      );

  }


}