
import 'package:flutter_application_1/models/Preferences.dart';
import 'package:scoped_model/scoped_model.dart';

class PreferencesViewModel extends Model{
  Preferences _preferences = Preferences();

  set background(String background){
    _preferences.notesBackground = background;
    //solo llamamos a notify cuando se hagan cambios si no nada
  //importante de scope model
  notifyListeners();
  }

  get background{
    return _preferences.notesBackground;
  }

}