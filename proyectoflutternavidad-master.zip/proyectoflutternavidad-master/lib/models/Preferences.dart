//con esto vamos a hacer un patron singleton


//nos vale para crear una unica instancia en toda la aplicacion de esta clase , que no tengamos distinta instancia de la clase preferencia si no una sola.
//al ser una única instancia nos va a servir para poder llamar a esta instancia desde cualquier sitio de la aplicacion.
//

import 'package:flutter_application_1/Widgets/NotesBackground.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Preferences {
  //dentro de la misma clase preferencias hay una instancia de preferencia
  //con esto decimos que vamos a tener solo una instancia de las preferencias y se crea la primera vez que se llama al constructor de preferencias .
  static final Preferences _instance = Preferences._internal();
  //creamos una key para el fondo ,  y a al hora de setearlo o de devolverlo tenemos que usar esta key
  static final String backgroundKey = 'notes_background';
  //creamos una key para el token , es decir con el set asignamos un valor a esta llave , y con el _preference.getString traemos el valor de esta llave.
  static final String tokenKey ="notes_token";
  SharedPreferences _preferences;  

//un constructor de tipo factoria quiere decir que este constructor te puede retornar una instancia de otro objeto distinto 
//cuando llamemos al construtor preferences , lo que haremos siempre sera retornar una instancia de preferencias que es estatica , eso queire decir
//que siempre sera la misma instancia.
  factory Preferences(){
    return _instance;
  }

  //se puede mejorar llamando a un constructor privado
  //este constructor lo unico que hace es crear una instancia de preferencias
  //se llamaria primero a este constructor y se almacena de manera statica arriba en _instance , eso quiere decir que solo habrá una copia.


  Preferences._internal();

//es obligatorio crear este metodo para inicializar las preferencias , 
//creamos una instancia de sharedpreference y la guardamos en la variable de preferencias
//luego lo instanciamos nada mas hacer el main para que se cree una sola vez
//lo tenemos en persistencia local en el dispositivo.


  initPreferences() async{
     _preferences= await SharedPreferences.getInstance();
  }

  //estos son los metodos getter y setter que me devolveran el color de fondo o lo cambiaran


//le decimos que en las preferencias almacenadas en la variable backgroundkey (notes_background) vamos a almacenar un valor de fondo que es de tipo string

  set notesBackground(String background){
    _preferences.setString( backgroundKey, background);
  }

//nos traemos de las preferencias lo que tengamos guardado en la llave backgrounkey , si algo da error nos traemos la imagen por defecto 
 String get notesBackground{
    return _preferences.getString(backgroundKey) ?? 'assets/images/images1.jpg';
  }

//este set token lo hacemos para guardar el token
//es decir en _preferences metemos dos valores , el primero es el token key que es la clave que vamos a guardar y el segundo es el valor que
//le pasmos por el parametro que en este caso es el token
  set token(String token){
    _preferences.setString(tokenKey, token);
  }

  //indicamos que queremos recuperar un valor shared preferences en este caso el valor que queremos recuperar es el token
  //resumen en el shared preferences guardamos el token.
 String get token{
    return _preferences.getString(tokenKey);
  }

}