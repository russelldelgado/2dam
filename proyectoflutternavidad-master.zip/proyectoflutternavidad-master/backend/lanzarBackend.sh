#instalacion 
#npm i -g json-server
#npm i -g express
#npm i -g json-server-auth

#parametros
#-H 0.0.0.0 escucha en todos los puertos
#--watch notes.json Base de datos json , detecta cambios y reinicia el server.
#-r routes.json , en este fichero se redireccionan las rutas a los guards de json-server-auth
#-d 1000 añade un delay de 1 segundo en cada peticion 

#fichero router.json de json-server-auth
#600 significa que solo el usuario dueño de la nota puede ver y hacer lo que quiera con sus notas y nadie mas puede 
#es decir solo el que hace login puede hacer lo que quiera con sus notas y los demas no pueden 

json-server-auth  -H 0.0.0.0 --watch notes.json -r routes.json -d 1000