import 'dart:convert' as convert;

void imprimirMensaje(cadena) => print('Mi mensaje es:$cadena');

class MiCodificadorBase64 {
  static String codificar(String cadena) {
    var utf8cadena = convert.Utf8Encoder().convert(cadena);
    var codificada = convert.base64Encode(utf8cadena);
    return codificada;
  }

  static String decodificar(String cadena) {
    var utf8cadena = convert.base64Decode(cadena);
    cadena = convert.Utf8Decoder().convert(utf8cadena);
    return cadena;
  }
}
