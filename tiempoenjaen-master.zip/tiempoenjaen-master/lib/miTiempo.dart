import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class MiTiempo {
  static final dominio = 'api.openweathermap.org';
  static final endpointCiudad = 'data/2.5/weather';
  static final _apikey = 'c52ab84bd604992ba3532a79c8a853ec';
  static final _units = 'metric';

  static void getTiempoActual(ciudad) async {
    var url = Uri.http(dominio, endpointCiudad,
        {'q': ciudad, 'units': _units, 'appid': _apikey});

    var respuesta = await http.get(url);
    if (respuesta.statusCode == 200) {
      var jsonRespuesta = convert.jsonDecode(respuesta.body);
      _prueba();
      print(
          'La temperatura en $ciudad es: ${jsonRespuesta['main']['temp']} grados centígrados.');
    }
  }

  static void _prueba() {
    print('Esto es una prueba');
  }
}
